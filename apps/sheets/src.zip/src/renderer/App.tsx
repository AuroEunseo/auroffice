import { focusWorksheet } from './sheet-focus'
import {
  activateFormulaClosure,
  applyDefinedNames,
  applyFormatPatchToRange,
  applyWorkbookNotes,
  cellValueBounds,
  clearLazyState,
  columnLetter,
  disposeVisuals,
  ensureLazyRangeLoaded,
  journalRangeSnapshot,
  lazyWorkbookCellReader,
  loadSnapshotIntoUniver,
  loadVisibleRange,
  loadWorkbookSkeleton,
  matrixBounds,
  modelCellValue,
  navigateToAnchor,
  workbookStructureLocked,
  queueFormulaRecalc,
  queueSparklineInstall,
  resolveRenderedSheetId,
  recalcOverBudgetAtOpen,
  RECALC_MAX_FAILURES,
  queueVisualInstall,
  sheetOutline,
  syncUniver,
  univerDefinedNames,
  installFindRevealFix,
  installInjectorResolutionGuard,
  installWrapMeasureLifecycle,
  noteSidecarCrash,
} from './univer-sync'
import { installGridGrowth } from './grid-growth'
import {
  pollUntilReady,
  runHeadlessRendererExport,
} from '@genoffice/electron-utils/headless-export'
import {
  commitActiveCellEditor,
  installJournalSuppressionUndoFilter,
  installLoadAutoHeightGate,
  journalSuppression,
  lazySheetMeta,
  lazySheetScreenExtent,
  pendingEditsForClose,
  type ActiveCellEditor,
  type ActiveWorkbook,
  type LazyWorkbookState,
  type UniverRuntime,
  type UniverWorksheet,
} from './univer-state'
import {
  hashSheetPassword,
  type SheetPasswordHash,
} from '@genoffice/xlsx-gateway/gateway/xlsx-protection-hash'
import { applyChangePlan, planFromOps, type OpExecutorContext } from './op-executor'
import { installSheetsMcpBridge, type McpSheetHandlers } from './mcp-bridge'
import { renameChartRefsForSheet } from './workbook-ops'
import {
  proposeOperations as proposeOperationsImpl,
  runDeterministicPlan as runDeterministicPlanImpl,
  structuralDeleteFormulaErrorSync,
  type PlanContext,
} from './plan-operations'
import {
  registerCellFontAliases,
  untilCellFontsLoaded,
  workbookFontFamilies,
} from './cell-font-fallback'
import { isNumericIdentifierText } from './cell-warning'
import { consumePendingUndoCarry, undoStackDepth } from './undo-carry'
import { createSaveGate, shouldRunSaveTick } from './save-scheduler'
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import {
  useAutoSavePref,
  ImageViewer,
} from '@genoffice/ui'

const addTokenUsage = (..._args: any[]): void => { }

import {
  CellValueType,
  getNumfmtParseValueFilter,
  BooleanNumber,
  InterceptorEffectEnum,
  isRealNum,
  IUndoRedoService,
  IUniverInstanceService,
  LocaleType,
  mergeLocales,
  ThemeService,
  UniverInstanceType,
  type ICellData,
  type IRange,
  type IStyleData,
  type Workbook,
} from '@univerjs/core'
import { FormulaExecutedStateType } from '@univerjs/engine-formula'
import { FindReplaceController, IFindReplaceService } from '@univerjs/find-replace'
import { ILayoutService } from '@univerjs/ui'
import { UniverSheetsConditionalFormattingPreset } from '@univerjs/preset-sheets-conditional-formatting'
import UniverPresetSheetsConditionalFormattingEnUS from '@univerjs/preset-sheets-conditional-formatting/locales/en-US'
import '@univerjs/preset-sheets-conditional-formatting/lib/index.css'
import {
  INTERCEPTOR_POINT,
  SheetInterceptorService,
  UniverSheetsCorePreset,
} from '@univerjs/preset-sheets-core'
import UniverPresetSheetsCoreEnUS from '@univerjs/preset-sheets-core/locales/en-US'
import { UniverSheetsDataValidationPreset } from '@univerjs/preset-sheets-data-validation'
import UniverPresetSheetsDataValidationEnUS from '@univerjs/preset-sheets-data-validation/locales/en-US'
import '@univerjs/preset-sheets-data-validation/lib/index.css'
import { UniverSheetsDrawingPreset } from '@univerjs/preset-sheets-drawing'
import '@univerjs/preset-sheets-drawing/lib/index.css'
import { UniverSheetsFindReplacePreset } from '@univerjs/preset-sheets-find-replace'
import UniverPresetSheetsFindReplaceEnUS from '@univerjs/preset-sheets-find-replace/locales/en-US'
import '@univerjs/preset-sheets-find-replace/lib/index.css'
import { UniverSheetsFilterPreset } from '@univerjs/preset-sheets-filter'
import UniverPresetSheetsFilterEnUS from '@univerjs/preset-sheets-filter/locales/en-US'
import '@univerjs/preset-sheets-filter/lib/index.css'
import { UniverSheetsNotePreset } from '@univerjs/preset-sheets-note'
import UniverPresetSheetsNoteEnUS from '@univerjs/preset-sheets-note/locales/en-US'
import '@univerjs/preset-sheets-note/lib/index.css'
import { UniverSheetsSortPreset } from '@univerjs/preset-sheets-sort'
import UniverPresetSheetsSortEnUS from '@univerjs/preset-sheets-sort/locales/en-US'
import '@univerjs/preset-sheets-sort/lib/index.css'
import { UniverSheetsTablePreset, UniverSheetsTableUIPlugin } from '@univerjs/preset-sheets-table'
import UniverPresetSheetsTableEnUS from '@univerjs/preset-sheets-table/locales/en-US'
import '@univerjs/preset-sheets-table/lib/index.css'
import { greenTheme } from '@univerjs/themes'
import { createUniver } from './create-univer'
import { planFileTableRegistrations } from './file-tables'
import {
  createTableDefaultRange,
  selectedTableEcho,
  selectedTableEquals,
  type SelectedTableRibbon,
  type TableDesignContext,
} from './table-design-actions'


// 👇 본문 코드 수정 없이 빌드를 통과시키는 더미 선언
const agentCoreDummy: any = new Proxy({}, {
    get: () => () => ({}),
});

// 1. AI 스코프 칩 렌더링 헬퍼
const resolveScopeChip = (..._args: any[]): any => ({
    label: '',
    icon: null,
    key: 'default',
    range: {
        startRow: 0,
        endRow: 0,
        startColumn: 0,
        endColumn: 0,
    },
})
    ; (globalThis as any).resolveScopeChip = resolveScopeChip

// 2. AI UI 플래그 및 사이드바 비활성화
const isCopilotOpen = false
    ; (globalThis as any).isCopilotOpen = false

const aiSidebarEnabled = false
    ; (globalThis as any).aiSidebarEnabled = false

const aiScopeRange = null
    ; (globalThis as any).aiScopeRange = null

const aiScopeColumns: any[] = []
    ; (globalThis as any).aiScopeColumns = aiScopeColumns

const aiScopeLocked = false
    ; (globalThis as any).aiScopeLocked = false

// 3. AI 관련 콜백 및 앵커 더미
const onAiScopeDismiss = () => { }
    ; (globalThis as any).onAiScopeDismiss = onAiScopeDismiss

const onAiCitation = () => { }
    ; (globalThis as any).onAiCitation = onAiCitation

const onAiScopeSelect = () => { }
    ; (globalThis as any).onAiScopeSelect = onAiScopeSelect

const onAiScopeLockToggle = () => { }
    ; (globalThis as any).onAiScopeLockToggle = onAiScopeLockToggle

const onAiScopeClear = () => { }
    ; (globalThis as any).onAiScopeClear = onAiScopeClear

const aiSelectionAskAnchor: any = {
    getBoundingClientRect: () => ({
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: 0,
        height: 0,
        x: 0,
        y: 0,
    }),
}
    ; (globalThis as any).aiSelectionAskAnchor = aiSelectionAskAnchor

const hideFromAiLocale: any = Object.assign((_locale?: string) => true, {
    valueOf: () => true,
})
    ; (globalThis as any).hideFromAiLocale = hideFromAiLocale

// 4. 마우스 드래그 핸들러 (함수/값 동시 대응)
const isSelectionDrag: any = Object.assign((..._args: any[]) => false, {
    valueOf: () => false,
})
    ; (globalThis as any).isSelectionDrag = isSelectionDrag

const setIsCopilotOpen = () => { }
    ; (globalThis as any).setIsCopilotOpen = setIsCopilotOpen

// 5. 인덱싱 세션 객체 방어 (.index 체이닝 대응)
const redactionSessionFor = (..._args: any[]): any => ({
    index: {
        marks: [],
        get: () => null,
    },
    session: null,
    status: 'ready',
})
    ; (globalThis as any).redactionSessionFor = redactionSessionFor

// 6. 시트 인덱싱 상태 완료 플래그
const isIndexing = false
    ; (globalThis as any).isIndexing = false

const isSheetIndexing = false
    ; (globalThis as any).isSheetIndexing = false

const redactionIndexing = false
    ; (globalThis as any).redactionIndexing = false

const isRedactionReady = true
    ; (globalThis as any).isRedactionReady = true

// 7. 시트 탭 정보 추출 헬퍼 (워크북 전체 시트 마운트 복구)
const getActiveSheetInfoImpl = (workbook: any, sheetId?: string): any => {
    if (!workbook) return null
    const sheets = workbook.getSheets ? workbook.getSheets() : []
    const activeSheet = sheetId && workbook.getSheetBySheetId
        ? workbook.getSheetBySheetId(sheetId)
        : (workbook.getActiveSheet ? workbook.getActiveSheet() : sheets[0])

    return {
        sheetId: activeSheet?.getSheetId?.() ?? 'sheet1',
        name: activeSheet?.getName?.() ?? 'Sheet1',
        sheet: activeSheet ?? null,
    }
}
    ; (globalThis as any).getActiveSheetInfoImpl = getActiveSheetInfoImpl

// 8. 워크북 범위 집계 헬퍼
const aggregateWorkbookRange = (..._args: any[]): any => ({
    startRow: 0,
    endRow: 100,
    startColumn: 0,
    endColumn: 26,
})
    ; (globalThis as any).aggregateWorkbookRange = aggregateWorkbookRange
// 기존 import에서 가져오던 변수/함수명에 맞춰 export/const로 지정 (가장 흔히 쓰이는 이름들)
export const AgentCore: any = agentCoreDummy;
export type AgentCore = any;

import { type WorkbookOperation } from '@genoffice/xlsx-gateway/domain/workbook-dsl'
import {
  columnLabel,
  parseAddress,
  rangeCellCount,
} from '@genoffice/xlsx-gateway/domain/cell-address'
import { collectCellFormulaTexts, quadraticFormulaError } from './formula-cost'
import {
  applyChartStateEdit,
  chartSupportsDataLabels,
  chartSupportsSeriesReplace,
  withDefaultBarLabels,
  type CellBounds,
} from '@genoffice/xlsx-gateway/domain/chart-visual'
import { InMemoryWorkbookAdapter } from '@genoffice/xlsx-gateway/domain/in-memory-workbook'
import { cfRuleUnsaveableReason, iconSetSaveable } from '@genoffice/xlsx-gateway/gateway/xlsx-cf'
import type { SheetRedactionState } from '@genoffice/xlsx-gateway/gateway/xlsx-redaction'
import { statesOnScreen } from './redact-marks-shift'
import { installLazyFindBridge } from './lazy-find'
import { startFullLoad } from './full-load'
import { opensInFormulaMode, workbookCellCounts } from './load-budget'
import { installReplaceAutoSearch } from './replace-autosearch'
import { FindReplacePanel } from './FindReplacePanel'
import {
  installCrossHighlight,
  loadCrossHighlightPreference,
  storeCrossHighlightPreference,
  type CrossHighlightHandle,
} from './cross-highlight'
import { installOutlineGutter, type OutlineGutterHandle } from './outline-gutter'
import {
  loadRowOutlines,
  outlineSummarySettings,
  showOutlineLevel,
  toggleOutlineGroup,
} from './outline-actions'
import { moveOutlineEntries, shiftOutlineEntries } from './outline-model'
import type { ApplyOutcome, ChangePlan } from '@genoffice/xlsx-gateway/domain/workbook.types'
import { ATTACHMENT_IMAGE_EXTS } from '../shared/desktop-api'
import type {
  AttachmentAddResult,
  AttachmentMeta,
  MenuAction,
  RecoveryPromptPayload,
  WorkbookFile,
  WorkbookVisualObject,
} from '../shared/desktop-api'
import type { StructuralJournalOp } from './edit-journal'
import {
  AUTO_FILL_COMMAND,
  AXIS_ATTR_MUTATIONS,
  BLOCKED_COMMAND_PATTERN,
  CF_MUTATIONS,
  CF_RULE_COMMAND_PATTERN,
  CHAT_STORAGE_KEY,
  COPY_SHEET_COMMAND,
  DEFINED_NAME_MUTATIONS,
  DV_EDIT_COMMAND_PATTERN,
  DV_MUTATIONS,
  EMPTY_CHART_EDITS,
  FILTER_COMMAND_PATTERN,
  FILTER_MUTATIONS,
  initialSnapshot,
  MERGE_MUTATIONS,
  MOVE_RANGE_COMMAND,
  RANGE_SHIFT_COMMAND_PATTERN,
  MOVE_ROWS_COMMAND,
  MOVE_ROWS_MUTATION,
  MOVE_RANGE_MUTATION,
  NOTE_MUTATIONS,
  PERSIST_TOOL_FIELD_MAX,
  pixelsToCharacterWidth,
  REMOVE_NUMFMT_MUTATION,
  REORDER_RANGE_MUTATION,
  ROW_COLUMN_MUTATIONS,
  safeJsonInput,
  SET_FROZEN_MUTATION,
  SET_NUMFMT_MUTATION,
  SET_RIGHT_TO_LEFT_MUTATION,
  TOGGLE_GRIDLINES_MUTATION,
  SET_ZOOM_OPERATION,
  SET_ZOOM_COMMAND,
  OPEN_FILTER_PANEL_OPERATION,
  SET_RANGE_VALUES_MUTATION,
  SET_RANGE_VALUES_COMMAND,
  SHEET_LIFECYCLE_MUTATIONS,
  SORT_COMMAND_PATTERN,
  STRUCTURAL_EDIT_COMMAND_PATTERN,
  STRUCTURE_LOCK_COMMANDS,
} from './app-constants'
import {
  fullLoadGate,
  largestRangeCells,
  rangeHasStreamedFormulas,
  reorderCommandRanges,
  reorderGate,
} from './reorder-gate'


import { RedactDialog } from './components/RedactDialog'
import { installRedactMenu, type SelectionRequest } from './redact-menu'
import { buildMark, restoreCellFill } from './redact-tint'
import {
  addMark,
  clearMark,
  hasPendingRedactionChange,
  indexFor,
  redactIntentFor,
  type MarkKey,
  type RedactDialogState,
} from './redact-actions'
import {
  getSourceRange as getSourceRangeImpl,
  handleCreatePivot as handleCreatePivotImpl,
  handleCreateSlicer as handleCreateSlicerImpl,
  handleEditPivotApply as handleEditPivotApplyImpl,
  handleRefreshPivot as handleRefreshPivotImpl,
  handleCreateTimeline as handleCreateTimelineImpl,
  handleRemoveSlicer as handleRemoveSlicerImpl,
  handleRemoveTimeline as handleRemoveTimelineImpl,
  handleSlicerSelectAll as handleSlicerSelectAllImpl,
  handleSlicerToggle as handleSlicerToggleImpl,
  handleTimelineRange as handleTimelineRangeImpl,
  isSelectionInPivot as isSelectionInPivotImpl,
  pivotEditInitial as pivotEditInitialImpl,
  pivotFieldMembers as pivotFieldMembersImpl,
  pivotFieldOptions as pivotFieldOptionsImpl,
  pivotSelectionKey as pivotSelectionKeyImpl,
  type PivotActionContext,
  type PivotEditContext,
  type SlicerPickerState,
  type TimelinePickerState,
} from './pivot-actions'
import type { ChartRecommendations } from '@genoffice/xlsx-gateway/domain/chart-recommend'
import {
  cellAtClientPoint,
  handleInsertChart as handleInsertChartImpl,
  handleInsertEquation as handleInsertEquationImpl,
  handleInsertIcon as handleInsertIconImpl,
  handleInsertPictureFile,
  handleInsertScreenshot,
  handleRecommendedCharts as handleRecommendedChartsImpl,
  type VisualActionContext,
} from './visual-actions'
import {
  activeCellLabel as activeCellLabelImpl,
  consolidateDefaultReference as consolidateDefaultReferenceImpl,
  goToReference as goToReferenceImpl,
  handleApplyAdvancedFilter as handleApplyAdvancedFilterImpl,
  handleCreateConsolidate as handleCreateConsolidateImpl,
  handleCreateSubtotal as handleCreateSubtotalImpl,
  handleInsertSymbol as handleInsertSymbolImpl,
  listDefinedNames as listDefinedNamesImpl,
  type DataToolsContext,
} from './data-tools-actions'
import { installTsvClipboardFix } from './clipboard-tsv'
import { installFilteredCopyHook } from './filtered-copy'
import { installFilterRangeOutlineSuppression } from './filter-range-outline'
import { createSheetTabActions } from './sheet-tab-actions'
import { installVeryHiddenSheetGuard } from './very-hidden-sheets'
import { installFormulaBarAutosize } from './formula-bar-autosize'
import { createFunctionArgumentsHost, installFxButtonHook } from './function-arguments-runtime'
import {
  applyShowFormulasView,
  installFormulaTextInterceptor,
  installFormulaViewInterceptor,
} from './formula-view'
import { installCachedValueFallbackInterceptor } from './formula-cached-fallback'
import { readLiveFunctionInfos } from './function-catalog'
import { installSupportedFunctionProbe } from './function-registry-probe'
import { installCellFilenameFunction } from './cell-function'
import { installRightToLeftCommand, refreshSheetRender, sheetIsRightToLeft } from './sheet-rtl-view'
import { installFormulaLexerFix } from './formula-lexer-fix'
import { installErrorValueAlignment } from './error-value-align'
import { installFormulaNewlineDisplay } from './formula-newline-display'
import { installCfDisplayKeyCompare } from './cf-duplicate-key'
import { installCfFormulaFold } from './cf-formula-fold'
import { installSheetRenameFix } from './sheet-rename-fix'
import { installArrowCollapse } from './arrow-collapse-fix'
import { effectiveSheetProtection, installSheetProtectionGuard } from './sheet-protection'
import type { SheetProtectionAllow } from '@genoffice/xlsx-gateway/gateway/xlsx-protection'
import { installCtrlDragFill } from './ctrl-drag-fill'
import { installContextSubmenuReopenFix } from './context-submenu-reopen-fix'
import { installMenuInputEnter } from './menu-input-enter'
import { installCellContextMenu } from './cell-context-menu'
import { installClipboardAnchorTile } from './clipboard-anchor-tile'
import { installSelectionWrapGuard } from './selection-wrap-fix'
import { sharedFormulaResolverFor } from './shared-formula-journal'
import { installCellClipAnchorFix } from './cell-clip-anchor-fix'
import { installBorderOverflowExclusionFix } from './border-overflow-exclusion'
import { installCfEmptySheetFastPath } from './cf-empty-fast-path'
import { installOtherFormulaAnchor } from './other-formula-anchor'
import { installMergeBorderFix } from './merge-border-fix'
import { installThickBorderFix } from './thick-border-fix'
import { installCenterContinuousRender } from './center-continuous'
import { installExcelFilterButton } from './filter-button-excel-style'
import {
  extendLargeFilterRange,
  installLargeFilterValues,
  isLargeFilterSheet,
  largeFilterAction,
} from './large-filter'
import { resetLargeFilter } from './large-filter-state'
import { installForceStringMarkGate, installLongTextRender } from './long-text-render'
import { installAutofitWrapBudget } from './autofit-wrap-budget'
import { installAutofitLinePitch } from './autofit-line-pitch'
import { installHeaderUnhideDebounce } from './load-perf-patches'
import { installCopyAnimationIdle } from './copy-animation-idle'
import { installNumberAsTextAlertSeverity } from './number-as-text-alert'
import { installFormulaStreamHold } from './formula-stream-hold'
import { installRichTextBidiFix } from './rich-text-bidi-fix'
import { installRtlTextDirectionFix } from './rtl-text-fix'
import { installRtlGridMirror } from './rtl-grid-mirror'
import { installVertAlignRender } from './vert-align-render'
import { installMultiRowAutofit } from './autofit-multi-row'
import { registerExcelJumpNav } from './excel-jump-nav'
import { registerEditorWordJump } from './editor-word-jump'
import { registerExcelShortcuts } from './excel-shortcuts'
import { InsertDeleteCellsDialog } from './InsertDeleteCellsDialog'
import { runCellsChoice } from './insert-delete-cells'
import type { CellsMode } from './insert-delete-cells'
import { installFormatPainter } from './format-painter'
import { installCopyMaterialize } from './copy-materialize'
import {
  applyPasteSpecial,
  readPasteSpecialSource,
  type PasteSpecialOptions,
  type PasteSpecialSource,
} from './paste-special'
import { installStatusBarFileStats } from './statusbar-file-stats'
import {
  installStatusBarStatsFilter,
  readStatusBarFuncs,
  toggleStatusBarFunc,
  writeStatusBarFuncs,
  type StatusBarFunc,
  type StatusBarStatsFilter,
} from './status-bar-stats'
import {
  applyUniverLocale,
  insertRowsBelowLocale,
  numberAsTextAlertLocale,
} from './univer-locales'
import { installRuleDetail } from './univer-rule-detail'
import { installActiveCellDataValidationChrome } from './data-validation-dropdown'
import { installInvalidDataMarkerSuppression } from './data-validation-marker'
import { installThreadedCommentAffordances, type ThreadHover } from './threaded-comment-marker'
import { threadPane, threadStore } from './threaded-comments'
import { ThreadHoverCard, ThreadedCommentsPane } from './ThreadedCommentsPane'
import { NotePicturesPane } from './NotePicturesPane'
import type { PendingNotePicture } from './note-pictures'
import { handleRemoveNotePicture } from './note-picture-actions'
import { installFormulaNullResultFix } from './formula-null-result'
import { installNumberFormatFix } from './numfmt-fix'
import { installIfsEmptySetFix } from './ifs-empty-set'
import { installCriteriaCompareCacheFix } from './criteria-compare-cache'
import { installRateFallback } from './rate-function'
import {
  handleRibbonCommand as handleRibbonCommandImpl,
  type RibbonCommandContext,
} from './ribbon-actions'
import {
  handleApplyHeaderFooter as handleApplyHeaderFooterImpl,
  handleExportPdf as handleExportPdfImpl,
  handlePageLayoutCommand as handlePageLayoutCommandImpl,
  openPrintPreviewHost,
  type PrintPreviewHost,
  type PageLayoutContext,
} from './page-layout-actions'
import { handleExportCsv as handleExportCsvImpl, type CsvExportContext } from './csv-export'
import { effectivePageBreaks, installPageBreakPreview } from './page-break-preview'
import { mapProtectedRanges } from './protected-ranges'
import { handleSave as handleSaveImpl, type SaveContext, type SaveOutcome } from './save-actions'
import {
  applyChartEdit as applyChartEditImpl,
  applyShapeEdit as applyShapeEditImpl,
  flushPendingChartDataSync,
  queueChartDataSync as queueChartDataSyncImpl,
  queueChartRefResync,
  readChartVector as readChartVectorImpl,
  type VisualSyncContext,
} from './visual-edit-sync'
import {
  frameChangeEdit,
  handleVisualCommand,
  liveVisual,
  visualFrameInfo,
  type VisualArrangeContext,
  type VisualDialogKind,
} from './visual-arrange-actions'
import { VisualDialog, type SizeDialogResult } from './VisualDialogs'

import {
  cellImageAddAt,
  createEditJournal,
  isSheetRemoved,
  hyperlinkEditAt,
  journalSize,
  recordCfChange,
  recordPageSetup,
  recordDefinedNamesChange,
  recordDvChange,
  recordNoteChange,
  recordProtectedRangesChange,
  recordFilterChange,
  recordRemoveNumfmt,
  recordSetNumfmt,
  recordSetRangeValues,
  recordSheetHidden,
  recordSheetTabColor,
  recordSheetDuplicate,
  recordSheetInsert,
  recordSheetOrderChange,
  recordSheetRemove,
  recordSheetRename,
  recordStructuralOp,
  shiftVisualForStructuralOp,
} from './edit-journal'
import { shiftPinnedCells } from './formula-closure'
import { getLang, t, aiLangDirective } from './i18n/locale'
import { planStillMatches } from './lazy-plan'
import { lastSurvivingScreenLine, netAxisDelta, screenToFile } from './view-transform'
import { selectionFormatEquals, toSelectionFormat, type SelectionFormat } from './selection-format'
import { ExcelShell, type SelectedShapeRibbon } from './ExcelShell'
import { RecoveryDialog } from './RecoveryDialog'
import { EncryptedWorkbookPasswordDialog } from './EncryptedWorkbookPasswordDialog'
import { ChangeWorkbookPasswordDialog } from './ChangeWorkbookPasswordDialog'
import { ToastHost } from './toast'
import { showToast } from './toast-bus'
import { AdvancedFilterDialog, type AdvancedFilterColumn } from './AdvancedFilterDialog'
import { EquationDialog } from './EquationDialog'
import { IconsDialog } from './IconsDialog'
import { RecommendedChartsDialog } from './RecommendedChartsDialog'
import { installPictureTransfer } from './picture-paste'
import { installCellImagePreview } from './cell-image-preview'
import { installWheelZoomSteps } from './wheel-zoom'
import { ScreenshotDialog } from './ScreenshotDialog'
import { SymbolDialog } from './SymbolDialog'
import {
  calculateNow,
  calculateSheet,
  resetCalculationMode,
  setManualCalculation,
} from './calc-options'
import { applyFillSeries, fillSeriesContext } from './fill-series-apply'
import { solveGoalSeek } from './goal-seek'
import { applyDataTable } from './data-table'
import {
  awaitFormulaValues,
  clearVerifiedFormulaValues,
  formulaTargetsFromOps,
  rememberFormulaValue,
} from './formula-values'
import { SlicerFieldPicker, SlicerPanels, type SlicerUiState } from './SlicerPanel'
import { WatchWindowPanel, watchKey, type WatchCell, type WatchRowValue } from './WatchWindowPanel'
import { TimelineFieldPicker, TimelinePanels, type TimelineUiState } from './TimelinePanel'
import type { DefinedNameAction, DefinedNameRow } from './NameManagerDialog'
import { workbookMediaDataUrl } from './workbook-media'
import {
  clearVisualSelection,
  convertibleType,
  getChartElementSelection,
  installWorkbookVisuals,
  isVisualDragActive,
  setChartDialogListener,
  setVisualCommandListener,
  setVisualSelectionListener,
  subscribeChartElementSelection,
  type ChartDialogKind,
  type ChartEditData,
  type ChartVectorRead,
  type ShapeEditChanges,
  isEditableFileVisual,
  isEditableShape,
} from './WorkbookVisuals'
import { ChartFormatPane, SelectDataDialog } from './ChartPanels'
import { handleSheetsControl, type ControlRequest } from './control'

// Source sheet id of an in-flight copy-sheet command; the next insert-sheet
// mutation is that copy and must journal as a duplicate, not a blank add.
let pendingCopySource: string | undefined

/// Plain text of a rich-text cell: neither the raw model nor the view model
/// materializes a v for those — the text lives in the p document. The
/// document-terminating \r\n is stripped (it would break wholeCell matches)
/// and in-document paragraph breaks (\r) become \n, matching extractRichText
/// and the text users actually type.
/// Interceptors run on every cell read (each frame per visible cell, plus
/// every streamed chunk), and numfmt's date/time parser is slow on long
/// strings, so classify each distinct string once. No date, time or number
/// literal is longer than 64 characters.
const dateTextKinds = new Map<string, 'date-like' | 'text'>()
function dateTextKind(value: string): 'date-like' | 'text' {
  if (value.length > 64) return 'text'
  const cached = dateTextKinds.get(value)
  if (cached) return cached
  let kind: 'date-like' | 'text' = 'text'
  if (isNumericIdentifierText(value)) kind = 'date-like'
  else if (!isRealNum(value)) {
    const parsed = getNumfmtParseValueFilter(value)
    if (parsed?.z && /[ymdhs]/i.test(parsed.z)) kind = 'date-like'
  }
  if (dateTextKinds.size >= 50_000) dateTextKinds.clear()
  dateTextKinds.set(value, kind)
  return kind
}

export function App({
  queuedWorkbookAtBoot = false,
}: {
  queuedWorkbookAtBoot?: boolean
}): React.JSX.Element {
  const adapterRef = useRef(new InMemoryWorkbookAdapter(initialSnapshot))
  const univerRef = useRef<UniverRuntime | null>(null)
  const lazyWorkbookRef = useRef<LazyWorkbookState | null>(null)
  /**
   * The cells the reader withheld from the model, read once per open (see the
   * `readWorkbookRedactions` call in openLazyWorkbook). A ref rather than
   * state: the readers ask about it per cell and nothing renders from it, and
   * the marks the user adds later replace it through the same ref.
   */
  const redactionIndexRef = useRef<RedactionIndex | null>(null)
  /**
   * The same marks, in the shape the save takes (keyed by sheet name, as the
   * package part is). Held here so a save can carry them even when nothing
   * else in the journal is dirty — a workbook whose only pending change is a
   * newly withheld cell is still a workbook that must be saved.
   */
  const redactionStatesRef = useRef<readonly SheetRedactionState[]>([])
  /**
   * What the part held when this workbook was opened. A mark added or cleared
   * since then is a pending change the edit journal never sees, and the save
   * ticks below decide whether there is anything to write from that journal
   * alone — so without this a workbook whose only edit is a withheld cell
   * would never autosave, and closing the tab would drop the mark silently.
   */
  const loadedRedactionStatesRef = useRef<readonly SheetRedactionState[] | null>(null)
  /**
   * The pending "what does this stand for?" question, or null when no dialog
   * is open. State, not a ref: the dialog renders from it.
   */
  const [redactDialog, setRedactDialog] = useState<RedactDialogState | null>(null)
  /**
   * True when the reader's marks differ from what the file was opened with.
   *
   * Compares the two shapes as text: the marks are a handful of rectangles, and
   * a stable serialization is both simpler and stricter than a field-by-field
   * walk — a mark that moved by one row is a change, and both sides serialize
   * in the same order, so the comparison is exact.
   */
  function redactionsPendingSave(): boolean {
    const loaded = loadedRedactionStatesRef.current
    return loaded !== null && hasPendingRedactionChange(redactionStatesRef.current, loaded)
  }
  /// Univer undo/redo stack occupancy (subscribed at mount): drives the QAT button gray states
  const [univerHist, setUniverHist] = useState({ canUndo: false, canRedo: false })
  /// Set once Univer boots; mounts the app's Excel-style Find & Replace panel.
  const [findReplaceService, setFindReplaceService] = useState<IFindReplaceService | null>(null)
  const [threadHover, setThreadHover] = useState<ThreadHover | null>(null)
  const getRuntime = useCallback(() => univerRef.current, [])
  /// True while Univer's in-cell editor is open (AutoSave must not save-reload then).
  const editingCellRef = useRef(false)
  const visualDisposablesRef = useRef<{ dispose(): void }[]>([])
  const traceArrowsRef = useRef<{ disposables: { dispose(): void }[]; nextId: number }>({
    disposables: [],
    nextId: 0,
  })
  /// Page Break Preview overlay layers per sheet; the sheet-id set drives the
  /// ribbon echo, the ref owns the float DOM disposables.
  const [pageBreakPreviewSheets, setPageBreakPreviewSheets] = useState<ReadonlySet<string>>(
    new Set(),
  )
  const [printHost, setPrintHost] = useState<PrintPreviewHost | null>(null)
  const pageBreakLayersRef = useRef<Map<string, { dispose(): void }[]>>(new Map())
  const pageBreakIdRef = useRef(0)
  /// App-level setting, Excel-style: not stored in the file, kept across
  /// workbook switches.
  const [formulaBarVisible, setFormulaBarVisible] = useState(true)
  /// Cross-highlight ("reading mode") of the active row/column, persisted in
  /// localStorage like the auto-save flag; off until the user opts in.
  const [crossHighlightVisible, setCrossHighlightVisible] = useState(loadCrossHighlightPreference)
  const crossHighlightRef = useRef<CrossHighlightHandle | null>(null)
  const outlineGutterRef = useRef<OutlineGutterHandle | null>(null)
  const visualInstallTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const sparklineDisposablesRef = useRef<{ dispose(): void }[]>([])
  const sparklineTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const visualViewportKeyRef = useRef('')
  const demoVisualDisposablesRef = useRef<{ dispose(): void }[]>([])
  const demoVisualInstallTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [prompt, setPrompt] = useState('')
  const [preview, setPreview] = useState<ChangePlan | null>(null)
  const [_revision, setRevision] = useState(0)
  const [workbookFile, setWorkbookFile] = useState<WorkbookFile | null>(null)
  const [pendingEdits, setPendingEdits] = useState(0)
  /// Whether any cell in the workbook has content — the ribbon's one-click AI
  /// action buttons are greyed out on a fully empty sheet.
  const [sheetHasContent, setSheetHasContent] = useState(false)
  const recomputeSheetContent = useCallback(() => {
    setSheetHasContent(() => {
      // A file opened from disk always counts as having content.
      if (lazyWorkbookRef.current) return true
      const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
      if (!workbook) return false
      const snapshot = workbook.getSnapshot()
      for (const sheet of Object.values(snapshot.sheets ?? {})) {
        for (const row of Object.values(sheet.cellData ?? {})) {
          for (const cell of Object.values(row ?? {}) as (ICellData | null | undefined)[]) {
            if (!cell) continue
            if (cell.f || cell.p) return true
            if (cell.v !== undefined && cell.v !== null && String(cell.v) !== '') return true
          }
        }
      }
      return false
    })
  }, [])
  // Open/close of a real file swaps the whole data source; re-evaluate then too.
  useEffect(() => {
    recomputeSheetContent()
  }, [workbookFile, recomputeSheetContent])
  // The close guard lives in the main process; keep it fed with the badge count.
  useEffect(() => {
    window.desktopApi?.notifyPendingEdits?.(
      pendingEditsForClose(pendingEdits, editingCellRef.current),
    )
  }, [pendingEdits])
  const [autoSave, setAutoSave] = useAutoSavePref('ai-sheets-auto-save', window.desktopApi)
  // Ref mirror for callbacks captured when an AI run starts
  const autoSaveRef = useRef(autoSave)
  autoSaveRef.current = autoSave
  const saveGateRef = useRef(createSaveGate())
  // AutoSave tick (docs/slides parity): every 30 s and on window blur, flush
  // pending edits of the open workbook. The journal is read at tick time so
  // the interval stays stable; demo mode has no backing file and is skipped.
  useEffect(() => {
    if (!autoSave) return
    const tick = () => {
      const state = lazyWorkbookRef.current
      // Never while the in-cell editor is open (saving reloads the workbook
      // and would wipe the edit), never for converted .xls imports whose
      // first save opens a Save As dialog (a new unsaved workbook saves its
      // backing file quietly instead), and never for CSV sessions —
      // AutoSave would silently flatten the user's file.
      if (
        !state ||
        !shouldRunSaveTick({
          saveInFlight: saveGateRef.current.busy,
          hasWorkbook: true,
          journalEmpty: journalSize(state.editJournal) === 0,
          redactionsPendingSave: redactionsPendingSave(),
          editingCell: editingCellRef.current,
          needsSaveAsNotUnsavedNew: Boolean(state.file.needsSaveAs) && !state.file.unsavedNew,
          isCsv: state.file.csvPath !== undefined,
          kind: 'save',
          restoredFromRecovery: false,
          automaticRecoveryDisabled: false,
        })
      )
        return
      void handleSaveRef.current('save', true)
    }
    const id = window.setInterval(tick, 30_000)
    window.addEventListener('blur', tick)
    return () => {
      window.clearInterval(id)
      window.removeEventListener('blur', tick)
    }
  }, [autoSave])

  // Crash-recovery copy: independent of the AutoSave pill — a dirty
  // workbook gets a real .xlsx copy under userData every 30 s, so a force-quit or a
  // renderer crash no longer costs everything since the last manual save. A normal
  // save removes the copy; reopening a file whose copy is newer offers Restore.
  useEffect(() => {
    const tick = () => {
      const state = lazyWorkbookRef.current
      // The in-cell editor's pending text is not in the journal yet, a
      // converted import has no original file to recover into, and a restored
      // recovery session is backed by the recovery copy itself.
      if (
        !state ||
        !shouldRunSaveTick({
          saveInFlight: saveGateRef.current.busy,
          hasWorkbook: true,
          journalEmpty: journalSize(state.editJournal) === 0,
          redactionsPendingSave: redactionsPendingSave(),
          editingCell: editingCellRef.current,
          needsSaveAsNotUnsavedNew: Boolean(state.file.needsSaveAs) && !state.file.unsavedNew,
          isCsv: state.file.csvPath !== undefined,
          kind: 'recovery',
          restoredFromRecovery: state.file.restoredFromRecovery === true,
          automaticRecoveryDisabled: state.file.automaticRecoveryDisabled === true,
        })
      )
        return
      void handleSaveRef.current('recovery')
    }
    const id = window.setInterval(tick, 30_000)
    return () => window.clearInterval(id)
  }, [])
  const [recoveryPrompt, setRecoveryPrompt] = useState<RecoveryPromptPayload | null>(null)
  useEffect(
    () => window.desktopApi?.onRecoveryPrompt?.((prompt) => setRecoveryPrompt(prompt)) ?? undefined,
    [],
  )
  /// Streaming-mode filter gate: the filter panel builds
  /// value counts from whatever happens to be loaded and the apply command is
  /// cancelled, so instead of a silent no-op the user gets an explicit offer
  /// to fully load the workbook first.
  const [fullLoadPrompt, setFullLoadPrompt] = useState<'ask' | 'tooLarge' | null>(null)
  const [encryptedPasswordPrompt, setEncryptedPasswordPrompt] = useState<{
    readonly error: string | null
    readonly resolve: (password: string | null) => void
  } | null>(null)
  const requestEncryptedWorkbookPassword = (error: string | null): Promise<string | null> =>
    new Promise((resolve) => setEncryptedPasswordPrompt({ error, resolve }))
  const answerEncryptedWorkbookPassword = (password: string | null): void => {
    const prompt = encryptedPasswordPrompt
    setEncryptedPasswordPrompt(null)
    prompt?.resolve(password)
  }
  const [changeWorkbookPasswordOpen, setChangeWorkbookPasswordOpen] = useState(false)
  const [message, setMessage] = useState(t('appReadyInitial'))
  const sheetTabActions = useMemo(
    () => createSheetTabActions({ univerRef, lazyWorkbookRef, notify: setMessage }),
    [],
  )
  const [openingWorkbook, setOpeningWorkbook] = useState(
    () =>
      queuedWorkbookAtBoot ||
      new URLSearchParams(window.location.search).get('openingWorkbook') === '1',
  )
  const [emptyCsvNotice, setEmptyCsvNotice] = useState(false)
  /// Zoom of the active sheet in percent, echoed by the status-bar slider.
  const [zoomPercent, setZoomPercent] = useState(100)
  const [statusBarFuncs, setStatusBarFuncs] = useState<readonly StatusBarFunc[]>(() =>
    readStatusBarFuncs(localStorage),
  )
  const statusBarFuncsRef = useRef(statusBarFuncs)
  const statusBarStatsFilterRef = useRef<StatusBarStatsFilter | null>(null)
  const toggleStatusBarStat = (func: StatusBarFunc): void => {
    const next = toggleStatusBarFunc(statusBarFuncsRef.current, func)
    statusBarFuncsRef.current = next
    setStatusBarFuncs(next)
    writeStatusBarFuncs(localStorage, next)
    statusBarStatsFilterRef.current?.refresh()
  }
  const [selectionFormat, setSelectionFormat] = useState<SelectionFormat | null>(null)
  const [formatPainterActive, setFormatPainterActive] = useState(false)
  /// A1 label of the active cell, echoed live by the Name Box. Updated from
  /// the same SelectionChanged refresh that keeps selectionFormat current.
  const [activeCellA1, setActiveCellA1] = useState('')
  /// The multi-cell selection the AI composer shows as its scope chip, or null.
  /// A resting single-cell selection carries no intent, so it gets no chip —
  /// only a range the user deliberately dragged or shift-selected does.
  const [aiScope, setAiScope] = useState<FrozenSelection | null>(null)
  const [aiSelectionAskAnchor, setAiSelectionAskAnchor] = useState<SelectionAskAnchor | null>(null)
  const selectionDragRef = useRef<{
    start: Point
    initialRangeKey: string | null
    dragged: boolean
    selectionChanged: boolean
  } | null>(null)
  /// The user clicked × on the scope chip: this run targets the sheet at large.
  /// Re-arms on the next selection change, so a fresh drag means a fresh scope.
  const [aiScopeDismissed, setAiScopeDismissed] = useState(false)
  /// Selection scope of the run in flight. undefined = no run owns a scope
  /// (report the live selection); null = the user dropped it. The ref is what
  /// the skill's getActiveSheetInfo reads mid-run; the state is what the chip
  /// renders from, so both are written together by setAiRunScope.
  const aiRunScopeRef = useRef<FrozenSelection | null | undefined>(undefined)
  const [aiRunScope, setAiRunScopeState] = useState<FrozenSelection | null | undefined>(undefined)
  /// `sheetId!A1` of the scope currently on the chip; the refresh compares
  /// against it so an unchanged selection never resets the dismissed flag.
  const aiScopeKeyRef = useRef<string | null>(null)
  /// Non-null while the Advanced Filter dialog is open: the column choices
  /// sampled from the active filter range's header row.
  const [advancedFilterColumns, setAdvancedFilterColumns] = useState<
    readonly AdvancedFilterColumn[] | null
  >(null)
  /// True while the Insert → Symbol dialog is open.
  const [symbolDialogOpen, setSymbolDialogOpen] = useState(false)
  const [cellsDialog, setCellsDialog] = useState<CellsMode | null>(null)
  const [screenshotDialogOpen, setScreenshotDialogOpen] = useState(false)
  const [iconsDialogOpen, setIconsDialogOpen] = useState(false)
  const [equationDialogOpen, setEquationDialogOpen] = useState(false)
  const [recommendedCharts, setRecommendedCharts] = useState<ChartRecommendations | null>(null)
  /// The focused floating visual (chart/shape/image); charts surface a
  /// contextual Chart Design ribbon tab while selected.
  const [selectedVisual, setSelectedVisual] = useState<WorkbookVisualObject | null>(null)
  const [visualDialog, setVisualDialog] = useState<{
    kind: VisualDialogKind
    visualId: string
  } | null>(null)
  /// Data URL of the cell picture opened in the full-size viewer, if any.
  const [viewImage, setViewImage] = useState<string | null>(null)
  const visualCommandRef = useRef<(command: string, visualId: string) => void>(() => undefined)
  const [selectedTable, setSelectedTable] = useState<SelectedTableRibbon | null>(null)
  const [tableCreatedSeq, setTableCreatedSeq] = useState(0)
  /// Chart panels (Select Data dialog / format task pane), opened from the
  /// ribbon or the chart context menu, keyed like chart edits.
  const [chartDialog, setChartDialog] = useState<{ kind: ChartDialogKind; editKey: string } | null>(
    null,
  )
  const chartElement = useSyncExternalStore(
    subscribeChartElementSelection,
    getChartElementSelection,
  )
  /// Bumped on every visual/chart edit: journal edits merge in place, so the
  /// journal size (pendingEdits) alone misses same-target re-edits and the
  /// ribbon echo would go stale.
  const [, setVisualEditTick] = useState(0)
  /// In-session slicers (OOXML slicer part persistence: see the TODO in
  /// SlicerPanel).
  const [slicers, setSlicers] = useState<readonly SlicerUiState[]>([])
  const [watchOpen, setWatchOpen] = useState(false)
  const [watchCells, setWatchCells] = useState<readonly WatchCell[]>([])
  const [calcManual, setCalcManual] = useState(false)
  /// Non-null while the "Insert Slicer" field picker is open.
  const [slicerPicker, setSlicerPicker] = useState<SlicerPickerState | null>(null)
  /// In-session timelines (same session-only model as slicers).
  const [timelines, setTimelines] = useState<readonly TimelineUiState[]>([])
  /// Non-null while the "Insert Timeline" field picker is open.
  const [timelinePicker, setTimelinePicker] = useState<TimelinePickerState | null>(null)
  const menuActionRef = useRef<(action: MenuAction) => void>(() => {})
  /// Where the user was when a save started: the post-save session swap
  /// reinstalls the workbook, and the install consumes this instead of
  /// resetting the view to the first sheet's A1.
  const viewRestoreRef = useRef<{
    sheetId: string
    row: number
    column: number
    viewRow: number
    viewColumn: number
  } | null>(null)
  /// Set by a save's reopen: the next session-id change continues the same
  /// AI conversation instead of rehydrating it (which would show the live
  /// turn a second time under "Earlier conversation").
  const chatContinuesRef = useRef(false)
  /// Bumped per chat resolution; a resolution that awaited past a newer one
  /// must not write ids or history for a workbook that is no longer open.
  const chatResolveGenRef = useRef(0)
  /// Fresh handleSave for the AutoSave tick (assigned each render, like
  /// menuActionRef, so the interval closure never goes stale).
  const handleSaveRef = useRef<
    (
      mode: 'save' | 'save-as' | 'recovery',
      quiet?: boolean,
      explicitTarget?: { path: string; overwrite: boolean },
    ) => Promise<SaveOutcome>
  >(() => Promise.resolve({ ok: false }))
  /// Latest MCP bridge handlers (assigned each render; see the install below).
  const mcpSheetHandlersRef = useRef<McpSheetHandlers | null>(null)
  const closeSaveRef = useRef<() => Promise<void>>(() => Promise.resolve())
  const commitActiveEditor = useCallback(async (): Promise<boolean> => {
    const editor = univerRef.current?.univerAPI.getActiveWorkbook() as
      ActiveCellEditor | null | undefined
    return commitActiveCellEditor(editor).catch(() => false)
  }, [])
  const refreshSelectionFormatRef = useRef<() => void>(() => {})
  const chartEditRef = useRef<(chartPath: string, edit: ChartEditData) => void>(() => {})
  const chartVectorRef = useRef<(chartPath: string, range: string) => Promise<ChartVectorRead>>(
    () => Promise.reject(new Error('Workbook not ready.')),
  )
  const shapeEditRef = useRef<(visualId: string, changes: ShapeEditChanges) => void>(() => {})
  /// A3 editing of an existing pivot: context locked when the dialog opens, used
  /// on Apply.
  const pivotEditContextRef = useRef<PivotEditContext | null>(null)
  const [pivotSelectionKey, setPivotSelectionKey] = useState<string | null>(null)
  const lazyPreviewRef = useRef<{
    sessionId: string
    sheetId: string
    plan: ChangePlan
  } | null>(null)

  /** App-scope state bundle for the extracted plan builders (plan-operations.ts). */
  function planContext(): PlanContext {
    return { adapterRef, univerRef, lazyWorkbookRef, lazyPreviewRef, setPreview, autoApplySafePlan }
  }

  /** App-scope refs/state bundle for the extracted pivot actions (pivot-actions.ts). */
  function pivotContext(): PivotActionContext {
    return {
      univerRef,
      lazyWorkbookRef,
      pivotEditContextRef,
      slicers,
      slicerPicker,
      setSlicers,
      setSlicerPicker,
      timelines,
      timelinePicker,
      setTimelines,
      setTimelinePicker,
      setMessage,
      setPendingEdits,
    }
  }

  /** App-scope refs/state bundle for the extracted visual-insert actions (visual-actions.ts). */
  function visualContext(): VisualActionContext {
    return {
      adapterRef,
      univerRef,
      lazyWorkbookRef,
      visualDisposablesRef,
      visualInstallTimerRef,
      chartEditRef,
      chartVectorRef,
      shapeEditRef,
      setMessage,
      setRevision,
      setPreview,
      setPendingEdits,
      pivotContext,
      queueDemoVisualInstall,
      refreshLazyVisuals,
    }
  }

  /** App-scope refs/state bundle for the extracted data-tool actions (data-tools-actions.ts). */
  function dataToolsContext(): DataToolsContext {
    return { univerRef, lazyWorkbookRef, setMessage, setPendingEdits, setAdvancedFilterColumns }
  }

  function tableDesignContext(): TableDesignContext {
    return {
      univerRef,
      lazyWorkbookRef,
      setMessage,
      setPendingEdits,
      refreshSelection: () => refreshSelectionFormatRef.current(),
      onTableCreated: () => setTableCreatedSeq((seq) => seq + 1),
    }
  }

  function pageLayoutContext(): PageLayoutContext {
    return {
      univerRef,
      lazyWorkbookRef,
      setMessage,
      setPendingEdits,
      refreshPageBreakPreview,
      requestVisualInstall: () => {
        const runtime = univerRef.current
        if (!runtime) return
        queueVisualInstall(
          runtime,
          lazyWorkbookRef,
          visualDisposablesRef,
          visualInstallTimerRef,
          chartEditRef,
          chartVectorRef,
          shapeEditRef,
        )
      },
      runOps: runUiOps,
    }
  }

  // Headless export mode (--headless-export): this renderer lives in a hidden
  // window whose only job is to run the ribbon's own PDF export against a path
  // the CLI chose, then report back so the main process can quit.
  const headlessExportStartedRef = useRef(false)
  useEffect(() => {
    if (headlessExportStartedRef.current) return
    headlessExportStartedRef.current = true
    void (async () => {
      const outPath = (await window.desktopApi?.consumeHeadlessExport?.()) ?? null
      if (!outPath) return
      const report = await runHeadlessRendererExport(
        outPath,
        async () => {
          await pollUntilReady(() => lazyWorkbookRef.current !== null, 'no workbook opened', {
            timeoutMs: 300_000,
          })
          // The PDF layout needs every cell in the grid. Workbooks small enough
          // for formula mode preload themselves; a larger one waits for the
          // user's "Full Load" click, which headless has to make itself.
          await pollUntilReady(
            () => {
              const state = lazyWorkbookRef.current
              if (!state) return false
              if (state.flags.preloadComplete) return true
              const runtime = univerRef.current
              if (runtime && !state.flags.preloadRunning) {
                void startFullLoad(runtime, lazyWorkbookRef, setMessage)
              }
              return false
            },
            'workbook never finished loading',
            { timeoutMs: 540_000, pollMs: 500 },
          )
        },
        (target) => handleExportPdfImpl(pageLayoutContext(), target),
      )
      window.desktopApi?.headlessExportDone?.(report)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps -- runs once per renderer; reads the latest state through refs
  }, [])

  function csvExportContext(): CsvExportContext {
    return {
      univerRef,
      lazyWorkbookRef,
      setMessage,
      requestSaveAs: () => void handleSaveRef.current('save-as'),
    }
  }

  function saveContext(): SaveContext {
    return {
      univerRef,
      lazyWorkbookRef,
      setMessage,
      openLazyWorkbook,
      setPendingEdits,
      readCells: (addresses, sheetId) => readCellsImpl(readContext(), addresses, sheetId),
      // null until the part was read: a save in that window must not clear it
      redactionStates: () =>
        loadedRedactionStatesRef.current === null ? null : redactionStatesRef.current,
      stashViewRestore: (view) => {
        viewRestoreRef.current = view
      },
    }
  }

  function visualSyncContext(): VisualSyncContext {
    return {
      adapterRef,
      univerRef,
      lazyWorkbookRef,
      chartSyncRef,
      setMessage,
      refreshLazyVisuals,
      refreshDemoVisuals,
    }
  }

  function visualArrangeContext(): VisualArrangeContext {
    return {
      univerRef,
      lazyWorkbookRef,
      shapeEditRef,
      setMessage,
      refreshLazyVisuals,
      setPendingEdits,
      openDialog: (kind, visualId) => setVisualDialog({ kind, visualId }),
      resyncChart: (state, editKey) => queueChartRefResync(visualSyncContext(), state, editKey),
      refreshCellImages: () => {
        const runtime = univerRef.current
        if (runtime) {
          queueSparklineInstall(
            runtime,
            lazyWorkbookRef,
            sparklineDisposablesRef,
            sparklineTimerRef,
          )
        }
      },
    }
  }
  visualCommandRef.current = (command, visualId) =>
    handleVisualCommand(visualArrangeContext(), command, visualId)

  function proposeOperations(
    operations: readonly WorkbookOperation[],
    summary: string,
  ): { ok: true; plan: ChangePlan } | { ok: false; error: string } {
    return proposeOperationsImpl(planContext(), operations, summary)
  }

  function runDeterministicPlan(instruction: string): { text: string; isError?: boolean } {
    return runDeterministicPlanImpl(planContext(), instruction)
  }

  // ---- AI: real LLM agent (falls back to the deterministic planner above
  // when no provider is configured — see isAgentConfigured/handleSend) ----
  const [aiSettings, setAiSettingsState] = useState<AiSettings | null>(null)
  const aiSettingsRef = useRef<AiSettings | null>(null)
  aiSettingsRef.current = aiSettings

  /** gsk login state for the cloud-tools gate (refreshed on mount and window focus) */
  const gskLoggedInRef = useRef(false)
  useEffect(() => {
    let alive = true
    const refresh = () => {
      void window.desktopApi
        ?.aiGskStatus()
        .then((s) => {
          if (alive) gskLoggedInRef.current = !!s?.loggedIn
        })
        .catch(() => {})
    }
    refresh()
    window.addEventListener('focus', refresh)
    return () => {
      alive = false
      window.removeEventListener('focus', refresh)
    }
  }, [])
  const [aiBusy, setAiBusy] = useState(false)
  // Display history survives restarts via localStorage; the AgentLoop's model
  // context does not, so restored turns are read-only transcript.
  const [chat, setChat] = useState<readonly AiChatMessage[]>([])
  /** History loaded from project-store (read-only transcript, not fed to the model) */
  const [historicChat, setHistoricChat] = useState<readonly AiChatMessage[]>([])
  // ── Chat attachments (same structure as docs/slides: text types go through the
  // read_attachment tool, images go multimodal) ──
  const [attachments, setAttachments] = useState<readonly AttachmentMeta[]>([])
  const [attachNotice, setAttachNotice] = useState<string | null>(null)
  const attachmentsRef = useRef(attachments)
  attachmentsRef.current = attachments
  const [attachedSkills, setAttachedSkills] = useState<readonly string[]>([])
  const attachedSkillsRef = useRef(attachedSkills)
  attachedSkillsRef.current = attachedSkills
  const toggleSkill = (name: string) =>
    setAttachedSkills((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name],
    )
  /** Attachments consumed by earlier sends this session: sending clears the composer, but the
      files skill must keep reading them mid-run and in follow-up turns. Deduped by path. */
  const sentAttachmentsRef = useRef<readonly AttachmentMeta[]>([])
  /** composer attachments plus everything already sent this session (deduped by path) */
  const availableAttachments = (): AttachmentMeta[] => {
    const seen = new Set<string>()
    return [...sentAttachmentsRef.current, ...attachmentsRef.current].filter((a) =>
      seen.has(a.path) ? false : (seen.add(a.path), true),
    )
  }
  /** Synchronous re-entrancy guard between runAgent trigger and loop.run
   * (loop.busy is still false while attachment images load asynchronously) */
  const runStartingRef = useRef(false)
  /** The shell can repeat its queued-open nudge while the renderer starts.
   * Only one picker/open request may own the workbook session at a time. */
  const workbookOpeningRef = useRef(false)
  /** Current session's projectId/chatId (resolved when the workbook opens) */
  const chatRefIdsRef = useRef<{ projectId: string; chatId: string } | null>(null)

  // File renamed externally (in the shell Home list) → sync the title-bar file
  // name (the save path is synced by the main process)
  useEffect(
    () =>
      window.desktopApi?.onWorkbookRenamed?.((newName) => {
        setWorkbookFile((prev) => (prev ? { ...prev, name: newName } : prev))
      }) ?? (() => undefined),
    [],
  )

  // The sidecar process died, so every session id this tab holds is unknown
  // to the replacement. Record the crash: the next range read re-opens the
  // workbook through the normal open path and adopts a live session. Only an
  // actual process death reaches here — a session the app closed or swapped
  // on purpose is not a crash and must not re-open anything.
  useEffect(
    () =>
      window.desktopApi?.onSidecarCrashed?.(() => {
        noteSidecarCrash()
      }) ?? (() => undefined),
    [],
  )

  useEffect(() => {
    setVisualSelectionListener({
      select: (visual) =>
        setSelectedVisual((current) => (current?.id === visual.id ? current : visual)),
      deselect: () => setSelectedVisual(null),
    })
    setChartDialogListener((editKey, dialog) => setChartDialog({ kind: dialog, editKey }))
    setVisualCommandListener((command, visualId) => visualCommandRef.current(command, visualId))
    return () => {
      setVisualSelectionListener(null)
      setChartDialogListener(null)
      setVisualCommandListener(null)
    }
  }, [])

  // The format pane follows the chart selection; deselecting closes it.
  useEffect(() => {
    if (!selectedVisual) setChartDialog(null)
  }, [selectedVisual])

  // ── One-time migration: import legacy localStorage history into project-store ──
  useEffect(() => {
    const api = (window as Window & { projectApi?: typeof window.projectApi }).projectApi
    if (!api) return
    const raw = localStorage.getItem(CHAT_STORAGE_KEY)
    if (!raw) return
    try {
      const parsed: unknown = JSON.parse(raw)
      if (!Array.isArray(parsed) || parsed.length === 0) {
        localStorage.removeItem(CHAT_STORAGE_KEY)
        return
      }
      const msgs = parsed.filter(
        (
          e,
        ): e is {
          role: 'user' | 'assistant'
          text: string
          tools?: Array<{ summary: string; isError?: boolean }>
        } =>
          !!e &&
          typeof e === 'object' &&
          ((e as { role: string }).role === 'user' ||
            (e as { role: string }).role === 'assistant') &&
          typeof (e as { text: string }).text === 'string',
      )
      if (msgs.length === 0) {
        localStorage.removeItem(CHAT_STORAGE_KEY)
        return
      }
      // Get the default project's chatId (unsaved-0 marks the file-less default chat)
      const tempChatId = 'unsaved-legacy'
      void api
        .resolveChat({ filePath: null, tempChatId })
        .then(async (ids) => {
          for (const m of msgs) {
            const appendArgs: Parameters<typeof api.appendChat>[0] = {
              projectId: ids.projectId,
              chatId: ids.chatId,
              role: m.role,
              text: m.text,
            }
            if (m.tools && m.tools.length > 0) {
              appendArgs.tools = m.tools.map((t) => ({
                name: '',
                summary: t.summary,
                isError: !!t.isError,
              }))
            }
            await api.appendChat(appendArgs)
          }
          localStorage.removeItem(CHAT_STORAGE_KEY)
        })
        .catch(() => {
          // A failed migration doesn't affect normal use; retried on next launch
        })
    } catch {
      localStorage.removeItem(CHAT_STORAGE_KEY)
    }
  }, [])

  // ── project-store: resolve chatId and load history when a workbook opens ──
  useEffect(() => {
    const api = (window as Window & { projectApi?: typeof window.projectApi }).projectApi
    if (!api) return
    const continues = chatContinuesRef.current
    chatContinuesRef.current = false
    const previous = chatRefIdsRef.current
    const generation = ++chatResolveGenRef.current
    const stale = () => chatResolveGenRef.current !== generation
    // Reset (new workbook or new session)
    chatRefIdsRef.current = null
    if (!continues) setHistoricChat([])
    const tempChatId = `unsaved-${Date.now()}`
    const sessionId = workbookFile?.sessionId
    const resolveArgs: Parameters<typeof api.resolveChat>[0] = { filePath: null, tempChatId }
    if (sessionId !== undefined) resolveArgs.sessionId = sessionId
    void api
      .resolveChat(resolveArgs)
      .then(async (ids) => {
        if (continues) {
          // A save swapped the sidecar session under the same conversation:
          // the panel already shows every turn, so only re-point persistence.
          // A draft that just hit disk carries its unsaved-* transcript along.
          const bound =
            previous && previous.chatId !== ids.chatId && previous.chatId.startsWith('unsaved-')
              ? await api.rebindChat({
                  projectId: previous.projectId,
                  tempChatId: previous.chatId,
                  ...(sessionId !== undefined ? { sessionId } : { newChatId: ids.chatId }),
                })
              : ids
          if (!stale()) chatRefIdsRef.current = bound
          return
        }
        if (stale()) return
        chatRefIdsRef.current = ids
        const msgs = await api.loadChat({
          projectId: ids.projectId,
          chatId: ids.chatId,
          limit: 200,
        })
        if (stale() || msgs.length === 0) return
        setHistoricChat(
          msgs.map((m) => ({
            role: m.role,
            text: m.text,
            tools:
              m.tools?.map((t) => ({
                summary: t.summary,
                isError: !!t.isError,
                ...(t.name ? { name: t.name } : {}),
                ...(t.output ? { output: t.output.slice(0, 2000) } : {}),
              })) ?? [],
            // stored metadata only: no thumbnail read for history, the chips render name/size
            ...(m.attachments && m.attachments.length > 0
              ? {
                  attachments: m.attachments
                    .filter((a) => a.path)
                    .map((a) => ({
                      name: a.name,
                      path: a.path ?? '',
                      ext: a.ext ?? '',
                      sizeBytes: a.sizeBytes ?? 0,
                    })),
                }
              : {}),
            ...(m.scope ? { scope: m.scope } : {}),
          })),
        )
        // Restore model context: follow-ups after reopening the file continue the
        // previous conversation (only when the loop is idle and has no history)
        agentLoopRef.current?.restore(msgs.map((m) => ({ role: m.role, text: m.text })))
      })
      .catch(() => {
        /* silent */
      })
  }, [workbookFile?.sessionId])

  const persistChatMessage = (
    role: 'user' | 'assistant',
    text: string,
    tools?: Array<{
      name?: string
      summary: string
      isError?: boolean
      input?: string
      output?: string
    }>,
    attachments?: readonly AttachmentMeta[],
    scope?: AiScopeQuoteData,
  ): boolean => {
    // Reports whether a write was issued: right after a workbook opens the
    // chat refs resolve asynchronously, and a send in that window is dropped.
    const ids = chatRefIdsRef.current
    const api = (window as Window & { projectApi?: typeof window.projectApi }).projectApi
    if (!ids || !api) return false
    void api
      .appendChat({
        projectId: ids.projectId,
        chatId: ids.chatId,
        role,
        text,
        ...(tools && tools.length > 0
          ? { tools: tools.map((t) => ({ ...t, name: t.name ?? '' })) }
          : {}),
        ...(attachments && attachments.length > 0
          ? {
              attachments: attachments.map((a) => ({
                name: a.name,
                path: a.path,
                ext: a.ext,
                sizeBytes: a.sizeBytes,
              })),
            }
          : {}),
        ...(scope ? { scope } : {}),
      })
      .catch(() => {
        /* silent */
      })
    return true
  }

  function appendChat(entry: AiChatMessage): void {
    setChat((previous) => [...previous, entry])
  }

  function patchLastAssistant(patch: (entry: AiChatMessage) => AiChatMessage): void {
    setChat((previous) => {
      const index = previous.length - 1
      const last = previous[index]
      if (!last || last.role !== 'assistant') return previous
      const next = previous.slice()
      next[index] = patch(last)
      return next
    })
  }

  /** Tool activity for the whole run (args/output included, accumulated across
   * turns) — for full transcript persistence */
  const runToolsRef = useRef<
    Array<{ name: string; summary: string; isError?: boolean; input?: string; output?: string }>
  >([])
  /** tokens billed so far in the in-flight run (summed across turns) */
  const runUsageRef = useRef<AiTokenUsageView | undefined>(undefined)
  /** tokens billed across the session (the composer chip) */
  const [sessionUsage, setSessionUsage] = useState<AiTokenUsageView | undefined>(undefined)
  /** Last non-empty streamed text of the run: a final empty turn falls back to
   * it instead of wiping the model's own summary from the tool-call turn. */
  const runLastTextRef = useRef('')
  /** true once any tool of the run mutated the workbook */
  const runMutatedRef = useRef(false)

    const agentLoopRef = useRef<any>(null)
    if (!agentLoopRef.current) {
        agentLoopRef.current = {
            run: async () => { },
            stop: () => { },
            abort: () => { },
            cancel: () => { },
            reset: () => { },
        }
    }
 
  function isAgentConfigured(): boolean {
    const settings = aiSettingsRef.current
    if (!settings) return false
    const config = settings.providers[settings.provider]
    if (!config?.model) return false
    // Genspark's key never lands in the settings file; the main process injects
    // it from the gsk login state. When logged out, requests return an error
    // guiding sign-in — not intercepted here.
    return settings.provider === 'genspark' || !!config.apiKey
  }

  /** Image attachments read as base64 and sent multimodal with this user message
   * (≤5MB each, max 20; same structure as docs/slides) */
  const MAX_IMAGES_PER_MESSAGE = 20
  async function collectImageAttachments(atts: readonly AttachmentMeta[]): Promise<AgentImage[]> {
    const imageAtts = atts.filter((a) => ATTACHMENT_IMAGE_EXTS.has(a.ext))
    const images: AgentImage[] = []
    const failures: string[] = []
    for (const att of imageAtts.slice(0, MAX_IMAGES_PER_MESSAGE)) {
      const result = await window.desktopApi.readAttachmentImage(att.path)
      if (result.ok && result.base64 && result.mime) {
        images.push({ base64: result.base64, mime: result.mime })
      } else {
        failures.push(result.error ?? t('appAttachmentReadFailed', { name: att.name }))
      }
    }
    if (imageAtts.length > MAX_IMAGES_PER_MESSAGE) {
      failures.push(t('appTooManyImages', { max: MAX_IMAGES_PER_MESSAGE }))
    }
    if (failures.length > 0) {
      setAttachNotice(failures.join('；'))
      window.setTimeout(() => setAttachNotice(null), 5000)
    }
    return images
  }

  /** the attached skills' full text in front of the request; a skill that vanished is skipped */
  const withSkillBodies = async (instruction: string, names: readonly string[]) => {
    if (names.length === 0) return instruction
    const bodies = await Promise.all(
      names.map(async (name) => {
        try {
          return { name, body: await window.desktopApi.skillText(name) }
        } catch {
          return null
        }
      }),
    )
    return withAttachedSkills(
      instruction,
      bodies.filter((b): b is { name: string; body: string } => b !== null),
    )
  }

  function runAgent(
    instruction: string,
    sentAttachments: readonly AttachmentMeta[],
    sentSkills: readonly string[] = [],
  ): void {
    const loop = agentLoopRef.current
    if (!instruction.trim() || !loop || loop.busy || runStartingRef.current) return
    runStartingRef.current = true
    // Freeze the selection scope for the whole run: users go on clicking around
    // while the AI works, so a live read would retarget "this column" mid-run.
    // Released in onDone/onError, which own the rest of the run teardown.
    setAiRunScope(aiScopeDismissed ? null : aiScope)
    aiApplyPromisesRef.current = []
    runLastTextRef.current = ''
    runMutatedRef.current = false
    setAiBusy(true)
    setMessage(t('appAiThinking'))
    appendChat({ role: 'assistant', text: '', tools: [], streaming: true })
    void collectImageAttachments(sentAttachments)
      .then(async (images) => {
        const modelInstruction = await withSkillBodies(instruction, sentSkills)
        runStartingRef.current = false
        loop.run(modelInstruction, images)
      })
      .catch(async () => {
        // an unreadable image must not strand the run, nor drop the skills the user attached
        const modelInstruction = await withSkillBodies(instruction, sentSkills).catch(
          () => instruction,
        )
        runStartingRef.current = false
        loop.run(modelInstruction)
      })
  }

  const mergeAttachments = (result: AttachmentAddResult | null): void => {
    if (!result) return
    if (result.accepted.length > 0) {
      setAttachments((prev) => {
        const seen = new Set(prev.map((a) => a.path))
        return [...prev, ...result.accepted.filter((a) => !seen.has(a.path))]
      })
    }
    if (result.rejected.length > 0) {
      setAttachNotice(result.rejected.join('；'))
      window.setTimeout(() => setAttachNotice(null), 5000)
    }
  }

  async function handlePickAttachments(): Promise<void> {
    mergeAttachments(await window.desktopApi.pickAttachments())
  }

  async function handleAddAttachmentPaths(paths: readonly string[]): Promise<void> {
    if (paths.length === 0) return
    mergeAttachments(await window.desktopApi.addAttachmentPaths([...paths]))
  }

  async function handleAddPastedImage(data: ArrayBuffer, ext: string): Promise<void> {
    mergeAttachments(await window.desktopApi.addPastedImage(data, ext))
  }

  function handleRemoveAttachment(path: string): void {
    setAttachments((prev) => prev.filter((a) => a.path !== path))
  }

  function handleStopAgent(): void {
    agentLoopRef.current?.cancel()
  }

  /// A citation link in an AI answer ([B12](sheetnav://B12)): jump the grid to
  /// the cited cell or range through the same path the Name Box uses.
  function handleAiCitation(href: string): void {
    const ref = parseSheetNavHref(href)
    if (ref === null) return
    const error = goToReferenceImpl(dataToolsContext(), ref)
    if (error !== null) setMessage(error)
  }

  function handleNewChat(): void {
    agentLoopRef.current?.reset()
    setAiRunScope(undefined)
    setAiBusy(false)
    setChat([])
    setHistoricChat([])
    // Unsent composer attachments would otherwise ride into the next chat's
    // file context (availableAttachments merges sent + live) — same as docs
    // (#224) and slides. The typed draft itself is kept.
    setAttachments([])
    setAttachedSkills([])
    setAttachNotice(null)
    sentAttachmentsRef.current = []
    setPreview(null)
    lazyPreviewRef.current = null
    setMessage(t('appNewConversation'))
  }

  /** DSL context the AgentSkill reads/writes through — reuses the exact same
   * preview-then-apply path handlePlan/handleLazyPlan already exercise. */
  /** App-scope refs bundle for the extracted workbook readers (ai/workbook-readers.ts). */
  function readContext(): WorkbookReadContext {
    return { univerRef, lazyWorkbookRef, adapterRef, redactionIndexRef }
  }

  /**
   * The index the grid, the tint and the model all read.
   *
   * `redactionStatesRef` holds the marks in file coordinates — where the
   * reader put them, and where a save writes them. The grid is somewhere else
   * after this session's row and column edits, so the index is derived by
   * replaying the journal's structural ops rather than by moving the marks and
   * trying to move them back on undo. The journal is already how a streamed
   * viewport survives the same shift, and it cancels an insert/remove pair on
   * undo, so a mark follows the grid for free and returns with ⌘Z.
   */
    function rebuildRedactionIndex(): void {
        // AI 마스킹 및 인덱싱 완전 비활성화
        return
    }

    function getActiveSheetInfo(): ActiveSheetInfo {
  // 1순위: 실제 Univer 워크북 (탭에 보이는 시트와 항상 일치)
  const workbook = univerRef.current?.univerAPI?.getActiveWorkbook?.() ?? null

  if (workbook) {
    const worksheets = workbook.getSheets()
    const sheets = worksheets.map((ws) => ({
      id: ws.getSheetId(),
      name: ws.getSheetName(),
      sheet: ws,
    }))
    const active = workbook.getActiveSheet() ?? worksheets[0] ?? null
    return {
      sheetId: active?.getSheetId() ?? sheets[0]?.id ?? '',
      name: active?.getSheetName() ?? sheets[0]?.name ?? '',
      sheet: active,
      sheets,
    } as ActiveSheetInfo
  }

  // 2순위: Univer가 아직 준비되기 전이면 파일에서 읽은 시트 메타를 사용
  const fileSheets = lazyWorkbookRef.current?.file.sheets ?? []
  const sheets = fileSheets.map((s) => ({ id: s.id, name: s.name, sheet: null }))
  return {
    sheetId: sheets[0]?.id ?? '',
    name: sheets[0]?.name ?? '',
    sheet: null,
    sheets,
  } as ActiveSheetInfo
}

  /**
   * Re-derive the index whenever the grid's structure changes.
   *
   * A row inserted above a mark leaves it covering whatever shifted down into
   * its place, and the app looks right the whole time — the tint is drawn from
   * the mark — so the leak only appears in the saved file, on the next open, on
   * someone else's machine. The AI's own inserts are refused while a mark would
   * move (`ai/redact-guard.ts`); a person inserting a row from the grid is the
   * case no guard sees.
   */
  const watchStructuralEditsForMarks = (): void => {
    const api = univerRef.current?.univerAPI
    if (!api) return
    api.onCommandExecuted((command: { id?: string }) => {
      if (!command?.id || !STRUCTURAL_EDIT_COMMAND_PATTERN.test(command.id)) return
      rebuildRedactionIndex()
    })
  }

  /** Turn a grid right-click into either a dialog or an immediate clear. */
  function onRedactSelection(request: SelectionRequest) {
    const state = lazyWorkbookRef.current
    if (!state) return
    const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
    const sheetName = workbook?.getSheetBySheetId(request.sheetId)?.getSheetName()
    const intent = redactIntentFor(request, redactionIndexRef.current ?? NO_REDACTIONS, (id) =>
      workbook?.getSheetBySheetId(id)?.getSheetName(),
    )
    if (intent.kind === 'ignore') return
    if (intent.kind === 'clear') {
      // The tint was clicked on the grid, so what arrives is in screen
      // coordinates; the store keeps file coordinates. Same translation the
      // create path makes, so the two actually meet.
      const clearOps = lazyWorkbookRef.current?.editJournal.structuralOps.get(request.sheetId) ?? []
      const clearRow = screenToFile(clearOps, 'row', intent.mark.startRow)
      const clearEndRow = screenToFile(clearOps, 'row', intent.mark.endRow)
      const clearCol = screenToFile(clearOps, 'column', intent.mark.startColumn)
      const clearEndCol = screenToFile(clearOps, 'column', intent.mark.endColumn)
      // The same gesture that withheld it stops withholding it — one item, and
      // no second string in a locale set that must not grow.
      const marked =
        clearRow === null || clearEndRow === null || clearCol === null || clearEndCol === null
          ? undefined
          : redactionStatesRef.current
              .find((entry) => entry.sheetName === intent.sheetName)
              ?.marks.find(
                (mark) =>
                  mark.startRow === clearRow &&
                  mark.endRow === clearEndRow &&
                  mark.startColumn === clearCol &&
                  mark.endColumn === clearEndCol,
              )
      const next =
        clearRow === null || clearEndRow === null || clearCol === null || clearEndCol === null
          ? redactionStatesRef.current
          : clearMark(redactionStatesRef.current, intent.sheetName, {
              ...intent.mark,
              startRow: clearRow,
              endRow: clearEndRow,
              startColumn: clearCol,
              endColumn: clearEndCol,
            })
      redactionStatesRef.current = next
      rebuildRedactionIndex()
      // The tint is the only thing the mark ever did to the reader's own
      // formatting, so clearing has to take it back off.
      if (marked && workbook) {
        try {
          restoreCellFill(
            univerRef.current!,
            request.sheetId,
            workbook.getSheetBySheetId(request.sheetId)!.getRange(a1Of(intent.mark)) as never,
            marked.previousFill,
            workbook.getId(),
          )
        } catch {
          // A cell the grid will not hand out (filtered out, never loaded) is
          // not a reason to keep the mark; the mark is already gone.
        }
      }
      return
    }
    // A single cell offers its own text as the label, so the common case is
    // one word of typing; a range has no text and starts empty.
    let seed = ''
    if (request.isSingleCell) {
      try {
        seed =
          (
            workbook
              ?.getSheetBySheetId(request.sheetId)
              ?.getRange(`${columnLabel(request.startColumn)}${request.startRow + 1}`)
              .getValue() as string | undefined
          )?.slice(0, 24) ?? ''
      } catch {
        // An unreadable cell just means no seed offered.
      }
    }
    setRedactDialog({ ...intent.dialog, seed })
    if (sheetName === undefined) setRedactDialog(null)
  }

  /** Commit the label the reader typed. */
  function onRedactConfirm(label: string) {
    const pending = redactDialog
    setRedactDialog(null)
    if (!pending) return
    const clean = sanitizeLabel(label)
    if (!clean) return
    const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
    const worksheet = workbook?.getSheetBySheetId(pending.sheetId)
    // A mark is written into the package part, so it has to name the cell the
    // FILE has, not the one the grid is showing: this session may have
    // inserted rows above it that the file has never seen. `screenToFile`
    // answers null for a row inserted this session — it has no file coordinate
    // to write down — so the reader is told to save rather than handed a mark
    // the save would later shift a second time.
    const ops = lazyWorkbookRef.current?.editJournal.structuralOps.get(pending.sheetId) ?? []
    const startRow = screenToFile(ops, 'row', pending.startRow)
    const endRow = screenToFile(ops, 'row', pending.endRow)
    const startColumn = screenToFile(ops, 'column', pending.startColumn)
    const endColumn = screenToFile(ops, 'column', pending.endColumn)
    if (startRow === null || endRow === null || startColumn === null || endColumn === null) {
      showToast(t('redactNeedsSavedRow'), 'error')
      return
    }
    const inFile = { startRow, endRow, startColumn, endColumn }
    // buildMark reads the fill, paints the tint and returns both, so the mark
    // cannot be assembled without the value that has to be restored later. The
    // tint is drawn on the grid, so it takes the screen bounds.
    let mark: MarkKey & { label: string; previousFill: string | null } = {
      ...inFile,
      label: clean,
      previousFill: null,
    }
    try {
      if (worksheet) {
        mark = buildMark(worksheet, a1Of(pending), clean, {
          startRow: pending.startRow,
          endRow: pending.endRow,
          startColumn: pending.startColumn,
          endColumn: pending.endColumn,
        })
        // buildMark echoes the bounds it was handed; the stored copy is the
        // file-coord one, the painted one is the screen one.
        mark = { ...mark, ...inFile }
      }
    } catch {
      // A range the grid will not hand out still gets its mark; it just goes
      // unmarked on screen, which is the same state the reader is in anyway
      // for a sheet that has not finished streaming.
    }
    const next = addMark(redactionStatesRef.current, pending.sheetName, mark)
    redactionStatesRef.current = next
    // Not `indexFor(next, …)`: the states are in file coordinates now, and the
    // index the grid reads has to be the screen ones. The same replay the
    // loaded marks go through covers this one.
    rebuildRedactionIndex()
  }

  /** `A1:B2` for a mark's rectangle, for the range the tint is painted on. */
  function a1Of(area: {
    startRow: number
    endRow: number
    startColumn: number
    endColumn: number
  }): string {
    return (
      `${columnLabel(area.startColumn)}${area.startRow + 1}:` +
      `${columnLabel(area.endColumn)}${area.endRow + 1}`
    )
  }

  function sheetsSkillDeps(): SheetsSkillDeps {
    return {
      getActiveSheetInfo,
      aggregateRange: (sheetId, bounds) => aggregateWorkbookRange(readContext(), sheetId, bounds),
      ensureRangeLoaded: async (range, sheetId) => {
        const state = lazyWorkbookRef.current
        if (!state) return true
        // Fully-loaded workbooks (formula mode) have every cell in the grid.
        if (state.flags.preloadComplete) return true
        const runtime = univerRef.current
        const workbook = runtime?.univerAPI.getActiveWorkbook()
        const worksheet =
          sheetId === undefined ? workbook?.getActiveSheet() : workbook?.getSheetBySheetId(sheetId)
        if (!runtime || !worksheet) return false
        // A sheet added this session has no file part to stream from — the
        // grid already holds everything.
        if (!state.file.sheets.some((sheet) => sheet.id === worksheet.getSheetId())) return true
        // Anything reaching here genuinely streams; refuse blocks too large
        // to load in one request.
        if (rangeCellCount(range) > MAX_READ_RANGE_CELLS) return false
        return ensureLazyRangeLoaded(runtime, lazyWorkbookRef, worksheet, range, setMessage)
      },
      readCells: (addresses, sheetId) => readCellsImpl(readContext(), addresses, sheetId),
      readFormats: (addresses, sheetId) => readFormatsImpl(readContext(), addresses, sheetId),
      readSheetFeatures: (sheetId) => readSheetFeaturesImpl(readContext(), sheetId),
      findCells: (options) => findWorkbookCells(readContext(), options),
      selectRange: (sheetId, bounds) =>
        selectWorkbookRange(readContext(), sheetId, bounds, setMessage),
      tracePrecedents: (sheetId, address) =>
        traceWorkbookPrecedents(readContext(), sheetId, address),
      traceDependents: (sheetId, address) =>
        traceWorkbookDependents(readContext(), sheetId, address),
      redactions: () => redactionIndexRef.current ?? NO_REDACTIONS,
      proposeOperations,
      createDocument: (request) => createAiDocument({ univerRef, lazyWorkbookRef }, request),
    }
  }

  useEffect(() => {
    const loadSettings = () => void window.desktopApi.getAiSettings().then(setAiSettingsState)
    loadSettings()
    return window.desktopApi.onAiSettingsChanged?.(loadSettings)
  }, [])

  useEffect(() => {
    // Univer paints the grid on canvas, so it can't follow the CSS tokens —
    // mirror the canvas state into its official darkMode flag: an explicit
    // <html data-doc-theme> pin (genoffice#1811) wins, otherwise the <html data-theme>
    // state as before
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)')
    const isDarkTheme = () => {
      const docAttr = document.documentElement.getAttribute('data-doc-theme')
      if (docAttr === 'dark') return true
      if (docAttr === 'light') return false
      return (
        document.documentElement.getAttribute('data-theme') === 'dark' ||
        (!document.documentElement.hasAttribute('data-theme') && prefersDark.matches)
      )
    }
    const runtime = createUniver({
      // green selection/highlight instead of Univer's default blue
      theme: greenTheme,
      darkMode: isDarkTheme(),
      locale: LocaleType.EN_US,
      locales: {
        [LocaleType.EN_US]: mergeLocales(
          UniverPresetSheetsCoreEnUS,
          UniverPresetSheetsConditionalFormattingEnUS,
          UniverPresetSheetsFilterEnUS,
          UniverPresetSheetsDataValidationEnUS,
          UniverPresetSheetsNoteEnUS,
          UniverPresetSheetsFindReplaceEnUS,
          UniverPresetSheetsSortEnUS,
          UniverPresetSheetsTableEnUS,
          numberAsTextAlertLocale(UniverPresetSheetsCoreEnUS),
          // last wins per namespace: feed the alert-patched pack through so
          // both sheets-ui patches survive the shallow merge
          hideFromAiLocale(
            insertRowsBelowLocale(numberAsTextAlertLocale(UniverPresetSheetsCoreEnUS)),
            'en',
          ),
        ),
      },
      presets: [
        UniverSheetsCorePreset({
          container: 'univer-container',
          // header: true + toolbar: false renders only the name box + formula
          // bar (the Univer ribbon needs both flags).
          header: true,
          toolbar: false,
          contextMenu: true,
          formulaBar: true,
          footer: {
            sheetBar: true,
            statisticBar: true,
            menus: true,
            // zoom lives in the custom full-width status bar (unified with docs/slides)
            zoomSlider: false,
          },
          statusBarStatistic: true,
          // OOXML resolves style defaults as cell over row over column; the
          // render skeleton defaults to column-wins unless this flag is set.
          sheets: { isRowStylePrecedeColumnStyle: true },
        }),
        UniverSheetsDrawingPreset(),
        UniverSheetsConditionalFormattingPreset(),
        UniverSheetsFilterPreset(),
        UniverSheetsDataValidationPreset(),
        UniverSheetsNotePreset(),
        UniverSheetsFindReplacePreset(),
        UniverSheetsSortPreset(),
        UniverSheetsTablePreset(),
        // No floating table-name chip: its 32px gap above row-0 tables shifts
        // the grid vs Excel and strands the filter overlay at pre-gap coords.
        { plugins: [[UniverSheetsTableUIPlugin, { hideAnchor: true }]] },
      ],
    })
    // must precede the first render: the filter render module registers at
    // lifecycle Rendered, and Excel draws no outline around a filtered range
    installFilterRangeOutlineSuppression(runtime)
    installVeryHiddenSheetGuard(runtime, lazyWorkbookRef)
    loadSnapshotIntoUniver(runtime, initialSnapshot, 'new-workbook', 'Untitled')
    univerRef.current = runtime
    // The hidden spare can have a canvas/editor before Univer finishes booting.
    // Expose its lifecycle readiness only to explicitly enabled e2e drivers.
    if ((window as unknown as Record<string, unknown>).__genofficeDebugHooks === true) {
      ;(window as unknown as Record<string, unknown>).__genofficeSpareViewReady = () =>
        runtime.univerAPI.getCurrentLifecycleStage() ===
        runtime.univerAPI.Enum.LifecycleStages.Steady
    }
    // a throwing construction must not poison the injector's depth counter
    installInjectorResolutionGuard(runtime)
    // find-bar reveals share scrollToCell's broken freeze offset (r135)
    const findRevealDispose = installFindRevealFix(runtime)
    // the grid is sized to the data, so a blank sheet stops scrolling a few
    // columns past its last cell; this extends it ahead of the viewport
    const gridGrowthDispose = installGridGrowth(runtime)
    // Load-time wrap-row measures queue until Univer's auto-height
    // interceptor exists (lifecycle Rendered).
    const wrapMeasureDisposable = installWrapMeasureLifecycle(runtime)
    // live theme switching: main.tsx updates data-theme first (its listener
    // registered at bootstrap), so reading the attribute here is safe; the
    // matchMedia listener covers OS appearance flips while in system mode
    const themeService = runtime.univer.__getInjector().get(ThemeService)
    const applyUniverDark = () => {
      themeService.setDarkMode(isDarkTheme())
      crossHighlightRef.current?.refresh()
    }
    const offThemeChanged = window.desktopApi?.onThemeChanged?.(applyUniverDark)
    const offDocThemeChanged = window.desktopApi?.onDocumentThemeChanged?.(applyUniverDark)
    prefersDark.addEventListener('change', applyUniverDark)
    // Undo/redo stack occupancy: the QAT buttons grey out when there is nothing to apply
    const undoRedoService = runtime.univer.__getInjector().get(IUndoRedoService)
    const undoRedoSub = undoRedoService.undoRedoStatus$.subscribe(
      ({ undos, redos }: { undos: number; redos: number }) =>
        setUniverHist({ canUndo: undos > 0, canRedo: redos > 0 }),
    )
    // Programmatic installs (viewport streaming, file loads, merges, row
    // heights, notes, CF/filter rules) run through the same undoable commands
    // as user edits; they all raise journalSuppression, so drop their undo
    // entries there too — a freshly opened workbook starts with an empty
    // stack and undo can never strip loaded file content or layout.
    // The patch must live on the class prototype: the injector hands out a
    // lazy redi proxy, so assigning onto the resolved instance only shadows
    // the proxy — Univer-internal callers keep hitting the real method.
    installJournalSuppressionUndoFilter()
    // Opening a file must not re-measure row heights (Excel renders stored
    // heights verbatim), and clipped multi-line cells must show their FIRST
    // line like Excel does.
    installLoadAutoHeightGate()
    installBorderOverflowExclusionFix()
    installCfEmptySheetFastPath()
    installOtherFormulaAnchor()
    installCellClipAnchorFix()
    // Borders stored on a merged range's main cell must render their edge
    // segments like Excel; stock Univer drops them entirely.
    installMergeBorderFix()
    // Thick borders must read visibly heavier than medium ones like Excel;
    // stock Univer's 3px thick shares the footprint of its smeared 2px medium.
    installThickBorderFix()
    // Mixed-direction cell text (e.g. Arabic year suffixes) must follow
    // Excel's context reading order instead of always rendering ltr.
    installRtlTextDirectionFix()
    // sheetView rightToLeft="1": mirror the grid geometry (column A on the
    // right, headers on the right) while keeping logical indices.
    installRtlGridMirror()
    // Univer defines the right-to-left command/mutation pair but never
    // registers it; without this the View tab's toggle would silently no-op.
    installRightToLeftCommand(runtime)
    installRichTextBidiFix()
    // Excel's "Center Across Selection": center anchor text over its run of
    // blank same-format neighbors instead of folding it inside one cell.
    installCenterContinuousRender()
    installExcelFilterButton()
    // Paragraph-sized plain text cells: draw only the slice that can reach the
    // clip box instead of shaping the whole string every frame.
    installLongTextRender()
    // A whole-cell superscript/subscript (Home ribbon, or <vertAlign> in the
    // file) must draw raised/lowered; Univer's plain painter ignores `va`.
    installVertAlignRender()
    installAutofitWrapBudget()
    // Wrapped auto rows must stack Excel's per-font row height, not the
    // canvas line box (Calibri 10: 12.75 pt per line, not ~10 pt).
    installAutofitLinePitch()
    installHeaderUnhideDebounce()
    // The dashed border on a copied range is a per-frame animation. It must
    // not keep repainting the scene while nobody is looking at it.
    installCopyAnimationIdle()
    installNumberAsTextAlertSeverity()
    installForceStringMarkGate(runtime.univer.__getInjector().get(SheetInterceptorService))
    // Hold the formula engine's per-chunk recalculation while file data streams
    // in; one merged cycle follows once the chunks stop.
    installFormulaStreamHold(runtime)
    // The window always starts blank now; still consume the one-shot
    // new-blank flag so it doesn't leak into the next workbook open.
    void window.desktopApi?.consumeNewBlankWorkbook?.()
    // Pull any shell-queued workbook ourselves: the shell's 'open' nudge loop
    // gives up after 30s, and on slow dev cold starts Univer mounts later than
    // that — the tab would strand as a blank in-memory workbook (no save, no
    // shapes) with the queued file silently never opened.
    void window.desktopApi?.hasQueuedWorkbook?.().then((queued) => {
      if (queued) void handleInspectWorkbook()
    })
    // Univer 0.25.1 also badges text parseable as date/time, phone numbers, and
    // other long numeric identifiers with "Number stored as text". Those values
    // should remain text, so clear the view type before the built-in marker
    // interceptor (priority 10). Short numeric text ("007", "20%") keeps its
    // warning.
    const dateTextDisposable = runtime.univer
      .__getInjector()
      .get(SheetInterceptorService)
      .intercept(INTERCEPTOR_POINT.CELL_CONTENT, {
        priority: 11,
        effect: InterceptorEffectEnum.Style,
        handler: (cell, _position, next) => {
          if (cell?.t === CellValueType.STRING && typeof cell.v === 'string') {
            if (dateTextKind(cell.v) === 'date-like') return next({ ...cell, t: undefined })
          }
          return next(cell)
        },
      })
    // Copying in a filtered sheet must skip hidden rows;
    // see filtered-copy.ts for why the built-in hook is not enough.
    const filteredCopyDisposable = installFilteredCopyHook(runtime)
    // Excel-compatible TSV plain text (TRUE/FALSE, quoted newlines).
    const tsvClipboardDisposable = installTsvClipboardFix(runtime)
    // Formula view: swap formula cells to their formula text per sheet.
    const formulaViewDisposable = installFormulaViewInterceptor(runtime, lazyWorkbookRef)
    // Formula bar shows harvested formula text on streamed workbooks whose
    // closure gave up; display-only, the engine never sees it.
    const formulaTextDisposable = installFormulaTextInterceptor(runtime, lazyWorkbookRef)
    // The fx bar grows to fit a wrapped formula instead of clipping it.
    const formulaBarAutosizeDisposable = installFormulaBarAutosize(runtime)
    const fxButtonDisposable = installFxButtonHook(runtime)
    // A file formula the engine re-computes into an error shows the file's
    // cached result instead; display-only.
    const cachedValueDisposable = installCachedValueFallbackInterceptor(runtime, lazyWorkbookRef)
    // A wrapped formula result with CR/LF renders its line breaks.
    const formulaNewlineDisposable = installFormulaNewlineDisplay(runtime)
    // A file formula calling a function the engine lacks keeps its cached
    // value at install time — even when IFERROR/ISERROR would otherwise
    // swallow the #NAME? into the fallback literal.
    const functionProbeDisposable = installSupportedFunctionProbe(runtime)
    // Excel-parity number-format display: empty sections, text section,
    // _/* padding, General digit fitting, 1904 date-system serial shift.
    const numberFormatFixDisposable = installNumberFormatFix(
      runtime,
      () => lazyWorkbookRef.current?.file.date1904 === true,
    )
    const errorAlignDisposable = installErrorValueAlignment(runtime)
    // CELL("filename") resolves the session's on-disk path; converted
    // imports (needsSaveAs) count as never-saved, like Excel.
    const cellFilenameDisposable = installCellFilenameFunction(runtime, () => {
      const file = lazyWorkbookRef.current?.file
      // A CSV session's on-disk identity is the original .csv, not the
      // converted temp copy the session streams from.
      return file && !file.needsSaveAs ? (file.csvPath ?? file.path ?? null) : null
    })
    // RATE converges near -100% via bisection instead of erroring.
    const rateFallbackDisposable = installRateFallback(runtime)
    // MINIFS/MAXIFS over zero matching cells return 0, not blank.
    const ifsEmptySetDisposable = installIfsEmptySetFix(runtime)
    // Repeated *IF(S) '=' compares on text columns survive the inverted-
    // index cache when the criteria was number-coerced ("2026-06").
    const criteriaCompareCacheDisposable = installCriteriaCompareCacheFix()
    // Escaped quotes ("") no longer shift lexer indices and silently
    // rewrite committed formulas.
    const formulaLexerFixDisposable = installFormulaLexerFix(runtime)
    // Renaming a sheet to a case variant of itself is not a duplicate.
    const sheetRenameFixDisposable = installSheetRenameFix()
    // Arrow keys stop at the sheet edge instead of wrapping to the far side.
    const selectionWrapGuardDisposable = installSelectionWrapGuard(runtime)
    // Arrows on a multi-cell selection collapse to the active cell first,
    // then move one step (Excel), instead of stepping past the range edge.
    const arrowCollapseDisposable = installArrowCollapse(runtime)
    const sheetProtectionDisposable = installSheetProtectionGuard(runtime, {
      getState: () => lazyWorkbookRef.current,
      notify: (message) => {
        setMessage(message)
        showToast(message, 'error')
      },
    })
    const ctrlDragFillDisposable = installCtrlDragFill(runtime)
    // The grid's right-click item that withholds the selected cells from the
    // AI. Contributed to Univer's own menu rather than replacing it, so every
    // built-in item keeps working.
    const redactMenuDisposable = installRedactMenu(runtime, onRedactSelection)
    // A context-menu submenu re-hovered within Univer's close delay stays
    // invisible; re-trigger its positioning (genoffice#337).
    const contextSubmenuReopenDisposable = installContextSubmenuReopenFix()
    // Enter in a context-menu count box (insert N rows/columns, column
    // width) runs the row's action instead of only committing the number.
    installMenuInputEnter(runtime)
    const cellContextMenuDisposable = installCellContextMenu(runtime)
    // Pasting into an anchor-shaped target (rows a multiple, columns
    // narrower than the copy — or vice versa) repeats like Excel.
    installClipboardAnchorTile(runtime)
    // Row-header double-click autofits every selected row, like Excel.
    const multiRowAutofitDisposable = installMultiRowAutofit(runtime)
    const formatPainterDisposable = installFormatPainter(runtime, (active, turnedOff) => {
      setFormatPainterActive(active)
      if (turnedOff) setMessage('')
    })
    // Ctrl/Cmd+Arrow data-edge jumps must stop at formula cells even when
    // their values are empty strings or not yet materialized (cache mode).
    registerExcelJumpNav(runtime)
    // Ctrl+arrow (mac: Option) word jumps inside the cell editor / formula bar
    registerEditorWordJump(runtime)
    // Excel-standard keys Univer doesn't ship: worksheet-tab switching,
    // Ctrl+Home/End, Home, whole row/column selection. The used-end hint
    // covers streamed workbooks whose cell matrix is a loaded window.
    registerExcelShortcuts(
      runtime,
      (subUnitId) => {
        const state = lazyWorkbookRef.current
        if (!state) return null
        const sheet = state.file.sheets.find((candidate) => candidate.id === subUnitId)
        if (!sheet || sheet.rowCount <= 0 || sheet.columnCount <= 0) return null
        // positional mapping: an insert/delete moves the used end only when it
        // sits at or before it — a distant insert in the empty grid does not
        const ops = state.editJournal.structuralOps.get(subUnitId) ?? []
        const row = lastSurvivingScreenLine(ops, 'row', sheet.rowCount - 1)
        const column = lastSurvivingScreenLine(ops, 'column', sheet.columnCount - 1)
        return row !== null && column !== null ? { row, column } : null
      },
      setCellsDialog,
    )
    // Wide expression CF rules register folded/windowed formula ranges so
    // the engine stops rebuilding millions of per-cell dependency trees on
    // every stream-in recalculation (genoffice#158).
    const cfFormulaFoldDisposable = installCfFormulaFold(runtime)
    // duplicateValues / uniqueValues compare display text like Excel (1981233
    // and "1981233" are duplicates).
    const cfDisplayKeyDisposable = installCfDisplayKeyCompare(runtime)
    // Empty-value formula results (IFERROR/IF/CHOOSE over blank refs)
    // display as 0 like Excel.
    const nullResultDisposable = installFormulaNullResultFix(runtime)
    // Copy/cut load their selection into the lazy window first so streamed
    // workbooks don't serialize blanks for never-viewed rows.
    const copyMaterializeDisposable = installCopyMaterialize(runtime, lazyWorkbookRef, setMessage)
    statusBarStatsFilterRef.current = installStatusBarStatsFilter(
      runtime,
      () => statusBarFuncsRef.current,
    )
    // Footer statistics on streamed workbooks aggregate the real file, not
    // the loaded window (a whole-column count read 191 on a 185k-row file).
    const statusBarFileStatsDisposable = installStatusBarFileStats({
      runtime,
      lazyWorkbookRef,
      aggregate: (sheetId, bounds) =>
        aggregateWorkbookRange(readContext(), sheetId, bounds, { skipFileHiddenRows: true }),
    })
    // Validation dropdowns and input messages follow the active cell, matching Excel.
    const dataValidationChromeDisposable = installActiveCellDataValidationChrome(runtime)
    // Excel shows no invalid-data marker until Circle Invalid Data is run.
    const dataValidationMarkerDisposable = installInvalidDataMarkerSuppression(runtime)
    const threadedCommentDisposable = installThreadedCommentAffordances(runtime, {
      theme: () => (isDarkTheme() ? 'dark' : 'light'),
      onHover: setThreadHover,
    })
    threadStore.onChange = (sheetId) => {
      const state = lazyWorkbookRef.current
      if (!state) return
      recordNoteChange(state.editJournal, sheetId)
      setPendingEdits(journalSize(state.editJournal))
    }
    void window.desktopApi.getUserDisplayName?.().then((name) => threadStore.setAuthor(name))
    const offAuthorChanged = window.desktopApi.onUserDisplayNameChanged?.((name) =>
      threadStore.setAuthor(name),
    )
    // Univer's own UI (rule-management panels, dialogs) follows the app
    // language instead of hard-coded English.
    void applyUniverLocale(runtime, getLang())
    // Rule-management panels show what each rule actually does: list options /
    // source range, CF formula text, ⚠ on #REF! dead rules.
    const ruleDetailDisposable = installRuleDetail(runtime)
    // Ctrl+F covers every row of a streamed workbook, not just the loaded
    // window: the bridge pages the underlying file for out-of-window hits.
    const lazyFindDisposable = installLazyFindBridge({ runtime, lazyWorkbookRef, setMessage })
    // Replace mode searches as you type, like find mode, so Replace / Replace
    // All enable without a separate Find click.
    const replaceAutoSearchDisposable = installReplaceAutoSearch(
      runtime.univer.__getInjector().get(IFindReplaceService),
    )
    // Ctrl+F / Ctrl+H open the app's Excel-style Find & Replace panel; the
    // stock Univer dialog still mounts (it carries the session lifecycle) but
    // a styles.css rule keeps it invisible.
    setFindReplaceService(runtime.univer.__getInjector().get(IFindReplaceService))
    // A canvas extension highlights the active row and column without
    // allocating per-selection float DOM or covering interactive visuals.
    crossHighlightRef.current = installCrossHighlight(runtime, {
      theme: () => (isDarkTheme() ? 'dark' : 'light'),
    })
    const gutterHost = document.querySelector<HTMLElement>('.workbook-area')
    outlineGutterRef.current = gutterHost
      ? installOutlineGutter({
          runtime,
          host: gutterHost,
          state: () => lazyWorkbookRef.current,
          onToggleGroup: (axis, group, collapsed) =>
            toggleOutlineGroup(dataToolsContext(), axis, group, collapsed),
          onLevel: (axis, level) => showOutlineLevel(dataToolsContext(), axis, level),
        })
      : null
    const scrollDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.Scroll,
      (params) => {
        setAiSelectionAskAnchor(null)
        const { worksheet } = params
        // The event carries the true post-scroll position; getVisibleRange
        // inside loadVisibleRange lags a frame.
        const eventStart = params as { sheetViewStartRow?: number; sheetViewStartColumn?: number }
        void loadVisibleRange(
          runtime,
          lazyWorkbookRef,
          worksheet,
          setMessage,
          typeof eventStart.sheetViewStartRow === 'number' &&
            typeof eventStart.sheetViewStartColumn === 'number'
            ? { row: eventStart.sheetViewStartRow, column: eventStart.sheetViewStartColumn }
            : undefined,
        )
        let visible: ReturnType<typeof worksheet.getVisibleRange>
        try {
          visible = worksheet.getVisibleRange()
        } catch {
          // The lazy loader falls back to the top-left viewport while Univer
          // replaces its scroll controller; visual installation can wait.
          return
        }
        const viewportKey = visible
          ? `${worksheet.getSheetId()}:${visible.startRow}:${visible.endRow}:${visible.startColumn}:${visible.endColumn}`
          : worksheet.getSheetId()
        if (visualViewportKeyRef.current === viewportKey) return
        visualViewportKeyRef.current = viewportKey
        queueVisualInstall(
          runtime,
          lazyWorkbookRef,
          visualDisposablesRef,
          visualInstallTimerRef,
          chartEditRef,
          chartVectorRef,
          shapeEditRef,
        )
        queueSparklineInstall(runtime, lazyWorkbookRef, sparklineDisposablesRef, sparklineTimerRef)
      },
    )
    const zoomDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.SheetZoomChanged,
      ({ worksheet }) => {
        setAiSelectionAskAnchor(null)
        setZoomPercent(Math.round(worksheet.getZoom() * 100))
      },
    )
    // In-cell editor open/closed, read by the AutoSave tick: saving reloads
    // the workbook and would wipe an in-progress edit.
    // The main-process close guard only sees what the renderer reports, so an
    // open editor counts as one pending edit until it closes (its commit, if
    // any, then lands in the journal). Reported on open/close only — never per
    // keystroke.
    const syncCellEditorPending = (): void => {
      const state = lazyWorkbookRef.current
      window.desktopApi?.notifyPendingEdits?.(
        pendingEditsForClose(state ? journalSize(state.editJournal) : 0, editingCellRef.current),
      )
    }
    const editStartDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.SheetEditStarted,
      () => {
        editingCellRef.current = true
        syncCellEditorPending()
        setAiSelectionAskAnchor(null)
      },
    )
    const editEndDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.SheetEditEnded,
      () => {
        editingCellRef.current = false
        syncCellEditorPending()
      },
    )
    const sheetDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.ActiveSheetChanged,
      ({ activeSheet }) => {
        setAiSelectionAskAnchor(null)
        void loadVisibleRange(runtime, lazyWorkbookRef, activeSheet, setMessage)
        // formula view is per-sheet (sheetView/@showFormulas)
        applyShowFormulasView(runtime, lazyWorkbookRef.current, activeSheet.getSheetId())
        // zoom is per-sheet state; echo the new sheet's level
        setZoomPercent(Math.round(activeSheet.getZoom() * 100))
        refreshSelectionFormatRef.current()
        visualViewportKeyRef.current = ''
        if (!lazyWorkbookRef.current) {
          queueDemoVisualInstall(runtime)
        }
        queueVisualInstall(
          runtime,
          lazyWorkbookRef,
          visualDisposablesRef,
          visualInstallTimerRef,
          chartEditRef,
          chartVectorRef,
          shapeEditRef,
        )
        queueSparklineInstall(runtime, lazyWorkbookRef, sparklineDisposablesRef, sparklineTimerRef)
      },
    )
    const editDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.BeforeSheetEditStart,
      (event) => {
        const state = lazyWorkbookRef.current
        if (!state) return
        const sheetId = event.worksheet.getSheetId()
        const sheet = state.file.sheets.find((candidate) => candidate.id === sheetId)
        if (!sheet) return
        // Pivot output is baked into the worksheet; editing it would corrupt
        // the file's pivot semantics. Protected in every load mode.
        if (
          sheet.pivotRanges.some(
            (range) =>
              event.row >= range.startRow &&
              event.row <= range.endRow &&
              event.column >= range.startColumn &&
              event.column <= range.endColumn,
          )
        ) {
          event.cancel = true
          setMessage(t('appPivotCellNoEdit'))
          return
        }
        // Fully-loaded workbooks have nothing left to stream in.
        if (state.flags.preloadComplete) return
        // Editing a cell whose original content hasn't streamed in yet would
        // silently overwrite data the user never saw. Beyond the file's used
        // range every cell is genuinely empty, so those edits are safe — and
        // so are rows/columns inserted this session (journal-owned, nothing
        // streams into them). Bounds are screen-space: structural ops shift
        // the data extent.
        const ops = state.editJournal.structuralOps.get(sheetId) ?? []
        const beyondData =
          event.row >= sheet.rowCount + netAxisDelta(ops, 'row') ||
          event.column >= sheet.columnCount + netAxisDelta(ops, 'column')
        const journalOwned =
          ops.length > 0 &&
          (screenToFile(ops, 'row', event.row) === null ||
            screenToFile(ops, 'column', event.column) === null)
        const loaded = state.loadedRanges.get(sheetId)
        const inLoaded =
          loaded !== undefined &&
          event.row >= loaded.startRow &&
          event.row <= loaded.endRow &&
          event.column >= loaded.startColumn &&
          event.column <= loaded.endColumn
        const inFrozen =
          loaded !== undefined &&
          (event.row < (sheet.freeze?.frozenRows ?? 0) ||
            event.column < (sheet.freeze?.frozenColumns ?? 0))
        if (!beyondData && !journalOwned && !inLoaded && !inFrozen) {
          event.cancel = true
          setMessage(t('appAreaStreaming'))
        }
      },
    )
    const calcEndDisposable = runtime.univerAPI.getFormula().calculationEnd((executed) => {
      if (executed === FormulaExecutedStateType.SUCCESS) {
        flushPendingChartDataSync(visualSyncContext())
      }
    })
    const journalDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.CommandExecuted,
      (event) => {
        if (journalSuppression.active) return
        // The formula engine re-applies cached results with these execution
        // options; they are derived state, never user edits.
        const options = event.options as { fromFormula?: boolean } | undefined
        if (options?.fromFormula) return
        // The copy finished (or failed); a stale source must not claim a
        // later, unrelated insert-sheet.
        if (event.id === COPY_SHEET_COMMAND) {
          pendingCopySource = undefined
          return
        }
        const rowColumn = ROW_COLUMN_MUTATIONS[event.id]
        const merge = MERGE_MUTATIONS[event.id]
        const axisAttr = AXIS_ATTR_MUTATIONS[event.id]
        if (
          event.id !== SET_RANGE_VALUES_MUTATION &&
          event.id !== SET_NUMFMT_MUTATION &&
          event.id !== REMOVE_NUMFMT_MUTATION &&
          !rowColumn &&
          !merge &&
          !axisAttr &&
          !SHEET_LIFECYCLE_MUTATIONS.has(event.id) &&
          event.id !== REORDER_RANGE_MUTATION &&
          !FILTER_MUTATIONS.has(event.id) &&
          !CF_MUTATIONS.has(event.id) &&
          !DV_MUTATIONS.has(event.id) &&
          !DEFINED_NAME_MUTATIONS.has(event.id) &&
          !NOTE_MUTATIONS.has(event.id) &&
          event.id !== MOVE_RANGE_MUTATION &&
          event.id !== MOVE_ROWS_MUTATION &&
          event.id !== SET_FROZEN_MUTATION &&
          event.id !== TOGGLE_GRIDLINES_MUTATION &&
          event.id !== SET_RIGHT_TO_LEFT_MUTATION &&
          event.id !== SET_ZOOM_OPERATION &&
          event.id !== SET_ZOOM_COMMAND
        ) {
          return
        }
        const state = lazyWorkbookRef.current
        if (!state) {
          // Demo mode journals nothing, but chart↔data sync still applies.
          if (event.id === SET_RANGE_VALUES_MUTATION) {
            const demoParams = event.params as
              { subUnitId?: string; cellValue?: unknown } | undefined
            const bounds = cellValueBounds(demoParams?.cellValue)
            if (demoParams?.subUnitId && bounds) queueChartDataSync(demoParams.subUnitId, bounds)
          }
          return
        }
        const params = event.params as
          | {
              unitId?: string
              subUnitId?: string
              cellValue?: unknown
              range?: IRange
              ranges?: IRange[]
              order?: Record<number, number>
              name?: string
              sheet?: { id?: string; name?: string }
            }
          | undefined
        if (params?.unitId !== `file-${state.file.sha256}`) return
        if (SHEET_LIFECYCLE_MUTATIONS.has(event.id)) {
          if (event.id === 'sheet.mutation.insert-sheet') {
            const { id, name } = params.sheet ?? {}
            if (typeof id === 'string' && typeof name === 'string') {
              if (pendingCopySource !== undefined) {
                recordSheetDuplicate(state.editJournal, id, name, pendingCopySource)
                threadStore.copySheet(pendingCopySource, id)
                if (
                  lazySheetMeta(state, pendingCopySource) &&
                  !(state.formulaMode && state.flags.preloadComplete)
                ) {
                  state.streamAliases.set(id, pendingCopySource)
                  const resident = state.loadedRanges.get(pendingCopySource)
                  if (resident) state.loadedRanges.set(id, resident)
                  // The copy becomes active before this handler ran; its
                  // first viewport load found no meta and bailed.
                  setTimeout(() => {
                    if (lazyWorkbookRef.current !== state) return
                    const copy = runtime.univerAPI.getActiveWorkbook()?.getSheetBySheetId(id)
                    if (copy) void loadVisibleRange(runtime, lazyWorkbookRef, copy, setMessage)
                  }, 0)
                }
                pendingCopySource = undefined
              } else {
                recordSheetInsert(state.editJournal, id, name)
              }
            }
          } else if (event.id === 'sheet.mutation.remove-sheet') {
            if (typeof params.subUnitId === 'string') {
              recordSheetRemove(state.editJournal, params.subUnitId)
              threadStore.removeSheet(params.subUnitId)
            }
          } else if (event.id === 'sheet.mutation.set-worksheet-order') {
            recordSheetOrderChange(state.editJournal)
          } else if (event.id === 'sheet.mutation.set-worksheet-hidden') {
            const hidden = (params as { hidden?: number | boolean }).hidden
            if (typeof params.subUnitId === 'string' && hidden !== undefined) {
              const originallyHidden =
                state.file.sheets.find((sheet) => sheet.id === params.subUnitId)?.hidden ?? false
              recordSheetHidden(
                state.editJournal,
                params.subUnitId,
                hidden === true || hidden === 1,
                originallyHidden,
              )
            }
          } else if (event.id === 'sheet.mutation.set-tab-color') {
            if (typeof params.subUnitId === 'string') {
              recordSheetTabColor(
                state.editJournal,
                params.subUnitId,
                (params as { color?: unknown }).color,
                state.file.sheets.find((sheet) => sheet.id === params.subUnitId)?.tabColor,
              )
            }
          } else if (typeof params.subUnitId === 'string' && typeof params.name === 'string') {
            const originalName = state.file.sheets.find(
              (sheet) => sheet.id === params.subUnitId,
            )?.name
            // The live sync matches series refs against live sheet names, so
            // in-memory refs must follow the rename (the file's own c:f refs
            // are rewritten independently at save time).
            const previousName =
              state.editJournal.sheets.renamed.get(params.subUnitId) ??
              state.editJournal.sheets.added.get(params.subUnitId)?.name ??
              originalName
            recordSheetRename(state.editJournal, params.subUnitId, params.name, originalName)
            if (previousName !== undefined && previousName !== params.name) {
              renameChartRefsForSheet(state, previousName, params.name)
            }
          }
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        // Move-range carries its sheet ids inside from/to, not at top level.
        if (event.id === MOVE_RANGE_MUTATION) {
          const move = event.params as
            | {
                from?: { subUnitId?: string; value?: unknown }
                to?: { subUnitId?: string; value?: unknown }
                fromRange?: IRange
                toRange?: IRange
              }
            | undefined
          const fromSheet = move?.from?.subUnitId ?? params.subUnitId
          const toSheet = move?.to?.subUnitId ?? params.subUnitId
          const fromRange = move?.fromRange ?? matrixBounds(move?.from?.value)
          const toRange = move?.toRange ?? matrixBounds(move?.to?.value)
          if (fromSheet && fromRange) journalRangeSnapshot(runtime, state, fromSheet, fromRange)
          if (toSheet && toRange) journalRangeSnapshot(runtime, state, toSheet, toRange)
          if (fromSheet && fromRange && toSheet && toRange) {
            threadStore.moveRange(fromSheet, fromRange, toSheet, toRange)
          }
          // Moved cells feed charts too, same as value mutations.
          if (fromSheet && fromRange) queueChartDataSync(fromSheet, fromRange)
          if (toSheet && toRange) queueChartDataSync(toSheet, toRange)
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        // Workbook-level: defined-name mutations carry no subUnitId.
        if (DEFINED_NAME_MUTATIONS.has(event.id)) {
          recordDefinedNamesChange(state.editJournal)
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        // The sheets-note mutations name their sheet `sheetId`, not
        // `subUnitId` — they must be handled before the generic subUnitId
        // guard, which silently swallowed every note edit (notes changed on
        // screen but never reached the save).
        if (NOTE_MUTATIONS.has(event.id)) {
          const noteSheetId = (params as { sheetId?: string }).sheetId ?? params.subUnitId
          if (noteSheetId) {
            recordNoteChange(state.editJournal, noteSheetId)
            setPendingEdits(journalSize(state.editJournal))
          }
          return
        }
        if (!params.subUnitId) return
        if (axisAttr) {
          const attrParams = event.params as {
            ranges?: IRange[]
            rowHeight?: number | Record<number, number>
            colWidth?: number | Record<number, number>
            autoHeightInfo?: number | Record<number, number>
          }
          const uniform = axisAttr.axis === 'row' ? attrParams.rowHeight : attrParams.colWidth
          const toFileSize = (pixels: number): number =>
            axisAttr.axis === 'row'
              ? Math.round(pixels * 0.75 * 100) / 100
              : pixelsToCharacterWidth(pixels)
          for (const range of attrParams.ranges ?? []) {
            const start = axisAttr.axis === 'row' ? range.startRow : range.startColumn
            const end = axisAttr.axis === 'row' ? range.endRow : range.endColumn
            if (!Number.isInteger(start) || !Number.isInteger(end) || end < start) continue
            if (end - start >= 100_000) continue
            const sizeKind = axisAttr.axis === 'row' ? 'set-row-size' : 'set-col-size'
            if (axisAttr.kind === 'hidden') {
              recordStructuralOp(state.editJournal, params.subUnitId, {
                kind: axisAttr.axis === 'row' ? 'set-rows-hidden' : 'set-cols-hidden',
                start,
                end,
                hidden: axisAttr.hidden === true,
              })
            } else if (axisAttr.kind === 'auto-size') {
              // Setting an explicit height ALSO emits this mutation with
              // autoHeightInfo=0 (auto off) — only auto ON resets the height.
              const info = attrParams.autoHeightInfo
              if (typeof info === 'number') {
                if (info === 1) {
                  recordStructuralOp(state.editJournal, params.subUnitId, {
                    kind: sizeKind,
                    start,
                    end,
                    size: null,
                  })
                }
              } else if (info && typeof info === 'object') {
                for (let line = start; line <= end; line += 1) {
                  if (info[line] !== 1) continue
                  recordStructuralOp(state.editJournal, params.subUnitId, {
                    kind: sizeKind,
                    start: line,
                    end: line,
                    size: null,
                  })
                }
              }
            } else if (typeof uniform === 'number') {
              recordStructuralOp(state.editJournal, params.subUnitId, {
                kind: sizeKind,
                start,
                end,
                size: toFileSize(uniform),
              })
            } else if (uniform && typeof uniform === 'object') {
              // Per-line sizes (undo restores): one op per line in the range.
              for (let line = start; line <= end; line += 1) {
                const pixels = uniform[line]
                if (typeof pixels !== 'number') continue
                recordStructuralOp(state.editJournal, params.subUnitId, {
                  kind: sizeKind,
                  start: line,
                  end: line,
                  size: toFileSize(pixels),
                })
              }
            }
          }
          // Resizes and hidden lines move the automatic page boundaries.
          if (pageBreakLayersRef.current.has(params.subUnitId)) {
            installPageBreakLayers(params.subUnitId)
          }
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        if (FILTER_MUTATIONS.has(event.id)) {
          recordFilterChange(state.editJournal, params.subUnitId)
          if (
            event.id === 'sheet.mutation.set-filter-range' &&
            isLargeFilterSheet(state, params.subUnitId)
          ) {
            const worksheet = runtime.univerAPI
              .getActiveWorkbook()
              ?.getSheetBySheetId(params.subUnitId)
            if (worksheet) extendLargeFilterRange(runtime, state, worksheet)
          }
          if (event.id === 'sheet.mutation.remove-filter') {
            resetLargeFilter(state, params.subUnitId)
          }
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        if (CF_MUTATIONS.has(event.id)) {
          recordCfChange(state.editJournal, params.subUnitId)
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        if (DV_MUTATIONS.has(event.id)) {
          if (params.subUnitId) {
            recordDvChange(state.editJournal, params.subUnitId)
            setPendingEdits(journalSize(state.editJournal))
          }
          return
        }
        if (event.id === SET_FROZEN_MUTATION) {
          // Recording from the mutation (not the ribbon handler) keeps the
          // journal in step with Univer's undo/redo of the freeze.
          const freeze = event.params as
            { subUnitId?: string; ySplit?: number; xSplit?: number } | undefined
          if (freeze?.subUnitId && !isSheetRemoved(state.editJournal, freeze.subUnitId)) {
            recordPageSetup(state.editJournal, freeze.subUnitId, {
              frozenRows: Math.max(0, freeze.ySplit ?? 0),
              frozenColumns: Math.max(0, freeze.xSplit ?? 0),
            })
            setPendingEdits(journalSize(state.editJournal))
          }
          return
        }
        if (event.id === TOGGLE_GRIDLINES_MUTATION) {
          const gridlines = event.params as
            { subUnitId?: string; showGridlines?: number } | undefined
          if (
            gridlines?.subUnitId &&
            gridlines.showGridlines !== undefined &&
            !isSheetRemoved(state.editJournal, gridlines.subUnitId)
          ) {
            recordPageSetup(state.editJournal, gridlines.subUnitId, {
              showGridlines: gridlines.showGridlines === 1,
            })
            setPendingEdits(journalSize(state.editJournal))
          }
          return
        }
        if (event.id === SET_RIGHT_TO_LEFT_MUTATION) {
          // Journaling from the mutation (not the ribbon handler) keeps the
          // save in step with Univer's own undo/redo of the direction flip;
          // the rebuild also re-runs the mirrored viewport anchors, which
          // undo/redo dispatches without the command's render side effects.
          const rtl = event.params as { subUnitId?: string; rightToLeft?: number } | undefined
          if (
            rtl?.subUnitId &&
            rtl.rightToLeft !== undefined &&
            !isSheetRemoved(state.editJournal, rtl.subUnitId)
          ) {
            recordPageSetup(state.editJournal, rtl.subUnitId, {
              rightToLeft: rtl.rightToLeft === 1,
            })
            setPendingEdits(journalSize(state.editJournal))
          }
          refreshSheetRender(runtime)
          return
        }
        if (event.id === SET_ZOOM_OPERATION || event.id === SET_ZOOM_COMMAND) {
          // Excel persists the normal-view zoom in the file; without this the
          // save keeps the stored zoom and the post-save session reload snaps
          // the view back to it.
          const zoom = event.params as { subUnitId?: string; zoomRatio?: number } | undefined
          if (
            zoom?.subUnitId &&
            typeof zoom.zoomRatio === 'number' &&
            Number.isFinite(zoom.zoomRatio) &&
            !isSheetRemoved(state.editJournal, zoom.subUnitId)
          ) {
            recordPageSetup(state.editJournal, zoom.subUnitId, {
              zoomScale: Math.min(400, Math.max(10, Math.round(zoom.zoomRatio * 100))),
            })
            setPendingEdits(journalSize(state.editJournal))
          }
          return
        }
        if (event.id === REORDER_RANGE_MUTATION) {
          if (params.range) {
            journalRangeSnapshot(runtime, state, params.subUnitId, params.range, params.order)
            // Sorted cells feed charts too, same as value mutations.
            queueChartDataSync(params.subUnitId, params.range)
            setPendingEdits(journalSize(state.editJournal))
          }
          return
        }
        if (rowColumn || event.id === MOVE_ROWS_MUTATION) {
          let structuralOp: StructuralJournalOp
          if (rowColumn) {
            const range = params.range
            if (!range) return
            const index = rowColumn.axis === 'row' ? range.startRow : range.startColumn
            const count =
              rowColumn.axis === 'row'
                ? range.endRow - range.startRow + 1
                : range.endColumn - range.startColumn + 1
            if (count <= 0) return
            structuralOp = { kind: rowColumn.kind, index, count }
          } else {
            const move = event.params as { sourceRange?: IRange; targetRange?: IRange } | undefined
            if (!move?.sourceRange || !move.targetRange) return
            const index = move.sourceRange.startRow
            const count = move.sourceRange.endRow - move.sourceRange.startRow + 1
            const before = move.targetRange.startRow
            if (count <= 0 || (before >= index && before <= index + count)) return
            structuralOp = { kind: 'move-rows', index, count, before }
          }
          const structuralSheetId = params.subUnitId
          // Refs are matched by live sheet name (they follow renames).
          const structuralSheetName =
            runtime.univerAPI
              .getActiveWorkbook()
              ?.getSheetBySheetId(structuralSheetId)
              ?.getSheetName() ??
            state.file.sheets.find((sheet) => sheet.id === structuralSheetId)?.name
          // Undo of a filled insert (see below) must still cancel the insert:
          // drop the fill op so the inverse remove meets the insert itself.
          if (rowColumn && rowColumn.kind.startsWith('remove')) {
            const ops = state.editJournal.structuralOps.get(structuralSheetId)
            const fill = ops?.[ops.length - 1]
            const insert = ops?.[ops.length - 2]
            const rows = rowColumn.axis === 'row'
            if (
              fill &&
              insert &&
              'level' in fill &&
              fill.kind === (rows ? 'set-rows-outline' : 'set-cols-outline') &&
              'index' in insert &&
              insert.kind === (rows ? 'insert-rows' : 'insert-cols') &&
              insert.index === structuralOp.index &&
              insert.count === structuralOp.count &&
              fill.start === structuralOp.index &&
              fill.end === structuralOp.index + structuralOp.count - 1
            ) {
              ops.pop()
            }
          }
          recordStructuralOp(
            state.editJournal,
            structuralSheetId,
            structuralOp,
            structuralSheetName,
          )
          if (structuralOp.kind === 'move-rows') {
            const outline = sheetOutline(state, structuralSheetId)
            moveOutlineEntries(
              outline.rows,
              structuralOp.index,
              structuralOp.count,
              structuralOp.before,
            )
            outline.version += 1
          }
          if (rowColumn) {
            const outline = sheetOutline(state, structuralSheetId)
            const filled = shiftOutlineEntries(
              rowColumn.axis === 'row' ? outline.rows : outline.cols,
              structuralOp.index,
              rowColumn.kind.startsWith('insert') ? structuralOp.count : -structuralOp.count,
            )
            if (filled > 0) {
              recordStructuralOp(state.editJournal, structuralSheetId, {
                kind: rowColumn.axis === 'row' ? 'set-rows-outline' : 'set-cols-outline',
                start: structuralOp.index,
                end: structuralOp.index + structuralOp.count - 1,
                level: filled,
              })
            }
            outline.version += 1
          }
          threadStore.applyStructuralOp(structuralSheetId, structuralOp)
          // File visuals shift on-screen too (the save shifts the file's own
          // anchors and c:f refs independently); keeping the in-memory copy in
          // the new space keeps the preview and the live data sync honest.
          state.file.visuals.forEach((visual, at) => {
            state.file.visuals[at] = shiftVisualForStructuralOp(
              visual,
              structuralSheetId,
              structuralSheetName,
              structuralOp,
            )
          })
          refreshLazyVisuals(state)
          // Allow-edit ranges are kept in screen space; the page-break
          // overlay's boundaries moved with the rows/columns too.
          const protectedRanges = state.sheetProtectedRanges.get(structuralSheetId)
          if (protectedRanges && protectedRanges.length > 0) {
            state.sheetProtectedRanges.set(
              structuralSheetId,
              mapProtectedRanges(protectedRanges, [structuralOp]),
            )
          }
          if (pageBreakLayersRef.current.has(structuralSheetId)) {
            installPageBreakLayers(structuralSheetId)
          }
          // Univer shifted its installed cells itself, but the loaded-range
          // bookkeeping and frozen strip are now stale — refetch the viewport
          // through the updated coordinate mapping. Moves are exempt: they
          // are gated to fully loaded sheets, and the refetch would re-install
          // cells through undoable commands, burying the move's undo entry.
          if (structuralOp.kind !== 'move-rows') {
            state.loadedRanges.delete(params.subUnitId)
            state.frozenStripKeys.delete(params.subUnitId)
          }
          // Pinned closure values shift with the model; pinned formulas are
          // dropped — Univer rewrote their references in the model, so a
          // stale snapshot must not be re-applied after eviction.
          const pinnedClosure = state.closure.pinned.get(params.subUnitId)
          if (pinnedClosure && 'index' in structuralOp) {
            const shifted = shiftPinnedCells(pinnedClosure, structuralOp)
            for (const [key, cell] of [...shifted]) {
              if (cell.f !== undefined) shifted.delete(key)
            }
            state.closure.pinned.set(params.subUnitId, shifted)
          }
          // The recalc fallback reads the on-disk file; structural edits
          // desync every coordinate, so its overlays must not re-apply.
          state.recalc.overlay.clear()
          state.recalc.formulaCells.clear()
          const activeSheet = runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()
          if (activeSheet?.getSheetId() === params.subUnitId) {
            void loadVisibleRange(runtime, lazyWorkbookRef, activeSheet, setMessage)
          }
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        if (merge) {
          for (const range of params.ranges ?? []) {
            if (range.endRow < range.startRow || range.endColumn < range.startColumn) continue
            recordStructuralOp(state.editJournal, params.subUnitId, {
              kind: merge,
              range: {
                startRow: range.startRow,
                endRow: range.endRow,
                startColumn: range.startColumn,
                endColumn: range.endColumn,
              },
            })
          }
          setPendingEdits(journalSize(state.editJournal))
          return
        }
        // Copy-sheet batches a large source's cellData into follow-up chunk
        // mutations; the save clones the worksheet part, so journaling them
        // as edits would duplicate (and re-encode) content the clone covers.
        // A >20k-cell paste (and its undo/redo) splits into chunks with the
        // same flag but runs them as plain mutations; copy-sheet's real local
        // pass is the idle re-run, which carries onlyLocal.
        const chunkOptions = event.options as { onlyLocal?: boolean } | undefined
        if (
          (event.params as { __splitChunk__?: boolean } | undefined)?.__splitChunk__ &&
          chunkOptions?.onlyLocal
        ) {
          return
        }
        const recorded =
          event.id === SET_NUMFMT_MUTATION
            ? recordSetNumfmt(state.editJournal, params.subUnitId, params)
            : event.id === REMOVE_NUMFMT_MUTATION
              ? recordRemoveNumfmt(state.editJournal, params.subUnitId, params)
              : recordSetRangeValues(
                  state.editJournal,
                  params.subUnitId,
                  params.cellValue,
                  sharedFormulaResolverFor(runtime, params.subUnitId),
                )
        if (recorded.length === 0) return
        setPendingEdits(journalSize(state.editJournal))
        const contentEdited = recorded.some(
          (entry) => entry.hasValue || entry.formula !== undefined,
        )
        if (contentEdited) {
          const valueEntries = recorded.filter(
            (entry) => entry.hasValue || entry.formula !== undefined,
          )
          queueChartDataSync(params.subUnitId, {
            startRow: Math.min(...valueEntries.map((entry) => entry.row)),
            endRow: Math.max(...valueEntries.map((entry) => entry.row)),
            startColumn: Math.min(...valueEntries.map((entry) => entry.column)),
            endColumn: Math.max(...valueEntries.map((entry) => entry.column)),
          })
          // Sparkline values read live from the grid — re-render them too.
          if (
            state.editJournal.sparklineAdds.length > 0 ||
            state.file.sheets.some((sheet) => sheet.sparklines.length > 0)
          ) {
            queueSparklineInstall(
              runtime,
              lazyWorkbookRef,
              sparklineDisposablesRef,
              sparklineTimerRef,
            )
          }
        }
        if (
          !state.formulaMode &&
          contentEdited &&
          state.closure.status === 'unavailable' &&
          state.recalc.failures < RECALC_MAX_FAILURES
        ) {
          queueFormulaRecalc(runtime, lazyWorkbookRef, setMessage)
        } else if (
          !state.formulaMode &&
          state.closure.status !== 'active' &&
          recorded.some((entry) => entry.formula)
        ) {
          setMessage(t('appFormulaRecordedPartial'))
        }
      },
    )
    const structuralDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.BeforeCommandExecute,
      (event) => {
        const state = lazyWorkbookRef.current
        if (journalSuppression.active || !state) return
        if (event.id === SET_RANGE_VALUES_COMMAND || event.id === SET_RANGE_VALUES_MUTATION) {
          // Quadratic array-criteria formulas (distinct-count COUNTIF idioms
          // over 80k+ rows) freeze the main-thread formula engine for
          // minutes; block them at the edit gate. The AI path is rejected
          // earlier with a model-facing message — this covers typing, and the
          // mutation id covers paste/autofill, which apply mutations directly.
          // Engine-derived mutations (result apply, reference rewrites) carry
          // fromFormula and only restate formulas that already passed.
          const options = event.options as { fromFormula?: boolean } | undefined
          if (options?.fromFormula) return
          const params = event.params as
            { subUnitId?: string; value?: unknown; cellValue?: unknown } | undefined
          const formulas = collectCellFormulaTexts(params?.value ?? params?.cellValue)
          if (formulas.length > 0) {
            const subUnitId =
              params?.subUnitId ??
              runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
            const hostName =
              state.file.sheets.find((candidate) => candidate.id === subUnitId)?.name ?? ''
            const costSheets = state.file.sheets.map((candidate) => ({
              name: candidate.name,
              rows: candidate.rowCount,
              columns: candidate.columnCount,
            }))
            if (
              formulas.some(
                (formula) => quadraticFormulaError(formula, hostName, costSheets) !== null,
              )
            ) {
              event.cancel = true
              setMessage(t('appFormulaTooExpensive'))
            }
          }
          return
        }
        if (CF_RULE_COMMAND_PATTERN.test(event.id)) {
          // The Univer panel offers rules base OOXML cannot hold (x14-only
          // icon sets, date-occurring, equal/notEqual average, …); block them
          // here instead of failing the whole save later.
          const rule = (
            event.params as
              | {
                  rule?: { rule?: Record<string, unknown> & { type?: string; config?: unknown } }
                }
              | undefined
          )?.rule?.rule
          if (rule?.type === 'iconSet' && !iconSetSaveable(rule.config)) {
            event.cancel = true
            setMessage(t('appIconSetUnsupported'))
            return
          }
          if (rule && cfRuleUnsaveableReason(rule) !== null) {
            event.cancel = true
            setMessage(t('appCfRuleUnsaveable'))
          }
          return
        }
        if (STRUCTURAL_EDIT_COMMAND_PATTERN.test(event.id)) {
          // Row/column inserts/removals and merges are allowed in every load
          // mode: viewport reads translate screen ↔ file coordinates through
          // the journaled operation stream (view-transform.ts), and the save
          // replays the same stream against the file. Sheets carrying pivot
          // tables are the exception — a shift would desync the baked pivot
          // output from its definition.
          const subUnitId =
            (event.params as { subUnitId?: string } | undefined)?.subUnitId ??
            runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
          const sheet = state.file.sheets.find((candidate) => candidate.id === subUnitId)
          if (sheet && sheet.pivotRanges.length > 0) {
            event.cancel = true
            setMessage(t('appPivotSheetNoStructural'))
            return
          }
          // The save aborts when a formula references only the deleted span;
          // reject the removal up front like the AI path does (#1134). The
          // remove commands act on the selection unless a range is given.
          if (sheet && /^sheet\.command\.remove-(row|col)/.test(event.id)) {
            const uiWorkbook = runtime.univerAPI.getActiveWorkbook()
            const range =
              (event.params as { range?: IRange } | undefined)?.range ??
              uiWorkbook?.getActiveRange()?.getRange()
            if (range && uiWorkbook) {
              const removeOp = event.id.includes('remove-row')
                ? {
                    op: 'delete_rows' as const,
                    sheetId: sheet.id,
                    row: range.startRow + 1,
                    count: range.endRow - range.startRow + 1,
                  }
                : {
                    op: 'delete_cols' as const,
                    sheetId: sheet.id,
                    column: columnLabel(range.startColumn),
                    count: range.endColumn - range.startColumn + 1,
                  }
              if (structuralDeleteFormulaErrorSync(state, uiWorkbook, removeOp)) {
                event.cancel = true
                setMessage(t('appDeleteSpanFormulas'))
                return
              }
            }
          }
          return
        }
        if (
          SORT_COMMAND_PATTERN.test(event.id) ||
          FILTER_COMMAND_PATTERN.test(event.id) ||
          event.id === OPEN_FILTER_PANEL_OPERATION ||
          event.id === MOVE_RANGE_COMMAND ||
          event.id === MOVE_ROWS_COMMAND ||
          RANGE_SHIFT_COMMAND_PATTERN.test(event.id)
        ) {
          const subUnitId =
            (event.params as { subUnitId?: string } | undefined)?.subUnitId ??
            runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
          const isAddedSheet =
            subUnitId !== undefined && state.editJournal.sheets.added.has(subUnitId)
          const isFilter =
            FILTER_COMMAND_PATTERN.test(event.id) || event.id === OPEN_FILTER_PANEL_OPERATION
          // Filtering only hides rows, so it is safe on the complete data
          // even without live formulas — after a full preload it unlocks.
          // The panel itself is also gated: opened mid-stream it builds its
          // by-value counts from whatever happens to be loaded and reports
          // them as the column's content (24 rows of a value
          // whose real count was 125, 2 008 phantom blanks).
          if (isFilter && !isAddedSheet && !state.flags.preloadComplete) {
            event.cancel = true
            // A silent footer note read as "filtering is broken" — raise an
            // explicit offer to fully load instead.
            // Formula-mode workbooks preload automatically at open — the gate
            // only holds during that brief window. Any other running
            // preload (Load all, Print / PDF export) shows the same notice.
            const verdict = fullLoadGate({
              formulaMode: state.formulaMode,
              preloadRunning: state.flags.preloadRunning,
              cellCounts: workbookCellCounts(state.file.sheets),
            })
            if (verdict === 'workbookTooLarge' && subUnitId !== undefined) {
              // Past the budget the filter runs on column projections read
              // from the file (large-filter.ts); the panel opens as usual.
              installLargeFilterValues(runtime, lazyWorkbookRef, isLargeFilterSheet, (loading) =>
                setMessage(t(loading ? 'appLargeFilterLoading' : 'appReadyInitial')),
              )
              const worksheet = runtime.univerAPI.getActiveWorkbook()?.getSheetBySheetId(subUnitId)
              const action = worksheet ? largeFilterAction(event.id, event.params, worksheet) : null
              if (!action) {
                event.cancel = false
                return
              }
              event.cancel = true
              setMessage(t('appLargeFilterApplying'))
              void action(runtime, state)
                .then(() => {
                  setPendingEdits(journalSize(state.editJournal))
                  setMessage(t('appReadyInitial'))
                })
                .catch((error: unknown) => setMessage(String(error)))
              return
            }
            if (verdict === 'loading') setMessage(t('appFullLoadRunning'))
            else setFullLoadPrompt(verdict === 'offerFullLoad' ? 'ask' : 'tooLarge')
            return
          }
          if (!isFilter) {
            // move-rows journals as a structural op, not a cell snapshot
            const ranges =
              event.id === MOVE_ROWS_COMMAND
                ? []
                : reorderCommandRanges(
                    event.id,
                    event.params,
                    runtime.univerAPI.getActiveWorkbook()?.getActiveRange()?.getRange(),
                    subUnitId === undefined ? null : lazySheetScreenExtent(state, subUnitId),
                  )
            const verdict = reorderGate({
              formulaMode: state.formulaMode,
              preloadComplete: state.flags.preloadComplete,
              preloadRunning: state.flags.preloadRunning,
              isAddedSheet,
              cellCounts: workbookCellCounts(state.file.sheets),
              rangeCells: largestRangeCells(ranges),
              rangeHasStreamedFormulas: () =>
                subUnitId !== undefined && rangeHasStreamedFormulas(state, subUnitId, ranges),
            })
            if (verdict !== 'allow') {
              event.cancel = true
              if (verdict === 'loading') setMessage(t('appFullLoadRunning'))
              else if (verdict === 'offerFullLoad') setFullLoadPrompt('ask')
              else if (verdict === 'workbookTooLarge') setFullLoadPrompt('tooLarge')
              else if (verdict === 'valueModeFormulas') setMessage(t('appSortValueModeFormulas'))
              else setMessage(t('appSortRangeTooLarge'))
              return
            }
          }
          if (
            (event.id === MOVE_RANGE_COMMAND ||
              event.id === MOVE_ROWS_COMMAND ||
              RANGE_SHIFT_COMMAND_PATTERN.test(event.id)) &&
            state.file.sheets.find((candidate) => candidate.id === subUnitId)?.pivotRanges.length
          ) {
            event.cancel = true
            setMessage(t('appPivotSheetNoMove'))
            return
          }
          return
        }
        if (event.id === AUTO_FILL_COMMAND && !state.flags.preloadComplete) {
          const target = (event.params as { targetRange?: IRange } | undefined)?.targetRange
          const subUnitId =
            (event.params as { subUnitId?: string } | undefined)?.subUnitId ??
            runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
          const sheet = state.file.sheets.find((candidate) => candidate.id === subUnitId)
          const loaded = subUnitId === undefined ? undefined : state.loadedRanges.get(subUnitId)
          const ops =
            subUnitId === undefined ? [] : (state.editJournal.structuralOps.get(subUnitId) ?? [])
          const beyondRow = sheet === undefined ? 0 : sheet.rowCount + netAxisDelta(ops, 'row')
          const beyondColumn =
            sheet === undefined ? 0 : sheet.columnCount + netAxisDelta(ops, 'column')
          const covered =
            target !== undefined &&
            (target.startRow >= beyondRow ||
              target.startColumn >= beyondColumn ||
              (loaded !== undefined &&
                target.startRow >= loaded.startRow &&
                target.endRow <= loaded.endRow &&
                target.startColumn >= loaded.startColumn &&
                target.endColumn <= loaded.endColumn))
          if (!covered) {
            event.cancel = true
            setMessage(t('appAutofillStreaming'))
          }
          return
        }
        if (DV_EDIT_COMMAND_PATTERN.test(event.id)) {
          const subUnitId =
            (event.params as { subUnitId?: string } | undefined)?.subUnitId ??
            runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
          const isAddedSheet =
            subUnitId !== undefined && state.editJournal.sheets.added.has(subUnitId)
          // The save rewrites the whole section from Univer's model, so the
          // file's own rules must be in the model before any edit.
          if (!isAddedSheet && (subUnitId === undefined || !state.appliedDvSheets.has(subUnitId))) {
            event.cancel = true
            setMessage(t('appDvNeedsIndexed'))
          }
          return
        }
        if (STRUCTURE_LOCK_COMMANDS.has(event.id) && workbookStructureLocked(state)) {
          event.cancel = true
          setMessage(t('appWorkbookStructureLocked'))
          return
        }
        if (event.id === COPY_SHEET_COMMAND) {
          const subUnitId =
            (event.params as { subUnitId?: string } | undefined)?.subUnitId ??
            runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
          const isAddedSheet =
            subUnitId !== undefined && state.editJournal.sheets.added.has(subUnitId)
          // The Univer-side copy clones only the resident window of a
          // streamed source; the insert-sheet handler below aliases the copy
          // to its source so the rest streams in like any other sheet.
          const sheet = subUnitId === undefined ? undefined : lazySheetMeta(state, subUnitId)
          if (sheet && sheet.pivotRanges.length > 0) {
            event.cancel = true
            setMessage(t('appPivotSheetNoDuplicate'))
            return
          }
          // The save clones the worksheet part and fails closed on
          // sheet-scoped defined names — reject before the copy so the user
          // never sees Duplicate succeed and ⌘S fail. The sidecar flag covers
          // hidden and _xlnm.* built-ins the modeled definedNames omit
          // entirely; the scan remains as the older-sidecar fallback.
          const sourceIndex = state.file.sheets.findIndex((candidate) => candidate.id === sheet?.id)
          const scopedNames =
            sheet?.hasScopedDefinedNames ??
            (sourceIndex >= 0 &&
              (state.file.definedNames ?? []).some((name) => name.sheetIndex === sourceIndex))
          if (!isAddedSheet && scopedNames) {
            event.cancel = true
            setMessage(t('appDuplicateScopedNames'))
            return
          }
          if (subUnitId !== undefined) pendingCopySource = subUnitId
          return
        }
        if (BLOCKED_COMMAND_PATTERN.test(event.id)) {
          event.cancel = true
          setMessage(t('appMoveRowsColsUnsaved'))
        }
      },
    )
    // File-menu accelerators (⌘O/⌘S/⇧⌘S) arrive from the main process.
    const unsubscribeMenu =
      window.desktopApi?.onMenuAction((action) => menuActionRef.current(action)) ??
      (() => undefined)
    // Close guard chose Save: run the journal save and report the outcome.
    const unsubscribeCloseSave =
      window.desktopApi?.onCloseSaveRequest?.(() => void closeSaveRef.current()) ??
      (() => undefined)
    const gridHost = document.getElementById('univer-container')
    const disposePictureTransfer = gridHost
      ? installPictureTransfer(gridHost, {
          isCellEditing: () => editingCellRef.current,
          cellAtPoint: (x, y) => cellAtClientPoint(runtime, x, y),
          insert: (file, anchor) => handleInsertPictureFile(visualContext(), file, anchor),
        })
      : () => undefined
    // Double-click on a cell picture opens the viewer instead of the editor.
    const openCellImagePreview = (row: number, column: number): boolean => {
      const state = lazyWorkbookRef.current
      const worksheet = runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()
      if (!state || !worksheet) return false
      const sheetId = worksheet.getSheetId()
      const session = cellImageAddAt(state.editJournal, sheetId, row, column)
      if (session) {
        setViewImage(session.dataUrl)
        return true
      }
      const fileImage = state.file.sheets
        .find((sheet) => sheet.id === sheetId)
        ?.cellImages?.find((image) => image.row === row && image.column === column)
      if (!fileImage) return false
      void window.desktopApi
        .readWorkbookMedia({ sessionId: state.file.sessionId, visualId: fileImage.id })
        .then(async (media) => {
          const next = await workbookMediaDataUrl(media)
          if (next) setViewImage(next)
        })
        .catch((reason: unknown) => {
          console.warn(`cell picture preview unavailable (${fileImage.id})`, reason)
        })
      return true
    }
    const disposeCellImagePreview = gridHost
      ? installCellImagePreview(gridHost, {
          isCellEditing: () => editingCellRef.current,
          cellAtPoint: (x, y) => cellAtClientPoint(runtime, x, y),
          openPreview: openCellImagePreview,
        })
      : () => undefined
    const disposeWheelZoom = gridHost
      ? installWheelZoomSteps(gridHost, {
          isCellEditing: () => editingCellRef.current,
          getZoom: () => runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getZoom(),
          setZoom: (zoom) => {
            runtime.univerAPI.getActiveWorkbook()?.getActiveSheet()?.zoom(zoom)
          },
        })
      : () => undefined
    let selectionAskRaf: number | null = null
    let selectionAskSettleRaf: number | null = null
    let selectionAskSettling = false
    const activeRangeKey = (): string | null => {
      try {
        const range = runtime.univerAPI.getActiveWorkbook()?.getActiveRange()?.getRange()
        return range
          ? `${range.startRow}:${range.startColumn}:${range.endRow}:${range.endColumn}`
          : null
      } catch {
        return null
      }
    }
    const onSelectionPointerDown = (event: PointerEvent): void => {
      if (event.button !== 0 || gridHost?.classList.contains('sheet-shape-drawing')) return
      setAiSelectionAskAnchor(null)
      selectionDragRef.current = {
        start: { x: event.clientX, y: event.clientY },
        initialRangeKey: activeRangeKey(),
        dragged: false,
        selectionChanged: false,
      }
    }
    const onSelectionPointerMove = (event: PointerEvent): void => {
      const gesture = selectionDragRef.current
      if (!gesture || gesture.dragged) return
      gesture.dragged = isSelectionDrag(gesture.start, { x: event.clientX, y: event.clientY })
    }
    const finishSelectionPointer = (event: PointerEvent): void => {
      const gesture = selectionDragRef.current
      selectionDragRef.current = null
      if (!gesture?.dragged || event.type === 'pointercancel') return
      const pointer = { x: event.clientX, y: event.clientY }
      selectionAskSettling = true
      if (selectionAskRaf !== null) cancelAnimationFrame(selectionAskRaf)
      selectionAskRaf = requestAnimationFrame(() => {
        selectionAskRaf = null
        if (editingCellRef.current || !gridHost) {
          selectionAskSettling = false
          return
        }
        try {
          const bounds = runtime.univerAPI.getActiveWorkbook()?.getActiveRange()?.getRange()
          if (
            !bounds ||
            (bounds.endRow === bounds.startRow && bounds.endColumn === bounds.startColumn)
          ) {
            setAiSelectionAskAnchor(null)
            return
          }
          const finalRangeKey = activeRangeKey()
          if (!gesture.selectionChanged && finalRangeKey === gesture.initialRangeKey) return
          const viewport = gridHost.getBoundingClientRect()
          setAiSelectionAskAnchor({
            pointer,
            bounds: {
              left: viewport.left,
              top: viewport.top,
              right: viewport.right,
              bottom: viewport.bottom,
            },
          })
        } catch {
          setAiSelectionAskAnchor(null)
        } finally {
          if (selectionAskSettleRaf !== null) cancelAnimationFrame(selectionAskSettleRaf)
          selectionAskSettleRaf = requestAnimationFrame(() => {
            selectionAskSettleRaf = null
            selectionAskSettling = false
          })
        }
      })
    }
    const cancelSelectionPointer = (): void => {
      if (!selectionDragRef.current) return
      selectionDragRef.current = null
      setAiSelectionAskAnchor(null)
    }
    gridHost?.addEventListener('pointerdown', onSelectionPointerDown, true)
    window.addEventListener('pointermove', onSelectionPointerMove, true)
    window.addEventListener('pointerup', finishSelectionPointer, true)
    window.addEventListener('pointercancel', finishSelectionPointer, true)
    window.addEventListener('blur', cancelSelectionPointer)
    const selectionDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.SelectionChanged,
      () => {
        if (selectionDragRef.current) selectionDragRef.current.selectionChanged = true
        else if (!selectionAskSettling) setAiSelectionAskAnchor(null)
        refreshSelectionFormatRef.current()
        // A grid click ends any floating-visual selection.
        clearVisualSelection()
      },
    )
    // Style edits (ribbon, dialog, undo/redo, AI apply) all land as these
    // mutations; re-reading the selection keeps the ribbon echo current.
    const formatEchoDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.CommandExecuted,
      ({ id }) => {
        if (
          id === SET_RANGE_VALUES_MUTATION ||
          id === SET_NUMFMT_MUTATION ||
          id === REMOVE_NUMFMT_MUTATION
        ) {
          refreshSelectionFormatRef.current()
        }
      },
    )
    const clickDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.CellClicked,
      ({ worksheet, row, column }) => {
        const state = lazyWorkbookRef.current
        if (!state) return
        // A journaled link edit (set, changed, or removed) wins over the
        // file's streamed target.
        const journaled = hyperlinkEditAt(state.editJournal, worksheet.getSheetId(), row, column)
        const target =
          journaled !== undefined
            ? journaled
            : state.hyperlinkTargets.get(worksheet.getSheetId())?.get(`${row}:${column}`)
        if (target?.startsWith('http')) {
          void window.desktopApi.openExternal(target)
        } else if (target?.startsWith('#')) {
          navigateToAnchor(runtime, target.slice(1), setMessage)
        }
      },
    )
    // Track "any cell has content" for the ribbon's AI action buttons.
    // Mutations fire in bursts (paste, AI plans), so recompute on a short
    // trailing debounce; the scan itself early-exits on the first value.
    let contentTimer: ReturnType<typeof setTimeout> | null = null
    const contentDisposable = runtime.univerAPI.addEvent(
      runtime.univerAPI.Event.CommandExecuted,
      (event) => {
        if (!event.id.includes('mutation')) return
        if (contentTimer) clearTimeout(contentTimer)
        contentTimer = setTimeout(recomputeSheetContent, 200)
      },
    )
    return () => {
      unsubscribeMenu()
      unsubscribeCloseSave()
      offThemeChanged?.()
      offDocThemeChanged?.()
      offAuthorChanged?.()
      undoRedoSub.unsubscribe()
      findRevealDispose()
      gridGrowthDispose()
      wrapMeasureDisposable.dispose()
      prefersDark.removeEventListener('change', applyUniverDark)
      dateTextDisposable.dispose()
      filteredCopyDisposable.dispose()
      tsvClipboardDisposable.dispose()
      formulaViewDisposable.dispose()
      formulaTextDisposable.dispose()
      formulaBarAutosizeDisposable.dispose()
      fxButtonDisposable.dispose()
      cachedValueDisposable.dispose()
      formulaNewlineDisposable.dispose()
      functionProbeDisposable.dispose()
      numberFormatFixDisposable.dispose()
      errorAlignDisposable.dispose()
      cellFilenameDisposable.dispose()
      rateFallbackDisposable.dispose()
      ifsEmptySetDisposable.dispose()
      criteriaCompareCacheDisposable.dispose()
      formulaLexerFixDisposable.dispose()
      sheetRenameFixDisposable.dispose()
      selectionWrapGuardDisposable.dispose()
      arrowCollapseDisposable.dispose()
      sheetProtectionDisposable.dispose()
      ctrlDragFillDisposable.dispose()
      redactMenuDisposable.dispose()
      contextSubmenuReopenDisposable.dispose()
      multiRowAutofitDisposable.dispose()
      cellContextMenuDisposable.dispose()
      formatPainterDisposable.dispose()
      cfFormulaFoldDisposable.dispose()
      cfDisplayKeyDisposable.dispose()
      nullResultDisposable.dispose()
      copyMaterializeDisposable.dispose()
      statusBarFileStatsDisposable.dispose()
      statusBarStatsFilterRef.current?.dispose()
      statusBarStatsFilterRef.current = null
      dataValidationChromeDisposable.dispose()
      dataValidationMarkerDisposable.dispose()
      threadedCommentDisposable.dispose()
      threadStore.onChange = null
      ruleDetailDisposable()
      lazyFindDisposable.dispose()
      replaceAutoSearchDisposable.dispose()
      setFindReplaceService(null)
      crossHighlightRef.current?.dispose()
      crossHighlightRef.current = null
      outlineGutterRef.current?.dispose()
      outlineGutterRef.current = null
      scrollDisposable.dispose()
      zoomDisposable.dispose()
      editStartDisposable.dispose()
      editEndDisposable.dispose()
      sheetDisposable.dispose()
      editDisposable.dispose()
      calcEndDisposable.dispose()
      journalDisposable.dispose()
      structuralDisposable.dispose()
      selectionDisposable.dispose()
      formatEchoDisposable.dispose()
      clickDisposable.dispose()
      if (contentTimer) clearTimeout(contentTimer)
      contentDisposable.dispose()
      disposePictureTransfer()
      disposeCellImagePreview()
      disposeWheelZoom()
      gridHost?.removeEventListener('pointerdown', onSelectionPointerDown, true)
      window.removeEventListener('pointermove', onSelectionPointerMove, true)
      window.removeEventListener('pointerup', finishSelectionPointer, true)
      window.removeEventListener('pointercancel', finishSelectionPointer, true)
      window.removeEventListener('blur', cancelSelectionPointer)
      if (selectionAskRaf !== null) cancelAnimationFrame(selectionAskRaf)
      if (selectionAskSettleRaf !== null) cancelAnimationFrame(selectionAskSettleRaf)
      if (visualInstallTimerRef.current) clearTimeout(visualInstallTimerRef.current)
      disposeVisuals(visualDisposablesRef.current)
      visualViewportKeyRef.current = ''
      const lazyState = lazyWorkbookRef.current
      lazyWorkbookRef.current = null
      clearLazyState(lazyState)
      if (lazyState) {
        void window.desktopApi.closeWorkbook(lazyState.file.sessionId)
      }
      runtime.univer.dispose()
      univerRef.current = null
    }
  }, [])

  // Canvas render state lives outside React; mirror the toggle into it.
  useEffect(() => {
    crossHighlightRef.current?.setVisible(crossHighlightVisible)
  }, [crossHighlightVisible])

  function handleSend(
    overrideInstruction?: string,
    overrideAttachments?: readonly AttachmentMeta[],
    retryIndex?: number,
  ): void {
    const instruction = (overrideInstruction ?? prompt).trim()
    if (!instruction || aiBusy) return
    runToolsRef.current = []
    runUsageRef.current = undefined
    // The message consumes the composer attachments: they ride along (echoed on the
    // bubble, images multimodal, files via the files skill) and the composer clears.
    // Retry passes the failed message's original set instead.
    const sentAtts = overrideAttachments ?? attachmentsRef.current
    // skills ride with this one message only: the chips clear like attachments do
    const sentSkills = overrideInstruction ? [] : attachedSkillsRef.current
    if (sentSkills.length > 0) setAttachedSkills([])
    const agentConfigured = isAgentConfigured()
    // Retry re-sends in place: drop the failed bubble and its error reply instead
    // of stacking a "Not sent" duplicate above the resent copy.
    const alreadyPersisted = retryIndex !== undefined && chat[retryIndex]?.persisted === true
    if (retryIndex !== undefined) {
      setChat((previous) => pruneFailedExchange(previous, retryIndex))
    }
    // A retried message was usually persisted by its original send — but that
    // write is skipped while the chat refs are still resolving, so re-issue it
    // then instead of dropping the question from the stored transcript.
    // a retry quotes what the failed message quoted; a fresh send the live scope runAgent freezes for the run
    const scope =
      retryIndex !== undefined
        ? chat[retryIndex]?.scope
        : aiScope && !aiScopeDismissed
          ? { label: scopeLabel(aiScope.a1, aiScope.columns ?? null, t) }
          : undefined
    const persisted =
      alreadyPersisted || persistChatMessage('user', instruction, undefined, sentAtts, scope)
    appendChat({
      role: 'user',
      text: instruction,
      tools: [],
      persisted,
      ...(sentAtts.length > 0 ? { attachments: sentAtts } : {}),
      ...(sentSkills.length > 0 ? { skills: sentSkills } : {}),
      ...(scope ? { scope } : {}),
    })
    if (!overrideInstruction) setPrompt('')
    // the deterministic path consumes the composer too — the bubble already echoes the set
    if (!overrideAttachments && sentAtts.length > 0) {
      const seen = new Set(sentAttachmentsRef.current.map((a) => a.path))
      sentAttachmentsRef.current = [
        ...sentAttachmentsRef.current,
        ...sentAtts.filter((a) => !seen.has(a.path)),
      ]
      setAttachments([])
    }
    // real LLM configured → let the agent read context and propose operations;
    // otherwise fall back to the local, deterministic regex planner
    // (kept for offline use and for the fixed micro-DSL it still supports).
    if (agentConfigured) {
      runAgent(instruction, sentAtts, sentSkills)
      return
    }
    const outcome = runDeterministicPlan(instruction)
    setMessage(outcome.text)
    appendChat({ role: 'assistant', text: outcome.text, tools: [], isError: outcome.isError })
    persistChatMessage('assistant', outcome.text)
  }

  /// AI edits on imported workbooks preview against the live sheet, then
  /// apply through Univer commands so they enter the edit journal exactly
  /// like manual edits (and save with ⌘S).

  /// A generated workbook shouldn't keep the pristine default sheet: when an
  /// AI plan adds its own sheet(s) and never touches Sheet1, drop the empty
  /// leftover so the first sheet the user sees is the generated one.
  /// Returns the post-prune revision, or null when nothing was pruned.
  function pruneEmptyDefaultSheet(plan: ChangePlan): number | null {
    const addedSheet = plan.structuralChanges.some((change) => change.op.op === 'add_sheet')
    if (!addedSheet) return null
    const snapshot = adapterRef.current.getSnapshot()
    if (snapshot.sheets.length < 2) return null
    const defaultSheet = snapshot.sheets.find((sheet) => sheet.id === 'sheet-1')
    if (!defaultSheet || defaultSheet.name !== 'Sheet1') return null
    if (Object.keys(defaultSheet.cells).length > 0) return null
    if ((defaultSheet.visuals?.length ?? 0) > 0) return null
    const touched =
      plan.cellChanges.some((change) => change.sheetId === 'sheet-1') ||
      plan.formatChanges.some((change) => change.sheetId === 'sheet-1') ||
      plan.sheetRenames.some((rename) => rename.sheetId === 'sheet-1') ||
      plan.structuralChanges.some(
        (change) => 'sheetId' in change.op && change.op.sheetId === 'sheet-1',
      )
    if (touched) return null
    try {
      const prunePlan = adapterRef.current.plan({
        dslVersion: 1,
        transactionId: `prune-default-sheet-${crypto.randomUUID()}`,
        baseRevision: snapshot.revision,
        summary: 'Remove the empty default sheet',
        operations: [{ op: 'delete_sheet', sheetId: 'sheet-1' }],
      })
      return adapterRef.current.apply(prunePlan).revision
    } catch {
      // Best-effort cleanup: keep the empty sheet if the delete is rejected.
      return null
    }
  }

  /// Demo-mode counterpart of queueVisualInstall: charts live in the adapter
  /// snapshot, so every grid rebuild (Apply/undo) and sheet switch re-installs
  /// them from there.
  function queueDemoVisualInstall(runtime: UniverRuntime): void {
    if (demoVisualInstallTimerRef.current) clearTimeout(demoVisualInstallTimerRef.current)
    demoVisualInstallTimerRef.current = setTimeout(function install() {
      demoVisualInstallTimerRef.current = null
      if (lazyWorkbookRef.current) return
      // Fire-time rendered sheet — an enqueue-time snapshot can go stale
      // while the timer pends and would leave stale floats painted.
      const sheetId = resolveRenderedSheetId(runtime)
      if (!sheetId) return
      if (isVisualDragActive()) {
        demoVisualInstallTimerRef.current = setTimeout(install, 100)
        return
      }
      disposeVisuals(demoVisualDisposablesRef.current)
      const visuals = adapterRef.current
        .getSnapshot()
        .sheets.flatMap((sheet) => sheet.visuals ?? [])
      demoVisualDisposablesRef.current =
        visuals.length === 0
          ? []
          : installWorkbookVisuals(
              runtime,
              { sessionId: 'demo-workbook', visuals },
              sheetId,
              {
                edits: EMPTY_CHART_EDITS,
                onEdit: (editKey, edit) => chartEditRef.current(editKey, edit),
                readVector: (editKey, range) => chartVectorRef.current(editKey, range),
              },
              { onEdit: (visualId, changes) => shapeEditRef.current(visualId, changes) },
            )
    }, 100)
  }

  function queueDemoVisualInstallForActiveSheet(): void {
    const runtime = univerRef.current
    if (runtime) queueDemoVisualInstall(runtime)
  }

  /** Default worksheet names carry no content signal, so they never name the file. */
  const DEFAULT_SHEET_NAME_RE = /^(sheet|工作表|ワークシート|シート)\s*\d*$/i

  /** Waits for every plan submitted during one AI run, then persists all
   * successful writes in one save. A canceled/failed Save As leaves both the
   * journal and inline undo available. */
  async function autoSaveCompletedAiRun(): Promise<void> {
    const applies = aiApplyPromisesRef.current
    aiApplyPromisesRef.current = []
    if (applies.length === 0) return
    const results = await Promise.all(applies)
    if (!results.some(Boolean)) return
    const state = lazyWorkbookRef.current
    if (!state || journalSize(state.editJournal) === 0) return
    // AutoSave off = the user decides when the file is written: the
    // run's edits stay pending in the journal, so the offered Undo / ⌘Z keeps
    // working (saving would reopen the session and reset the undo stack).
    if (!autoSaveRef.current) {
      setMessage(t('appAiChangesNotSaved'))
      return
    }
    // AutoSave-driven write after an AI run: silent like the interval autosave.
    await handleSave('save', true)
    const after = lazyWorkbookRef.current
    if (after && journalSize(after.editJournal) === 0) {
      // Saving reopens the sidecar session and resets Univer's undo stack.
      patchLastAssistant(({ autoApplied: _autoApplied, ...entry }) => entry)
      // Sheets' analog of slides' deckName: propose the first AI-named sheet as
      // the file name. The main process no-ops unless the file still carries the
      // shell's auto-created untitled name, so user-chosen names are never touched.
      const candidate = after.file.sheets
        .map((sheet) => sheet.name.trim())
        .find((name) => name.length > 0 && !DEFAULT_SHEET_NAME_RE.test(name))
      if (candidate) {
        try {
          await window.desktopApi.autoRenameWorkbook(after.file.sessionId, candidate)
        } catch {
          // naming is best-effort; the save itself already succeeded
        }
      }
    }
  }

  /**
   * Auto-apply a just-proposed plan without the manual Apply click.
   *
   * All plans (content, format, and structural) commit immediately for a
   * smoother, Google-Sheets-like flow — AI edits share the ribbon's command
   * channel + edit journal, so undo (⌘Z / inline button) covers everything.
   *
   * The CAS/planStillMatches guards inside plan()/handleLazyApply are preserved
   * — auto-apply never bypasses the "workbook changed since preview" check.
   * When apply fails, the preview card stays up as a manual fallback.
   */
  async function autoApplySafePlan(plan: ChangePlan): Promise<ApplyOutcome> {
    if (!(await commitActiveEditor())) {
      return { ok: false, reason: t('appApplyTxFailed') }
    }
    const opCount =
      plan.cellChanges.length +
      plan.formatChanges.length +
      plan.sheetRenames.length +
      plan.structuralChanges.length
    const state = lazyWorkbookRef.current
    if (state) {
      const undoDepthBefore = undoStackDepth(univerRef.current)
      // Lazy path reads lazyPreviewRef (a ref, already set by the caller) —
      // safe to invoke synchronously right after propose.
      const apply = handleLazyApply(state).then((outcome) => {
        if (outcome.ok) {
          const undoSteps = Math.max(0, undoStackDepth(univerRef.current) - undoDepthBefore)
          // Patch last assistant message with inline undo button.
          patchLastAssistant((entry) => ({
            ...entry,
            autoApplied: {
              opCount: (entry.autoApplied?.opCount ?? 0) + opCount,
              undoSteps: (entry.autoApplied?.undoSteps ?? 0) + undoSteps,
            },
          }))
        } else {
          // No manual-apply entry point: the failure reason is already in the
          // chat/status bar, and the preview card just collapses.
          lazyPreviewRef.current = null
          setPreview(null)
        }
        return outcome
      })
      aiApplyPromisesRef.current.push(apply.then((outcome) => outcome.ok))
      return apply
    }
    // Non-lazy path: apply the passed plan directly (setPreview is async, so we
    // cannot rely on the preview state within the same tick).
    try {
      const receipt = adapterRef.current.apply(plan)
      const prunedRevision = pruneEmptyDefaultSheet(plan)
      // Row/column shifts and new sheets can't be patched cell-by-cell into
      // the existing Univer grid — rebuild the demo workbook from the snapshot.
      if (plan.structuralChanges.length > 0 || prunedRevision !== null) {
        loadSnapshotIntoUniver(
          univerRef.current,
          adapterRef.current.getSnapshot(),
          'new-workbook',
          'Untitled',
        )
        queueDemoVisualInstallForActiveSheet()
      } else {
        // Keep these programmatic writes off Univer's undo stack entirely:
        // on blank workbooks the adapter owns AI-revision history (plans are
        // built and validated against its snapshot), so undo must go through
        // adapter.undo() as one step. A Univer-level undo item would revert
        // the grid but leave the adapter unreverted — the next apply's
        // full-snapshot syncUniver would then resurrect the undone content.
        journalSuppression.active = true
        try {
          syncUniver(univerRef.current, adapterRef.current.getSnapshot())
          const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
          for (const formatChange of plan.formatChanges) {
            const worksheet = workbook?.getSheetBySheetId(formatChange.sheetId)
            if (worksheet)
              applyFormatPatchToRange(worksheet.getRange(formatChange.range), formatChange.format)
          }
        } finally {
          journalSuppression.active = false
        }
        // The CommandExecuted chart↔data sync listener is gated on
        // journalSuppression, so re-queue the sync for the cells this plan
        // actually changed.
        const chartSyncBounds = new Map<string, CellBounds>()
        for (const change of plan.cellChanges) {
          const cell = parseAddress(change.address)
          const bounds = chartSyncBounds.get(change.sheetId)
          if (bounds) {
            bounds.startRow = Math.min(bounds.startRow, cell.row)
            bounds.endRow = Math.max(bounds.endRow, cell.row)
            bounds.startColumn = Math.min(bounds.startColumn, cell.column)
            bounds.endColumn = Math.max(bounds.endColumn, cell.column)
          } else {
            chartSyncBounds.set(change.sheetId, {
              startRow: cell.row,
              endRow: cell.row,
              startColumn: cell.column,
              endColumn: cell.column,
            })
          }
        }
        for (const [sheetId, bounds] of chartSyncBounds) queueChartDataSync(sheetId, bounds)
      }
      const revision = prunedRevision ?? receipt.revision
      setRevision(revision)
      setPreview(null)
      setMessage(t('appAppliedRevision', { revision }))
      // Patch last assistant message to show inline undo button.
      patchLastAssistant((entry) => ({
        ...entry,
        autoApplied: {
          opCount: (entry.autoApplied?.opCount ?? 0) + opCount,
          undoSteps: (entry.autoApplied?.undoSteps ?? 0) + 1,
        },
      }))
      return Promise.resolve({ ok: true })
    } catch (error: unknown) {
      // Fall back to leaving the preview up so the user can Apply manually.
      const reason = error instanceof Error ? error.message : t('appApplyTxFailed')
      setMessage(reason)
      return Promise.resolve({ ok: false, reason })
    }
  }

  async function handleLazyApply(state: LazyWorkbookState): Promise<ApplyOutcome> {
    const stored = lazyPreviewRef.current
    const runtime = univerRef.current
    if (!stored || !runtime) return { ok: false, reason: t('appApplyTxFailed') }
    if (stored.sessionId !== state.file.sessionId) {
      lazyPreviewRef.current = null
      setPreview(null)
      setMessage(t('appPreviewOtherWorkbook'))
      return { ok: false, reason: t('appPreviewOtherWorkbook') }
    }
    const workbook = runtime.univerAPI.getActiveWorkbook()
    const worksheet = workbook?.getSheetBySheetId(stored.sheetId)
    if (!workbook || !worksheet) {
      lazyPreviewRef.current = null
      setPreview(null)
      setMessage(t('appPreviewSheetGone'))
      return { ok: false, reason: t('appPreviewSheetGone') }
    }
    const reportFailure = (reason: string): void => {
      // The chat answer already promised the change — surface the failure
      // there too, or it silently never lands on the canvas.
      patchLastAssistant((entry) =>
        entry.text.includes(reason)
          ? entry
          : {
              ...entry,
              text: `${entry.text}\n\n${t('appApplyFailed', { reason })}`,
              isError: true,
            },
      )
    }
    let verified: ApplyOutcome | null = null
    const outcome = await applyChangePlan(
      stored.plan,
      opExecutorContext(runtime, workbook, state),
      {
        verifyBeforeApply: () => {
          if (lazyPreviewRef.current !== stored || lazyWorkbookRef.current !== state) {
            verified = { ok: false, reason: t('appApplyTxFailed') }
            return verified
          }
          // The reader throws when a planned sheet no longer exists — treat that as
          // drift too (the plan can no longer apply as previewed).
          let stillMatches: boolean
          try {
            stillMatches = planStillMatches(stored.plan, lazyWorkbookCellReader(workbook))
          } catch {
            stillMatches = false
          }
          if (stillMatches) return null
          const reason = t('appWorkbookChangedSincePreview')
          setMessage(reason)
          reportFailure(reason)
          verified = { ok: false, reason }
          return verified
        },
      },
    )
    if (outcome.ok) {
      lazyPreviewRef.current = null
      setPreview(null)
    } else if (outcome !== verified && outcome.reason) {
      reportFailure(outcome.reason)
    }
    return outcome
  }

  /** Ribbon/dialog edits run the same executor as AI proposals (op-executor.ts). */
  function runUiOps(
    ops: readonly WorkbookOperation[],
    successMessage?: string | null,
  ): Promise<ApplyOutcome> {
    const runtime = univerRef.current
    const state = lazyWorkbookRef.current
    const workbook = runtime?.univerAPI.getActiveWorkbook()
    if (!runtime || !state || !workbook) {
      return Promise.resolve({ ok: false, reason: t('appNoWorkbookOpen') })
    }
    let plan: ChangePlan
    try {
      plan = planFromOps(ops, workbook, 'ribbon')
    } catch (error: unknown) {
      const reason = error instanceof Error ? error.message : t('appApplyTxFailed')
      setMessage(reason)
      return Promise.resolve({ ok: false, reason })
    }
    return applyChangePlan(plan, opExecutorContext(runtime, workbook, state), {
      userFacing: true,
      ...(successMessage === undefined ? {} : { successMessage }),
      // The apply queues behind in-flight applies; the file may be closed or
      // replaced meanwhile — drop the click silently rather than mutate the
      // wrong workbook.
      verifyBeforeApply: () =>
        lazyWorkbookRef.current !== state ||
        univerRef.current !== runtime ||
        runtime.univerAPI.getActiveWorkbook()?.getId() !== workbook.getId()
          ? { ok: false, reason: t('appApplyTxFailed') }
          : null,
    })
  }

  /** App-scope refs/state bundle for the extracted op executors (op-executor.ts). */
  function opExecutorContext(
    runtime: UniverRuntime,
    workbook: ActiveWorkbook,
    state: LazyWorkbookState,
  ): OpExecutorContext {
    return {
      runtime,
      workbook,
      state,
      lazyWorkbookRef,
      sparklineDisposablesRef,
      sparklineTimerRef,
      shapeEditRef,
      chartEditRef,
      setMessage,
      setPendingEdits,
      visualContext,
      pivotContext,
      queueChartDataSync,
    }
  }

  function handleUndo(steps?: number): void {
    const count =
      typeof steps === 'number' && Number.isFinite(steps) ? Math.max(1, Math.floor(steps)) : 1
    const fromAiBatch = typeof steps === 'number'
    const clearInlineUndo = () => {
      if (!fromAiBatch) return
      patchLastAssistant(({ autoApplied: _autoApplied, ...entry }) => entry)
    }
    // Mirror ⌘Z: interactive grid edits live on Univer's undo stack even in a
    // blank in-memory workbook, so drain that stack first; the adapter's
    // revision history (AI plan applies) is the fallback once it is empty.
    if (lazyWorkbookRef.current || univerHist.canUndo) {
      const api = univerRef.current?.univerAPI
      if (!api) return
      void (async () => {
        for (let step = 0; step < count; step += 1) await api.undo()
        clearInlineUndo()
      })()
      return
    }
    try {
      let receipt = adapterRef.current.undo()
      for (let step = 1; step < count; step += 1) receipt = adapterRef.current.undo()
      // Rebuild instead of patching: undo can remove cells and reverse
      // structural changes, neither of which syncUniver can express.
      loadSnapshotIntoUniver(
        univerRef.current,
        adapterRef.current.getSnapshot(),
        'new-workbook',
        'Untitled',
      )
      queueDemoVisualInstallForActiveSheet()
      setRevision(receipt.revision)
      setPreview(null)
      setMessage(t('appUndoCommitted', { revision: receipt.revision }))
      clearInlineUndo()
    } catch (error: unknown) {
      setMessage(error instanceof Error ? error.message : t('appUndoFailed'))
    }
  }

  /// QAT Redo: workbook history via Univer, same path as the app menu's ⇧⌘Z
  /// (the demo adapter has no redo, matching the menu's behavior).
  function handleRedo(): void {
    void univerRef.current?.univerAPI.redo()
  }

  function disposePageBreakLayers(sheetId: string): void {
    const layers = pageBreakLayersRef.current.get(sheetId) ?? []
    pageBreakLayersRef.current.delete(sheetId)
    for (const layer of layers) {
      try {
        layer.dispose()
      } catch {
        // The float layer already died with a closed workbook.
      }
    }
  }

  /// (Re)installs the overlay for one sheet that has the preview enabled.
  function installPageBreakLayers(sheetId: string): void {
    const runtime = univerRef.current
    const state = lazyWorkbookRef.current
    const worksheet = runtime?.univerAPI.getActiveWorkbook()?.getSheetBySheetId(sheetId)
    if (!runtime || !state || !worksheet) return
    const breaks = effectivePageBreaks(state, sheetId)
    if (breaks === null) return
    disposePageBreakLayers(sheetId)
    pageBreakIdRef.current += 1
    const fileSheet = state.file.sheets.find((sheet) => sheet.id === sheetId)
    const ops = state.editJournal.structuralOps.get(sheetId) ?? []
    pageBreakLayersRef.current.set(
      sheetId,
      installPageBreakPreview(
        runtime,
        worksheet,
        state.editJournal.pageSetup.get(sheetId) ?? {},
        breaks,
        {
          rows: (fileSheet?.rowCount ?? 0) + netAxisDelta(ops, 'row'),
          columns: (fileSheet?.columnCount ?? 0) + netAxisDelta(ops, 'column'),
        },
        `page-break-${pageBreakIdRef.current}`,
      ),
    )
  }

  function refreshPageBreakPreview(): void {
    for (const sheetId of pageBreakPreviewSheets) installPageBreakLayers(sheetId)
  }

  function togglePageBreakPreview(): void {
    const state = lazyWorkbookRef.current
    const worksheet = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()
    const sheetId = worksheet?.getSheetId()
    if (!state || !sheetId) {
      setMessage(t('appPageSetupNeedsFile'))
      return
    }
    if (pageBreakPreviewSheets.has(sheetId)) {
      disposePageBreakLayers(sheetId)
      setPageBreakPreviewSheets((sheets) => {
        const next = new Set(sheets)
        next.delete(sheetId)
        return next
      })
      setMessage(t('appPageBreakPreviewOff'))
      return
    }
    if (effectivePageBreaks(state, sheetId) === null) {
      setMessage(t('appBreaksNeedIndexed'))
      return
    }
    installPageBreakLayers(sheetId)
    setPageBreakPreviewSheets((sheets) => new Set(sheets).add(sheetId))
    setMessage(t('appPageBreakPreviewOn'))
  }

  /**
   * The pictures put into notes this session, so the pane can show them
   * before the save writes them into the file.
   */
  function pendingNotePictures(): PendingNotePicture[] {
    const journal = lazyWorkbookRef.current?.editJournal
    if (!journal) return []
    return journal.notePictures.map((entry) => ({
      sheetId: entry.sheetId,
      row: entry.row,
      column: entry.column,
      dataUrl: entry.picture?.dataUrl ?? null,
    }))
  }

  /** App-scope refs/state bundle for the extracted ribbon dispatcher (ribbon-actions.ts). */
  function ribbonContext(): RibbonCommandContext {
    return {
      univerRef,
      lazyWorkbookRef,
      runOps: runUiOps,
      traceArrowsRef,
      sparklineDisposablesRef,
      sparklineTimerRef,
      chartEditRef,
      shapeEditRef,
      refreshSelectionFormatRef,
      selectedVisual,
      selectedChart,
      setMessage,
      setChartDialog,
      setSymbolDialogOpen,
      openCellsDialog: setCellsDialog,
      setScreenshotDialogOpen,
      setIconsDialogOpen,
      setEquationDialogOpen,
      openRecommendedCharts: () => {
        void handleRecommendedChartsImpl(visualContext()).then((result) => {
          if (result) setRecommendedCharts(result)
        })
      },
      setPendingEdits,
      visualContext,
      dataToolsContext,
      tableDesignContext,
      visualArrangeContext,
      pivotContext,
      handlePageLayoutCommand: (rest) => handlePageLayoutCommandImpl(pageLayoutContext(), rest),
      handleExportPdf: () => handleExportPdfImpl(pageLayoutContext()),
    }
  }

  const functionArgumentsHost = useMemo(
    () =>
      createFunctionArgumentsHost(
        () => univerRef.current,
        () => t('appWorkbookNotReady'),
      ),
    [],
  )
  const isCellEditing = useCallback((): boolean => {
    const workbook = univerRef.current?.univerAPI.getActiveWorkbook() as
      { isCellEditing?(): boolean } | null | undefined
    return workbook?.isCellEditing?.() === true
  }, [])

  async function readPasteSpecialSourceFromRuntime(): Promise<PasteSpecialSource> {
    const runtime = univerRef.current
    return runtime ? readPasteSpecialSource(runtime) : { kind: 'none' }
  }

  async function handlePasteSpecial(
    source: PasteSpecialSource,
    options: PasteSpecialOptions,
  ): Promise<string | null> {
    const runtime = univerRef.current
    if (!runtime) return t('dlgPasteSpecialNothing')
    const result = await applyPasteSpecial(runtime, source, options)
    if (result.ok) return null
    return t(
      result.reason === 'out-of-bounds'
        ? 'dlgPasteSpecialOutOfBounds'
        : result.reason === 'no-selection'
          ? 'dlgPasteSpecialNoSelection'
          : 'dlgPasteSpecialNothing',
    )
  }

  /// A clicked ribbon button keeps DOM focus, so arrow-key cell navigation
  /// dies until the user clicks the grid — Excel hands the keyboard straight
  /// back. Only the button that issued the command is sent back: text fields
  /// commit on blur (focus is already moving on, e.g. Tab to the next box) and
  /// the More Colors native input applies live while its picker stays open.
  /// Two frames let a dialog or panel the command opened claim focus first.
  function handleRibbonCommandFromRibbon(command: string): void {
    const source = document.activeElement
    handleRibbonCommand(command)
    if (!(source instanceof HTMLElement) || !source.closest('[data-ribbon-body]')) return
    if (source.matches('input, select, textarea, [contenteditable="true"]')) return
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const active = document.activeElement
        // a palette swatch unmounts when the popover closes, dropping focus to body
        const dropped = !source.isConnected && (active === null || active === document.body)
        if (active !== source && !dropped) return
        source.blur()
        focusSheetGrid()
      }),
    )
  }

  function handleRibbonCommand(command: string): void {
    if (command === 'workbook-change-password') {
      if (lazyWorkbookRef.current?.file.passwordProtected) {
        setChangeWorkbookPasswordOpen(true)
      }
      return
    }
    if (command === 'watch-window') {
      setWatchOpen((open) => !open)
      return
    }
    if (command === 'toggle-page-break-preview') {
      togglePageBreakPreview()
      return
    }
    if (command === 'toggle-cross-highlight') {
      const next = !crossHighlightVisible
      setCrossHighlightVisible(next)
      storeCrossHighlightPreference(next)
      setMessage(t(next ? 'appCrossHighlightOn' : 'appCrossHighlightOff'))
      return
    }
    if (command === 'toggle-formula-bar') {
      const next = !formulaBarVisible
      document.getElementById('univer-container')?.classList.toggle('formula-bar-hidden', !next)
      setFormulaBarVisible(next)
      setMessage(t(next ? 'appFormulaBarShown' : 'appFormulaBarHidden'))
      return
    }
    const runtime = univerRef.current
    if (command === 'calc-mode:auto' || command === 'calc-mode:manual') {
      if (!runtime) return
      const manual = command === 'calc-mode:manual'
      setManualCalculation(runtime, manual)
      setCalcManual(manual)
      // Excel recalculates when flipping back to automatic.
      if (!manual) calculateNow(runtime)
      setMessage(t(manual ? 'appCalcManualOn' : 'appCalcAutoOn'))
      return
    }
    if (command === 'calculate-now' || command === 'calculate-sheet') {
      if (!runtime) return
      if (command === 'calculate-now') calculateNow(runtime)
      else calculateSheet(runtime)
      setMessage(t('appRecalculated'))
      return
    }
    handleRibbonCommandImpl(ribbonContext(), command)
  }

  /// Adds every cell of the active selection (capped — a whole-column
  /// selection must not spawn a million watches) that isn't watched yet.
  function addWatchSelection(): void {
    const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
    const worksheet = workbook?.getActiveSheet()
    const selection = workbook?.getActiveRange()?.getRange()
    if (!workbook || !worksheet || !selection) return
    const sheetId = worksheet.getSheetId()
    const seen = new Set(watchCells.map(watchKey))
    const added: WatchCell[] = []
    const CAP = 20
    outer: for (let row = selection.startRow; row <= selection.endRow; row += 1) {
      for (let column = selection.startColumn; column <= selection.endColumn; column += 1) {
        if (added.length >= CAP) break outer
        const cell = { sheetId, row, column }
        if (!seen.has(watchKey(cell))) added.push(cell)
      }
    }
    if (added.length > 0) setWatchCells([...watchCells, ...added])
  }

  function resolveWatch(cell: WatchCell): WatchRowValue | null {
    const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
    const worksheet = workbook?.getSheetBySheetId(cell.sheetId)
    if (!worksheet) return null
    const range = worksheet.getRange(cell.row, cell.column, 1, 1)
    return {
      sheetName: worksheet.getSheetName(),
      value: range.getDisplayValue() ?? '',
      formula: range.getFormula() ?? '',
    }
  }

  function selectionStyle(
    range: NonNullable<ReturnType<ActiveWorkbook['getActiveRange']>>,
  ): IStyleData {
    // Resolves interned style references and merges row/col/sheet styles —
    // raw getCellData().s can be a style-id string with no fields on it.
    return range.getCellStyleData() ?? {}
  }

  function anchorCellValue(): number | string | null {
    try {
      const value = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveRange()?.getValue()
      return typeof value === 'number' || typeof value === 'string' ? value : null
    } catch {
      return null
    }
  }

  /// Moves the run's scope in the ref and in state together: the ref is read
  /// mid-run by getActiveSheetInfo, the state is what the chip renders, and a
  /// chip fed from anything else would drift from the run it describes.
  function setAiRunScope(scope: FrozenSelection | null | undefined): void {
    aiRunScopeRef.current = scope
    setAiRunScopeState(scope)
  }

  /// Data extent of a sheet, floored by the file's own used range: cells stream
  /// into Univer lazily, so getLastRow/getLastColumn undercount a sheet the user
  /// has not scrolled through yet. The floor comes from the same screen-space
  /// extent the AI's workbook context reports, so the chip's range and the data
  /// area the model is told about survive inserted or deleted rows together.
  function sheetDataExtent(worksheet: UniverWorksheet): DataExtent {
    const state = lazyWorkbookRef.current
    const fileExtent = state ? lazySheetScreenExtent(state, worksheet.getSheetId()) : null
    return {
      lastRow: Math.max(worksheet.getLastRow(), (fileExtent?.rows ?? 0) - 1),
      lastColumn: Math.max(worksheet.getLastColumn(), (fileExtent?.columns ?? 0) - 1),
    }
  }

  /// Nulls the key too, so re-selecting the same range later still re-arms the
  /// chip instead of being mistaken for an unchanged selection.
  function clearAiScope(): void {
    aiScopeKeyRef.current = null
    setAiScope(null)
    setAiScopeDismissed(false)
  }

  /// Keeps the AI composer's scope chip in sync with the grid selection. Only a
  /// multi-cell range becomes a scope; moving to a different range re-arms a
  /// chip the user had dismissed, so a fresh drag means a fresh scope.
  function refreshAiScope(range: NonNullable<ReturnType<ActiveWorkbook['getActiveRange']>>): void {
    const worksheet = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()
    const sheetId = worksheet?.getSheetId()
    let bounds: IRange
    try {
      bounds = range.getRange()
    } catch {
      // a disposing workbook or a stale cross-sheet range can race the read
      return
    }
    const multiCell = bounds.endRow > bounds.startRow || bounds.endColumn > bounds.startColumn
    if (!multiCell || !worksheet || !sheetId) {
      clearAiScope()
      return
    }
    let scope: FrozenSelection
    try {
      const extent = sheetDataExtent(worksheet)
      const clamped = clampBoundsToExtent(bounds, extent, {
        rowCount: worksheet.getMaxRows(),
        columnCount: worksheet.getMaxColumns(),
      })
      // Display text, so a date header names itself rather than its serial.
      const columns = columnScopeHeaders(clamped, extent, (column) =>
        String(worksheet.getRange(0, column, 1, 1).getDisplayValue() ?? ''),
      )
      scope = { a1: boundsToA1(clamped), sheetId, ...(columns ? { columns } : {}) }
    } catch {
      // same disposing-workbook race as above, now over the extent/header reads
      return
    }
    // Keyed on the clamped range: two whole-column drags of different heights
    // are the same scope, and re-selecting one must not re-arm a dismissed chip.
    const key = `${sheetId}!${scope.a1}`
    if (aiScopeKeyRef.current === key) return
    aiScopeKeyRef.current = key
    setAiScope(scope)
    setAiScopeDismissed(false)
  }

  refreshSelectionFormatRef.current = () => {
    let range: ReturnType<ActiveWorkbook['getActiveRange']> | undefined
    try {
      range = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveRange()
    } catch {
      // Sheet changes briefly retain the previous sheet's selection. If that
      // row or column is outside the new sheet, Univer rejects the stale
      // range; the next selection event will refresh the ribbon normally.
      return
    }
    if (!range) {
      setSelectionFormat(null)
      setSelectedTable(null)
      setActiveCellA1('')
      setPivotSelectionKey(null)
      clearAiScope()
      return
    }
    setActiveCellA1(`${columnLetter(range.getColumn())}${range.getRow() + 1}`)
    setPivotSelectionKey(pivotSelectionKeyImpl(pivotContext()))
    const tableEcho = selectedTableEcho(tableDesignContext())
    setSelectedTable((previous) =>
      selectedTableEquals(previous, tableEcho) ? previous : tableEcho,
    )
    refreshAiScope(range)
    let pattern: string
    try {
      pattern = range.getNumberFormat()
    } catch {
      // A disposing workbook can race the read; keep the last echo.
      return
    }
    const next = toSelectionFormat(selectionStyle(range), pattern, selectionLinkTarget(range))
    setSelectionFormat((previous) => (selectionFormatEquals(previous, next) ? previous : next))
  }

  function selectionLinkTarget(
    range: NonNullable<ReturnType<ActiveWorkbook['getActiveRange']>>,
  ): string | null {
    const state = lazyWorkbookRef.current
    const sheetId = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
    if (!state || !sheetId) return null
    const row = range.getRow()
    const column = range.getColumn()
    const journaled = hyperlinkEditAt(state.editJournal, sheetId, row, column)
    if (journaled !== undefined) return journaled
    return state.hyperlinkTargets.get(sheetId)?.get(`${row}:${column}`) ?? null
  }

  async function openLazyWorkbook(
    opened: WorkbookFile,
    opts?: { continueChat?: boolean; onInitialRangeLoaded?: () => void },
  ): Promise<boolean> {
    if (!(await commitActiveEditor())) return false
    await untilCellFontsLoaded(registerCellFontAliases(workbookFontFamilies(opened)))
    if (opts?.continueChat) chatContinuesRef.current = true
        const selected: WorkbookFile = {
      ...opened,
      visuals: opened.visuals.map((visual) =>
        visual.kind === 'chart' && visual.chart !== undefined
          ? { ...visual, chart: withDefaultBarLabels(visual.chart) }
          : visual,
      ),
    }
    const cellCounts = workbookCellCounts(selected.sheets)
    setWorkbookFile(selected)
    // Calculation mode is workbook state: the next file starts automatic,
    // in the engine and in the menu alike.
    resetCalculationMode(univerRef.current)
    setCalcManual(false)
    // Values verified against the previous workbook mean nothing for this one.
    clearVerifiedFormulaValues()
    const previous = lazyWorkbookRef.current
    if (previous) {
      clearLazyState(previous)
      void window.desktopApi.closeWorkbook(previous.file.sessionId).catch(() => undefined)
    }
    if (demoVisualInstallTimerRef.current) {
      clearTimeout(demoVisualInstallTimerRef.current)
      demoVisualInstallTimerRef.current = null
    }
    disposeVisuals(demoVisualDisposablesRef.current)
    demoVisualDisposablesRef.current = []
    // The preview's float layers belong to the closed workbook's sheets.
    for (const sheetId of [...pageBreakLayersRef.current.keys()]) disposePageBreakLayers(sheetId)
    setPageBreakPreviewSheets(new Set())
    const state: LazyWorkbookState = {
      file: selected,
      generation: Date.now(),
      loadedRanges: new Map(),
      streamAliases: new Map(),
      loadingKeys: new Map(),
      retryTimers: new Map(),
      appliedMerges: new Map(),
      appliedRowKeys: new Map(),
      measuredWrapRows: new Map(),
      rowColStyleKeys: new Map(),
      sheetProtections: new Map(),
      sheetPageBreaks: new Map(),
      sheetFilePageSetups: new Map(),
      sheetProtectedRanges: new Map(),
      uninstalledDefinedNames: new Set(),
      appliedCfSheets: new Set(),
      appliedFilterSheets: new Set(),
      appliedDvSheets: new Set(),
      decorationsPendingSheets: new Set(),
      hyperlinkTargets: new Map(),
      frozenStripKeys: new Map(),
      filterOrigins: new Map(),
      restoredFilterSpans: new Map(),
      showFormulaSheets: new Set(
        selected.sheets.filter((sheet) => sheet.showFormulas).map((sheet) => sheet.id),
      ),
      formulaMode: opensInFormulaMode(cellCounts),
      editJournal: createEditJournal(),
      flags: { preloadComplete: false, preloadRunning: false },
      closure: { status: 'idle', pinned: new Map() },
      formulaText: new Map(),
      formulaTextTruncated: new Set(),
      sharedFormulaGroups: new Map(),
      cachedFormulaValues: new Map(),
      pivotDefinitions: new Map(),
      hiddenFileRows: new Map(),
      hiddenRowsCoveredThrough: new Map(),
      outline: new Map(),
      recalc: {
        timer: null,
        generation: 0,
        failures: 0,
        engineOverBudget: recalcOverBudgetAtOpen(selected.fileBytes, cellCounts.gridCells),
        formulaCells: new Map(),
        overlay: new Map(),
        incompleteRuns: new Set(),
        follow: new Map(),
        running: false,
        lastRunAt: 0,
      },
    }
    // Column outline levels arrive with the sheet metadata; seed them now.
    for (const sheet of selected.sheets) {
      for (const columnWidth of sheet.columnWidths) {
        if (columnWidth.outlineLevel === undefined && !columnWidth.collapsed) continue
        const cols = sheetOutline(state, sheet.id).cols
        const endColumn = Math.min(columnWidth.endColumn, sheet.columnCount - 1)
        for (let column = columnWidth.startColumn; column <= endColumn; column += 1) {
          cols.set(column, {
            level: columnWidth.outlineLevel ?? 0,
            collapsed: columnWidth.collapsed ?? false,
          })
        }
      }
    }
    lazyWorkbookRef.current = state
    void loadRowOutlines(state, lazyWorkbookRef)
    // The cells the reader withheld, read once per open: every read tool asks
    // about cells, so a lazy read would either cost an archive read per call or
    // leave a window in which the model sees the real values. The next workbook
    // starts from nothing until its own read lands, and a part that exists but
    // cannot be read withholds everything rather than nothing — see
    // ai/redact-load.ts.
    redactionIndexRef.current = null
    redactionStatesRef.current = []
    loadedRedactionStatesRef.current = null
    void window.desktopApi
      .readWorkbookRedactions({ sessionId: selected.sessionId })
      .then((result) => {
        // A superseded session's answer must not install its marks.
        if (lazyWorkbookRef.current !== state) return
        const session = redactionSessionFor(result, getActiveSheetInfo().sheets, t)
        redactionIndexRef.current = session.index
        redactionStatesRef.current = result.status === 'ok' ? result.states : []
        watchStructuralEditsForMarks()
        // What the file holds is the baseline a later edit is measured against;
        // an unreadable part has no baseline, and saves leave it in place.
        loadedRedactionStatesRef.current =
          result.status === 'unreadable' ? null : redactionStatesRef.current
        const redactionMessage = session.error ?? session.notice
        if (redactionMessage !== null) setMessage(redactionMessage)
      })
      .catch((error: unknown) => {
        if (lazyWorkbookRef.current !== state) return
        // The read itself failed, so the marks are unknown — the same state a
        // damaged part produces, and the same answer: withhold, and say so.
        const reason = error instanceof Error ? error.message : String(error)
        redactionIndexRef.current = redactionSessionFor(
          { status: 'unreadable', error: reason },
          [],
          t,
        ).index
        setMessage(reason)
      })
    // Pivot definitions load eagerly so refresh (a synchronous apply step)
    // never waits on IPC. Best effort: a failed parse just disables refresh.
    for (const sheet of selected.sheets) {
      for (const pivot of sheet.pivotTables) {
        if (pivot.cachePath === null) continue
        void window.desktopApi
          .readPivotDefinition({
            sessionId: selected.sessionId,
            path: pivot.path,
            cachePath: pivot.cachePath,
          })
          .then((definition) => {
            if (lazyWorkbookRef.current === state) {
              state.pivotDefinitions.set(pivot.path, definition)
            }
          })
          .catch(() => undefined)
      }
    }
    // Dev-only diagnosis hooks: e2e drivers dump journal state and dispatch
    // Univer commands (drag interactions are hard to synthesize over CDP).
    if (import.meta.env.DEV) {
      ;(window as unknown as Record<string, unknown>).__journal = state.editJournal
      ;(window as unknown as Record<string, unknown>).__lazyState = state
      ;(window as unknown as Record<string, unknown>).__univerRuntime = univerRef.current
      ;(window as unknown as Record<string, unknown>).__univerAPI = univerRef.current?.univerAPI
      // Drivers exercise the AI tool layer (get_workbook_context /
      // aggregate_range / propose_operations) without an LLM in the loop.
      // ;(window as unknown as Record<string, unknown>).__workbookSkill =
      //   createWorkbookSkill(sheetsSkillDeps())
      // Ribbon commands by wire name, so UI-path drivers need no DOM clicks.
      ;(window as unknown as Record<string, unknown>).__ribbonCommand = handleRibbonCommand
    }
    // Built-app e2e hook, off by default: the preload exposes
    // __genofficeDebugHooks only when GENOFFICE_DEBUG_HOOKS=1 (scroll/freeze
    // drivers read Univer's render state through the Facade).
    if ((window as unknown as Record<string, unknown>).__genofficeDebugHooks === true) {
      ;(window as unknown as Record<string, unknown>).__genofficeDebug = {
        univerAPI: univerRef.current?.univerAPI,
        findReplaceService: univerRef.current?.univer.__getInjector().get(IFindReplaceService),
        // ground truth for typing-into-the-adopted-spare failures: the
        // shortcut gate is these context bits plus the focused unit, and a
        // null focusedUnit is exactly the state where character keys die
        // while Enter/arrows keep working
        focusContext: () => {
          const injector = univerRef.current?.univer.__getInjector()
          const active = document.activeElement as HTMLElement | null
          return {
            focusedUnitId:
              injector?.get(IUniverInstanceService).getFocusedUnit()?.getUnitId() ?? null,
            activeWorkbookId: univerRef.current?.univerAPI.getActiveWorkbook()?.getId() ?? null,
            activeUComp: active?.dataset?.uComp ?? null,
            docHasFocus: document.hasFocus(),
          }
        },
      }
    }
    setRevision(0)
    setPreview(null)
    lazyPreviewRef.current = null
    setPendingEdits(0)
    // Slicers/timelines belong to the previous workbook's session only;
    // switching files invalidates them.
    setSlicers([])
    setSlicerPicker(null)
    setTimelines([])
    setTimelinePicker(null)
    disposeVisuals(visualDisposablesRef.current)
loadWorkbookSkeleton(univerRef.current, selected)
    applyWorkbookNotes(univerRef.current, selected)
    threadStore.load(selected)
    threadPane.close()
    applyDefinedNames(univerRef.current, selected, state)
    const runtime = univerRef.current
    if (runtime) {
      requestAnimationFrame(() => {
        const workbook = runtime.univerAPI.getActiveWorkbook()
        if (!workbook) {
          opts?.onInitialRangeLoaded?.()
          return
        }
        // Register existing file tables under their displayName so Univer
        // renders filter dropdowns and resolves structured references. The
        // journal stays empty for file tables, so failures are swallowed —
        // the data is still usable.
        const tableInstalls: Promise<unknown>[] = []
        const sessionNames = state.editJournal.tableAdds.map((table) => table.name)
        for (const entry of planFileTableRegistrations(selected.sheets, sessionNames)) {
          const ws = workbook.getSheetBySheetId(entry.sheetId)
          if (!ws) continue
          const { tableId, tableName } = entry
          try {
            // File column names must reach Univer, or empty header cells
            // fall back to its locale template ("Column 1" with a space)
            // where Excel shows the table part's names ("Column1").
            const columnOptions = entry.columns
              ? {
                  columns: entry.columns.map((name, columnIndex) => ({
                    id: `${tableId}-col-${columnIndex}`,
                    displayName: name,
                  })),
                }
              : undefined
            const added = ws.addTable(
              tableName,
              entry.range,
              tableId,
              columnOptions as never,
            ) as unknown
            // Univer paints its own lavender default table theme over the
            // cells; file tables carry Excel's real banding in the cell
            // fills (applyTableBanding), so mute the theme to plain.
            tableInstalls.push(
              Promise.resolve(added)
                .then(() =>
                  (
                    ws as unknown as {
                      addTableTheme(id: string, theme: { name: string }): unknown
                    }
                  ).addTableTheme(tableId, { name: `plain-${tableId}` }),
                )
                // Theme muting is cosmetic; the table itself is registered.
                .catch(() => undefined),
            )
          } catch {
            // Best-effort: skip if Univer rejects (e.g. overlapping ranges)
          }
        }
        // Post-save reopen: swap the load-time decoration's undo entries
        // (table/note/name installs are load artifacts, not edits) for the
        // pre-save user history carried across the session swap. Table
        // registration is async and pushes its undo entries (each push also
        // clears the redo stack) only when its command settles — consume
        // strictly after every install, or the artifacts would land on top
        // of the carried history and wipe the carried redos.
        void Promise.allSettled(tableInstalls).then(() => {
          if (lazyWorkbookRef.current !== state) return
          consumePendingUndoCarry(runtime, workbook.getId())
        })
        const worksheet = workbook.getActiveSheet()
        if (!worksheet) {
          opts?.onInitialRangeLoaded?.()
          return
        }
        // apply the opening sheet's formula view (sheetView/@showFormulas)
        applyShowFormulasView(runtime, state, worksheet.getSheetId())
        queueVisualInstall(
          runtime,
          lazyWorkbookRef,
          visualDisposablesRef,
          visualInstallTimerRef,
          chartEditRef,
          chartVectorRef,
          shapeEditRef,
        )
        // A post-save reinstall lands back where the user was; anything else
        // (fresh opens) starts at the first sheet's origin. Falls back to the
        // origin when the stashed sheet no longer exists.
        const restore = viewRestoreRef.current
        viewRestoreRef.current = null
        const restoredSheet = restore ? workbook.getSheetBySheetId(restore.sheetId) : null
        try {
          if (restore && restoredSheet) {
            workbook.setActiveSheet(restoredSheet)
            restoredSheet.getRange(restore.row, restore.column, 1, 1).activate()
            // scrollToCell puts its target at the viewport's top-left, so
            // scroll to the captured viewport origin — not the selection —
            // to reproduce the exact pre-save view.
            restoredSheet.scrollToCell(restore.viewRow, restore.viewColumn)
          } else {
            worksheet.scrollToCell(0, 0)
          }
        } catch {
          // A workbook opened during startup (the shell's queued-open nudge)
          // can land before Univer's Rendered lifecycle registers the scroll
          // render controller, and the facade then throws a redi
          // QuantityCheckError. The fresh view is already at the origin, so
          // skipping the reset is harmless.
        }
        // getVisibleRange lags the jump by a frame (same as name-box goto) —
        // anchor the first stream at the restored cell, not the stale origin.
        void loadVisibleRange(
          runtime,
          lazyWorkbookRef,
          restoredSheet ?? worksheet,
          setMessage,
          restore && restoredSheet
            ? { row: restore.viewRow, column: restore.viewColumn }
            : undefined,
        ).then(
          () => opts?.onInitialRangeLoaded?.(),
          (error: unknown) => {
            setMessage(error instanceof Error ? error.message : t('appLoadRangeFailed'))
            opts?.onInitialRangeLoaded?.()
          },
        )
        if (state.formulaMode) {
          void startFullLoad(runtime, lazyWorkbookRef, setMessage)
        } else {
          // Deferred so first paint and initial streaming win the sidecar.
          setTimeout(() => {
            void activateFormulaClosure(runtime, lazyWorkbookRef, setMessage)
          }, 1500)
        }
      })
    } else {
      opts?.onInitialRangeLoaded?.()
    }
    return true
  }

  // A workbook loaded into an already-mounted view (the prewarmed spare) can
  // leave document focus on a node Univer no longer reads keys from; hand it
  // back to the cell editor unless chrome (AI composer, dialogs) holds it.
  // Runs from finishOpening, in the same tick that clears openingWorkbook: the
  // <main inert> that guarded the load is still in the DOM until React commits,
  // and an inert subtree refuses focus. The shell also hands webContents focus
  // to an adopted spare asynchronously, so the document may not have focus yet.
  function focusSheetGrid(framesLeft = 10): void {
    const runtime = univerRef.current
    if (!runtime) return
    if (!document.hasFocus()) {
      window.addEventListener('focus', () => focusSheetGrid(), { once: true })
      return
    }
    const active = document.activeElement
    const chromeHoldsFocus =
      active !== null &&
      active !== document.body &&
      active.isConnected &&
      !active.closest('#univer-container')
    if (chromeHoldsFocus) return
    const editor = document.querySelector<HTMLElement>('#univer-container [contenteditable="true"]')
    if (editor?.closest('[inert]') && framesLeft > 0) {
      requestAnimationFrame(() => focusSheetGrid(framesLeft - 1))
      return
    }
    runtime.univer.__getInjector().get(ILayoutService).focus()
    if (editor && document.activeElement !== editor) editor.focus()
  }

  async function handleInspectWorkbook(): Promise<void> {
    if (workbookOpeningRef.current) return
    workbookOpeningRef.current = true
    setOpeningWorkbook(true)
    const finishOpening = (): void => {
      workbookOpeningRef.current = false
      setOpeningWorkbook(false)
      focusSheetGrid()
    }
    try {
      if (!window.desktopApi) {
        throw new Error(t('appBridgeUnavailable'))
      }
      let selected = await window.desktopApi.selectWorkbook()
      if (!selected) {
        setMessage(t('appOpenCanceled'))
        finishOpening()
        return
      }
      if ('passwordRequired' in selected) {
        const encryptedPath = selected.path
        let passwordError: string | null = null
        let decryptedWorkbook: WorkbookFile | null = null
        while (decryptedWorkbook === null) {
          const password = await requestEncryptedWorkbookPassword(passwordError)
          if (password === null) break
          try {
            decryptedWorkbook = await window.desktopApi.openEncryptedWorkbook(
              encryptedPath,
              password,
            )
          } catch (error: unknown) {
            passwordError = error instanceof Error ? error.message : t('appOpenFailed')
          }
        }
        selected = decryptedWorkbook
        if (!selected) {
          setMessage(t('appOpenCanceled'))
          finishOpening()
          return
        }
      }
      if (!(await openLazyWorkbook(selected, { onInitialRangeLoaded: finishOpening }))) {
        finishOpening()
        setMessage(t('appOpenFailed'))
        return
      }
      setEmptyCsvNotice(selected.emptyCsv === true)
      setMessage(selected.emptyCsv ? '' : t('appOpened', { name: selected.name }))
    } catch (error: unknown) {
      setMessage(error instanceof Error ? error.message : t('appOpenFailed'))
      finishOpening()
    }
  }

  async function handleSave(
    mode: 'save' | 'save-as' | 'recovery',
    quiet = false,
    explicitTarget?: { path: string; overwrite: boolean },
  ): Promise<SaveOutcome> {
    // Manual and AI saves take the same gate as the timers: a recovery copy
    // written beside a real save would outlive it as a phantom Restore prompt.
    const gate = saveGateRef.current
    if (mode === 'recovery' && gate.busy) return { ok: false }
    return gate.run(async () => {
      if (!(await commitActiveEditor())) return { ok: false }
      return handleSaveImpl(saveContext(), mode, quiet, explicitTarget)
    })
  }
  async function updateWorkbookPassword(newPassword: string): Promise<string | null> {
    try {
      return await saveGateRef.current.run(async () => {
        if (!(await commitActiveEditor())) return t('appSaveFailed')
        const beforeSave = lazyWorkbookRef.current
        if (!beforeSave?.file.passwordProtected) {
          return t('appWorkbookNotPasswordProtected')
        }

        // Commit all current sheet edits before changing the package password.
        // The sidecar snapshot stays plaintext for this session, while the
        // main process updates the encrypted file atomically on disk.
        const saved = await handleSaveImpl(saveContext(), 'save', true)
        const current = lazyWorkbookRef.current
        if (!current) return t('appWorkbookNotReady')
        if (!saved.ok && journalSize(current.editJournal) > 0) {
          return saved.error ?? t('appSaveFailed')
        }
        if (!current.file.passwordProtected) {
          return t('appWorkbookNotPasswordProtected')
        }

        const result = await window.desktopApi.updateWorkbookPassword(
          current.file.sessionId,
          newPassword,
        )
        const file: WorkbookFile = { ...current.file, ...result }
        lazyWorkbookRef.current = { ...current, file }
        setWorkbookFile(file)
        setMessage(t('appWorkbookPasswordChanged'))
        return null
      })
    } catch (error: unknown) {
      return error instanceof Error ? error.message : t('appSaveFailed')
    }
  }
  closeSaveRef.current = async () => {
    if (!(await commitActiveEditor())) {
      window.desktopApi?.reportCloseSaveResult?.(false)
      return
    }
    const state = lazyWorkbookRef.current
    if (!state || journalSize(state.editJournal) === 0) {
      window.desktopApi?.reportCloseSaveResult?.(true)
      return
    }
    await handleSave('save')
    // handleSave swallows errors into the status bar; a drained journal
    // (fresh state after openLazyWorkbook) is the success signal.
    const after = lazyWorkbookRef.current
    window.desktopApi?.reportCloseSaveResult?.(
      after === null || journalSize(after.editJournal) === 0,
    )
  }
  function sortColumnOptions(): { label: string; colIndex: number }[] {
    const range = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveRange()
    if (!range) return []
    const start = range.getColumn()
    const width = Math.min(range.getWidth(), 26)
    return Array.from({ length: width }, (_, offset) => ({
      label: t('appColumnLabel', { col: columnLabel(start + offset) }),
      colIndex: start + offset,
    }))
  }

  menuActionRef.current = (action) => {
    if (action !== 'open' && (openingWorkbook || workbookOpeningRef.current)) return
    if (action === 'open') {
      void handleInspectWorkbook()
    } else if (action === 'print') {
      void openPrintPreviewHost(pageLayoutContext()).then(setPrintHost)
    } else if (action === 'export-pdf') {
      void handleExportPdfImpl(pageLayoutContext())
    } else if (action === 'export-csv') {
      void handleExportCsvImpl(csvExportContext())
    } else if (action === 'undo' || action === 'redo') {
      // The shell's own text fields (AI prompt, dialog inputs) keep native
      // text undo; everywhere else ⌘Z means workbook history.
      const active = document.activeElement
      if (active instanceof HTMLTextAreaElement || active instanceof HTMLInputElement) {
        document.execCommand(action)
      } else if (action === 'undo') {
        void univerRef.current?.univerAPI.undo()
      } else {
        void univerRef.current?.univerAPI.redo()
      }
    } else {
      void handleSave(action)
    }
  }
  handleSaveRef.current = handleSave

  // MCP visible-grid session (planning/mcp-server.md phase 2): the shell pushes
  // read/apply/save commands; they run through the same executors the built-in
  // AI uses. Handlers go through a ref so the bridge never sees stale closures.
  mcpSheetHandlersRef.current = {
    hasWorkbook: () =>
      univerRef.current?.univerAPI.getActiveWorkbook() != null && lazyWorkbookRef.current != null,
    context: () => getActiveSheetInfo(),
    // The MCP read is machine-facing: `value` is the model value, not the
    // rendered text a number format or a narrow column produced. The rendered
    // text rides along as `display` when the two differ, so a caller can still
    // see what the user sees (see modelCellValue).
    readCells: (addresses, sheetId) => {
      const cells = readCellsImpl(readContext(), addresses, sheetId)
      return Object.fromEntries(
        Object.entries(cells).map(([address, cell]) => {
          const value = modelCellValue(cell)
          return [
            address,
            {
              value,
              ...(cell.value !== value ? { display: cell.value } : {}),
              ...(cell.formula === undefined ? {} : { formula: cell.formula }),
            },
          ]
        }),
      )
    },
    sheets: () => getActiveSheetInfo().sheets.map((sheet) => ({ id: sheet.id, name: sheet.name })),
    // The user is watching this grid, so an edit to a sheet the view is not
    // showing would otherwise land invisibly. Switch the tab and bring the
    // first cell of the batch (or the sheet's top-left) into view — the same
    // jump the find bar performs on a hit.
    focusSheet: (sheetId, address) => {
      const runtime = univerRef.current
      if (!runtime) return
      const workbook = runtime.univerAPI.getActiveWorkbook()
      const worksheet = workbook?.getSheetBySheetId(sheetId)
      if (!workbook || !worksheet) return
      focusWorksheet(worksheet, () => {
        if (worksheet.getSheetId() !== workbook.getActiveSheet()?.getSheetId()) {
          workbook.setActiveSheet(worksheet)
        }
      })
      if (address === undefined) return
      try {
        const { row, column } = parseAddress(address)
        void ensureLazyRangeLoaded(
          runtime,
          lazyWorkbookRef,
          worksheet,
          { startRow: row, endRow: row, startColumn: column, endColumn: column },
          setMessage,
        )
        worksheet.getRange(row, column, 1, 1).activate()
      } catch {
        /* the address is malformed, or the workbook closed mid-jump */
      }
    },
    applyOps: async (ops, dryRun) => {
      const runtime = univerRef.current
      const state = lazyWorkbookRef.current
      const workbook = runtime?.univerAPI.getActiveWorkbook()
      if (!runtime || !state || !workbook) {
        return { ok: false, reason: t('appNoWorkbookOpen') }
      }
      if (dryRun) {
        try {
          const plan = planFromOps(ops, workbook, 'mcp')
          return {
            ok: true,
            dryRun: true,
            structuralChanges: plan.structuralChanges.map((change) => change.label),
            formatChanges: plan.formatChanges.map((change) => change.label),
            cellChanges: plan.cellChanges
              .slice(0, 100)
              .map((change) => ({ address: change.address, after: change.after.value })),
            cellChangeCount: plan.cellChanges.length,
            sheetRenames: plan.sheetRenames.map((rename) => `${rename.before} -> ${rename.after}`),
          }
        } catch (error: unknown) {
          return { ok: false, reason: error instanceof Error ? error.message : String(error) }
        }
      }
      const outcome = await runUiOps(ops)
      if (!outcome.ok) return outcome
      // A formula's text lands synchronously but its result is computed
      // asynchronously, so an immediate read of the cells this batch targeted
      // would show null and an agent could read that as a failed edit. Report
      // the computed values with the result (see formula-values.ts).
      const targets = formulaTargetsFromOps(ops)
      if (targets.length === 0) return outcome
      const values = await awaitFormulaValues(targets, (addresses, sheetId) =>
        readCellsImpl(readContext(), [...addresses], sheetId),
      )
      // Remember which cells settled so the next save can write a real cached
      // <v> for them (the overlay skips the very cells a batch just wrote); the
      // value itself is read live at save time, see formula-values.ts.
      for (const cell of values) {
        rememberFormulaValue(cell.sheetId, cell.address, { formula: cell.formula ?? '' })
      }
      return { ...outcome, formulaValues: values }
    },
    saveTo: async (path, overwrite) => handleSave('save-as', true, { path, overwrite }),
  }
  useEffect(() => {
    const handlers = mcpSheetHandlersRef
    return installSheetsMcpBridge({
      hasWorkbook: () => handlers.current?.hasWorkbook() ?? false,
      context: () => handlers.current?.context(),
      readCells: (addresses, sheetId) => handlers.current?.readCells(addresses, sheetId) ?? {},
      sheets: () => handlers.current?.sheets() ?? [],
      focusSheet: (sheetId, address) => handlers.current?.focusSheet(sheetId, address),
      applyOps: async (ops, dryRun) =>
        (await handlers.current?.applyOps(ops, dryRun)) ?? { ok: false, reason: 'not ready' },
      saveTo: async (path, overwrite) =>
        (await handlers.current?.saveTo(path, overwrite)) ?? {
          ok: false,
          error: 'the spreadsheet is not ready',
        },
    })
  }, [])
  /// Re-renders the floating visuals after a journal mutation (edits and
  /// their undo/redo closures share it).
  function refreshLazyVisuals(state: LazyWorkbookState): void {
    const runtime = univerRef.current
    if (!runtime || lazyWorkbookRef.current !== state) return
    setPendingEdits(journalSize(state.editJournal))
    setVisualEditTick((tick) => tick + 1)
    queueVisualInstall(
      runtime,
      lazyWorkbookRef,
      visualDisposablesRef,
      visualInstallTimerRef,
      chartEditRef,
      chartVectorRef,
      shapeEditRef,
    )
  }

  function refreshDemoVisuals(): void {
    if (lazyWorkbookRef.current) return
    setVisualEditTick((tick) => tick + 1)
    queueDemoVisualInstallForActiveSheet()
  }

  const chartSyncRef = useRef<{
    timer: ReturnType<typeof setTimeout> | null
    dirty: Map<string, CellBounds>
    pending: Map<string, CellBounds>
  }>({ timer: null, dirty: new Map(), pending: new Map() })

  function queueChartDataSync(sheetId: string, bounds: CellBounds): void {
    queueChartDataSyncImpl(visualSyncContext(), sheetId, bounds)
  }

  chartEditRef.current = (editKey, edit) => applyChartEditImpl(visualSyncContext(), editKey, edit)
  chartVectorRef.current = (editKey, rangeText) =>
    readChartVectorImpl(visualSyncContext(), editKey, rangeText)
  shapeEditRef.current = (visualId, changes) =>
    applyShapeEditImpl(visualSyncContext(), visualId, changes)

  // Ribbon echo of the selected chart; a live lookup so deletion, file
  // switches, and pending type edits reflect without extra bookkeeping.
  const selectedChart = (() => {
    if (!selectedVisual || selectedVisual.kind !== 'chart') return null
    const state = lazyWorkbookRef.current
    const live: WorkbookVisualObject | undefined = state
      ? [...state.file.visuals, ...state.editJournal.visualAdds].find(
          (candidate) => candidate.id === selectedVisual.id,
        )
      : (adapterRef.current.findVisual(selectedVisual.id) ?? undefined)
    if (!live?.chart || (state && state.editJournal.visualEdits.get(live.id)?.remove)) return null
    const pending =
      state && live.chartPath ? state.editJournal.chartEdits.get(live.chartPath) : undefined
    const currentChart = pending ? applyChartStateEdit(live.chart, pending) : live.chart
    const convertible = convertibleType(live.chart)
    const currentType = pending?.chartType ?? convertible
    const isPie =
      currentType !== null
        ? currentType === 'pie' || currentType === 'doughnut'
        : live.chart.chartTypes.some((type) => type.includes('pie') || type.includes('doughnut'))
    return {
      title: pending?.title ?? live.chart.title,
      convertible,
      currentType,
      canEdit: !state || live.chartPath !== undefined || live.id.startsWith('added-'),
      isPie,
      hasAxes: currentType !== null && !isPie,
      // A pending conversion always lands on a labelable family.
      canLabel: pending?.chartType !== undefined || chartSupportsDataLabels(live.chart.chartTypes),
      seriesCount: currentChart.series.length,
      categoryCount: currentChart.series[0]?.categories.length ?? 0,
      series: currentChart.series,
      legend: pending?.legend ?? live.chart.legend,
      axisTitles: { ...live.chart.axisTitles, ...pending?.axisTitles },
      dataLabels: pending?.dataLabels ?? live.chart.dataLabels,
      grouping: pending?.grouping ?? live.chart.grouping,
    }
  })()

  // Shape Format echo: the selected shape's paint with pending edits applied.
  const selectedShape = ((): SelectedShapeRibbon | null => {
    if (!selectedVisual || selectedVisual.kind !== 'shape') return null
    const state = lazyWorkbookRef.current
    if (!state) return null
    const live = [...state.file.visuals, ...state.editJournal.visualAdds].find(
      (candidate) => candidate.id === selectedVisual.id,
    )
    if (!live || !(isEditableShape(live) || isEditableFileVisual(live))) return null
    const edit = state.editJournal.visualEdits.get(live.id)
    if (edit?.remove) return null
    return {
      fillColor: edit?.fillColor ?? live.fillColor,
      lineColor: edit?.lineColor ?? live.lineColor,
    }
  })()

  const activePageLayout = (() => {
    const worksheet = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()
    const journalState = worksheet
      ? (lazyWorkbookRef.current?.editJournal.pageSetup.get(worksheet.getSheetId()) ?? {})
      : {}
    return {
      ...journalState,
      showGridlines:
        journalState.showGridlines ?? (worksheet ? !worksheet.hasHiddenGridLines() : true),
      showHeadings:
        journalState.showHeadings ??
        (worksheet
          ? worksheet.getSheet().getConfig().rowHeader.hidden !== BooleanNumber.TRUE
          : true),
      rightToLeft: journalState.rightToLeft ?? (worksheet ? sheetIsRightToLeft(worksheet) : false),
      pageBreakPreview: worksheet ? pageBreakPreviewSheets.has(worksheet.getSheetId()) : false,
    }
  })()

  // Chart panels resolve their chart live (pending edits applied), so every
  // control reflects the state the next save would write.
  const visualDialogTarget = (() => {
    if (!visualDialog) return null
    const state = lazyWorkbookRef.current
    return state
      ? liveVisual(state, visualDialog.visualId)
      : ((adapterRef.current.findVisual(visualDialog.visualId) as WorkbookVisualObject | null) ??
          null)
  })()
  const chartDialogTarget = (() => {
    if (!chartDialog) return null
    const state = lazyWorkbookRef.current
    const live: WorkbookVisualObject | undefined = state
      ? [...state.file.visuals, ...state.editJournal.visualAdds].find(
          (candidate) =>
            candidate.chartPath === chartDialog.editKey || candidate.id === chartDialog.editKey,
        )
      : (adapterRef.current.findVisual(chartDialog.editKey) ?? undefined)
    // A visual pending removal must not keep a live panel producing edits.
    if (!live?.chart || (state && state.editJournal.visualEdits.get(live.id)?.remove)) return null
    const pending =
      state && live.chartPath ? state.editJournal.chartEdits.get(live.chartPath) : undefined
    return {
      visualId: live.id,
      chart: applyChartStateEdit(live.chart, pending),
      supported: chartSupportsSeriesReplace(live.chart.chartTypes),
    }
  })()

  // genoffice CLI (`open --range`, `selection`): the shell evaluates this hook
  useEffect(() => {
    ;(window as unknown as Record<string, unknown>).__genofficeControl = (req: ControlRequest) =>
      handleSheetsControl(
        req,
        univerRef.current?.univerAPI.getActiveWorkbook(),
        lazyWorkbookRef.current !== null,
      )
  })

  const aiScopeChip = resolveScopeChip(aiRunScope, aiScope, aiScopeDismissed)

  return (
    <>
      <ToastHost />
      {recoveryPrompt && (
        <RecoveryDialog
          prompt={recoveryPrompt}
          onChoose={(restore) => {
            setRecoveryPrompt(null)
            window.desktopApi?.replyRecoveryPrompt?.(restore)
          }}
        />
      )}
      {fullLoadPrompt && (
        <div className="dialog-backdrop">
          <div
            className="format-cells-dialog recovery-dialog"
            role="dialog"
            aria-label={t('appFullLoadFilterTitle')}
          >
            <section className="dialog-body">
              <div className="recovery-heading">
                <h2>{t('appFullLoadFilterTitle')}</h2>
              </div>
              <p className="recovery-body">
                {t(fullLoadPrompt === 'ask' ? 'appFullLoadFilterBody' : 'appFullLoadTooLarge')}
              </p>
            </section>
            <div className="dialog-actions">
              <button className="secondary" onClick={() => setFullLoadPrompt(null)}>
                {t('appDialogCancel')}
              </button>
              {fullLoadPrompt === 'ask' && (
                <button
                  className="primary-action"
                  autoFocus
                  onClick={() => {
                    setFullLoadPrompt(null)
                    const runtime = univerRef.current
                    if (!runtime) return
                    setMessage(t('appFullLoadRunning'))
                    // Joins a load that is already running (e.g. from Print).
                    void startFullLoad(runtime, lazyWorkbookRef, setMessage)
                  }}
                >
                  {t('appFullLoadStart')}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      {visualDialog && visualDialogTarget && (
        <VisualDialog
          kind={visualDialog.kind}
          visual={visualDialogTarget}
          frame={
            lazyWorkbookRef.current
              ? visualFrameInfo(lazyWorkbookRef.current, visualDialogTarget.id)
              : null
          }
          onApply={(changes) => {
            const state = lazyWorkbookRef.current
            const runtime = univerRef.current
            if (visualDialog.kind === 'size') {
              const { size, editAs } = changes as SizeDialogResult
              const edit =
                size && state && runtime
                  ? frameChangeEdit(state, runtime, visualDialogTarget, size)
                  : null
              if (!edit && !editAs) return
              shapeEditRef.current(visualDialogTarget.id, {
                ...edit,
                ...(editAs ? { editAs } : {}),
              })
              return
            }
            shapeEditRef.current(visualDialogTarget.id, changes as ShapeEditChanges)
          }}
          onClose={() => setVisualDialog(null)}
        />
      )}
      {viewImage && (
        <ImageViewer
          src={viewImage}
          lang={getLang()}
          labels={{
            zoomIn: t('appZoomIn'),
            zoomOut: t('appZoomOut'),
            actualSize: t('appImgActualSize'),
            fitToWindow: t('appImgFitWindow'),
            save: t('appImgSaveAs'),
            close: t('appImgClose'),
          }}
          onClose={() => setViewImage(null)}
        />
      )}
      {chartDialog && chartDialogTarget && chartDialog.kind === 'format' && (
        <ChartFormatPane
          chart={chartDialogTarget.chart}
          element={
            chartElement?.visualId === chartDialogTarget.visualId ? chartElement.element : null
          }
          onEdit={(edit) => chartEditRef.current(chartDialog.editKey, edit)}
          onClose={() => setChartDialog(null)}
        />
      )}
      {chartDialog && chartDialogTarget && chartDialog.kind === 'select-data' && (
        <SelectDataDialog
          chart={chartDialogTarget.chart}
          supported={chartDialogTarget.supported}
          readVector={(range) => chartVectorRef.current(chartDialog.editKey, range)}
          onApply={(edit) => chartEditRef.current(chartDialog.editKey, edit)}
          onClose={() => setChartDialog(null)}
        />
      )}
      <ExcelShell
        openingWorkbook={openingWorkbook}
        prompt={prompt}
        preview={preview}
        sheetHasContent={sheetHasContent}
        pageLayout={activePageLayout}
        printHost={printHost}
        onClosePrint={() => setPrintHost(null)}
        calcManual={calcManual}
        onGoalSeek={(setCell, toValue, byCell) => {
          const runtime = univerRef.current
          if (!runtime) return Promise.reject(new Error(t('appWorkbookNotReady')))
          return solveGoalSeek(runtime, { setCell, toValue, byCell })
        }}
        onDataTable={(input) => {
          const runtime = univerRef.current
          if (!runtime) return Promise.reject(new Error(t('appWorkbookNotReady')))
          return applyDataTable(runtime, input)
        }}
        onGetDataTableRange={() => {
          // Excel's flow starts from the selected table region; a single-cell
          // selection cannot be a data table, so the field starts empty.
          const range = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveRange()
          return range && range.getHeight() > 1 && range.getWidth() > 1 ? range.getA1Notation() : ''
        }}
        onFillSeries={(options) => {
          const runtime = univerRef.current
          return runtime ? applyFillSeries(runtime, options, t) : t('appWorkbookNotReady')
        }}
        onGetFillSeriesContext={() =>
          fillSeriesContext(univerRef.current, lazyWorkbookRef.current?.file.date1904 === true)
        }
        selectionFormat={selectionFormat}
        formatPainterActive={formatPainterActive}
        statusMessage={openingWorkbook ? t('appOpeningWorkbook') : message}
        emptyCsvNotice={emptyCsvNotice}
        onOpenWorkbook={() => void handleInspectWorkbook()}
        onDismissEmptyCsvNotice={() => setEmptyCsvNotice(false)}
        aiBusy={aiBusy}
        {...(sessionUsage !== undefined ? { sessionUsage } : {})}
        chat={chat}
        historicChat={historicChat}
        attachments={attachments}
        attachedSkills={attachedSkills}
        onToggleSkill={toggleSkill}
        attachNotice={attachNotice}
        onPickAttachments={() => void handlePickAttachments()}
        onAddAttachmentPaths={(paths) => void handleAddAttachmentPaths(paths)}
        onAddPastedImage={(data, ext) => void handleAddPastedImage(data, ext)}
        onRemoveAttachment={handleRemoveAttachment}
        onPromptChange={setPrompt}
        onSend={handleSend}
        onStop={handleStopAgent}
        onNewChat={handleNewChat}
        onUndo={handleUndo}
        aiScopeRange={aiScopeChip.range}
        aiScopeColumns={aiScopeChip.columns ?? null}
        aiScopeLocked={aiScopeChip.locked}
        aiSelectionAskAnchor={aiSelectionAskAnchor}
        onAiSelectionAskDismiss={() => setAiSelectionAskAnchor(null)}
        onAiScopeDismiss={() => {
          setAiScopeDismissed(true)
          setAiSelectionAskAnchor(null)
        }}
        onAiCitation={handleAiCitation}
        canUndo={univerHist.canUndo || (!lazyWorkbookRef.current && adapterRef.current.canUndo)}
        canRedo={univerHist.canRedo}
        onCommand={handleRibbonCommandFromRibbon}
        onIsCellEditing={isCellEditing}
        zoomPercent={zoomPercent}
        statusBarFuncs={statusBarFuncs}
        onToggleStatusBarFunc={toggleStatusBarStat}
        canSave={pendingEdits > 0 || workbookFile?.unsavedNew === true}
        onSave={() => void handleSave('save')}
        canSaveAs={workbookFile !== null}
        onSaveAs={() => void handleSave('save-as')}
        onRedo={handleRedo}
        autoSave={autoSave}
        onAutoSaveChange={setAutoSave}
        selectedChart={selectedChart}
        selectedShape={selectedShape}
        selectedVisualKind={
          selectedVisual?.kind === 'image' || selectedVisual?.kind === 'shape'
            ? selectedVisual.kind
            : null
        }
        selectedTable={selectedTable}
        outlineSummary={outlineSummarySettings(
          lazyWorkbookRef.current,
          univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId(),
        )}
        tableCreatedSeq={tableCreatedSeq}
        onGetCreateTableRange={() => createTableDefaultRange(tableDesignContext())}
        onGetSortColumns={sortColumnOptions}
        onGetSheetProtection={sheetProtectionEcho}
        onProtectSheet={protectActiveSheet}
        onUnprotectSheet={unprotectActiveSheet}
        sheetTabActions={sheetTabActions}
        onGetWorkbookProtection={workbookProtectionEcho}
        passwordProtected={workbookFile?.passwordProtected === true}
        formulaBarVisible={formulaBarVisible}
        crossHighlightVisible={crossHighlightVisible}
        onGetProtectedRanges={protectedRangesSnapshot}
        onApplyProtectedRanges={applyProtectedRanges}
        onGetDefinedNames={definedNameRows}
        onDefinedNameAction={handleDefinedNameAction}
        onGetPivotFields={(sourceRange) => pivotFieldOptionsImpl(pivotContext(), sourceRange)}
        onGetSourceRange={() => getSourceRangeImpl(pivotContext())}
        onCreatePivot={(request) => handleCreatePivotImpl(pivotContext(), request)}
        onGetPivotEditSeed={() => pivotEditInitialImpl(pivotContext())}
        onEditPivot={(config) => handleEditPivotApplyImpl(pivotContext(), config)}
        onGetPivotFieldMembers={(fieldIndex) => pivotFieldMembersImpl(pivotContext(), fieldIndex)}
        pivotSelectionKey={pivotSelectionKey}
        onRefreshPivot={() => handleRefreshPivotImpl(pivotContext())}
        onIsSelectionInPivot={() => isSelectionInPivotImpl(pivotContext())}
        onGetActiveCell={() => activeCellLabelImpl(dataToolsContext())}
        onGetAnchorValue={anchorCellValue}
        activeCellA1={activeCellA1}
        onGoToReference={(ref) => goToReferenceImpl(dataToolsContext(), ref)}
        onListDefinedNames={() => listDefinedNamesImpl(dataToolsContext())}
        onReadPasteSpecialSource={readPasteSpecialSourceFromRuntime}
        onPasteSpecial={handlePasteSpecial}
        functionArguments={functionArgumentsHost}
        onListFunctions={() => {
          const runtime = univerRef.current
          return runtime ? readLiveFunctionInfos(runtime) : []
        }}
        onCreateSubtotal={(config) => handleCreateSubtotalImpl(dataToolsContext(), config)}
        onCreateConsolidate={(config) => handleCreateConsolidateImpl(dataToolsContext(), config)}
        onGetConsolidateDefault={() => consolidateDefaultReferenceImpl(dataToolsContext())}
        onApplyHeaderFooter={(result) => handleApplyHeaderFooterImpl(pageLayoutContext(), result)}
      />
      {openingWorkbook && (
        <div className="workbook-opening-screen" role="status" aria-live="polite">
          {t('appOpeningWorkbook')}
        </div>
      )}
      {encryptedPasswordPrompt && (
        <EncryptedWorkbookPasswordDialog
          error={encryptedPasswordPrompt.error}
          onSubmit={(password) => answerEncryptedWorkbookPassword(password)}
          onClose={() => answerEncryptedWorkbookPassword(null)}
        />
      )}
      {changeWorkbookPasswordOpen && (
        <ChangeWorkbookPasswordDialog
          onSubmit={updateWorkbookPassword}
          onClose={() => setChangeWorkbookPasswordOpen(false)}
        />
      )}
      <ThreadedCommentsPane getRuntime={getRuntime} />
      <NotePicturesPane
        file={workbookFile}
        pending={pendingNotePictures()}
        onRemove={(sheetId, row, column) =>
          handleRemoveNotePicture(ribbonContext(), sheetId, row, column)
        }
        getRuntime={getRuntime}
      />
      <ThreadHoverCard hover={threadHover} />
      {redactDialog && (
        <RedactDialog
          seed={redactDialog.seed}
          rangeLabel={redactDialog.rangeLabel}
          onSubmit={onRedactConfirm}
          onCancel={() => setRedactDialog(null)}
        />
      )}
      {findReplaceService && (
        <FindReplacePanel
          service={findReplaceService}
          getWorkbook={() =>
            univerRef.current?.univer
              .__getInjector()
              .get(IUniverInstanceService)
              .getCurrentUnitOfType<Workbook>(UniverInstanceType.UNIVER_SHEET) ?? null
          }
          onJumpTo={(sheetId, bounds) =>
            void selectWorkbookRange(readContext(), sheetId, bounds, setMessage)
          }
          onClose={() =>
            univerRef.current?.univer.__getInjector().get(FindReplaceController).closePanel()
          }
          registerContainer={(element) => {
            const disposable = univerRef.current?.univer
              .__getInjector()
              .get(ILayoutService)
              .registerContainerElement(element)
            return () => disposable?.dispose()
          }}
        />
      )}
      {cellsDialog !== null && univerRef.current && (
        <InsertDeleteCellsDialog
          mode={cellsDialog}
          onApply={(choice) => {
            const runtime = univerRef.current
            if (runtime) runCellsChoice(runtime, cellsDialog, choice)
          }}
          onClose={() => setCellsDialog(null)}
        />
      )}
      {advancedFilterColumns !== null && (
        <AdvancedFilterDialog
          columns={advancedFilterColumns}
          onApply={(criteria) => handleApplyAdvancedFilterImpl(dataToolsContext(), criteria)}
          onClose={() => setAdvancedFilterColumns(null)}
        />
      )}
      {symbolDialogOpen && (
        <SymbolDialog
          onInsert={(char) => handleInsertSymbolImpl(dataToolsContext(), char)}
          onClose={() => setSymbolDialogOpen(false)}
        />
      )}
      {screenshotDialogOpen && (
        <ScreenshotDialog
          onInsert={(dataUrl, width, height) =>
            handleInsertScreenshot(visualContext(), dataUrl, width, height)
          }
          onClose={() => setScreenshotDialogOpen(false)}
        />
      )}
      {iconsDialogOpen && (
        <IconsDialog
          onInsert={(dataUrl, size, name) =>
            handleInsertIconImpl(visualContext(), dataUrl, size, name)
          }
          onClose={() => setIconsDialogOpen(false)}
        />
      )}
      {equationDialogOpen && (
        <EquationDialog
          onInsert={(dataUrl, width, height) =>
            handleInsertEquationImpl(visualContext(), dataUrl, width, height)
          }
          onClose={() => setEquationDialogOpen(false)}
        />
      )}
      {recommendedCharts !== null && (
        <RecommendedChartsDialog
          recommendations={recommendedCharts}
          onPick={(kind) => void handleInsertChartImpl(visualContext(), kind)}
          onClose={() => setRecommendedCharts(null)}
        />
      )}
      {slicerPicker !== null && (
        <SlicerFieldPicker
          fields={slicerPicker.fields}
          onPick={(field) => handleCreateSlicerImpl(pivotContext(), field)}
          onClose={() => setSlicerPicker(null)}
        />
      )}
      <SlicerPanels
        slicers={slicers}
        onToggle={(slicerId, member) => handleSlicerToggleImpl(pivotContext(), slicerId, member)}
        onSelectAll={(slicerId) => handleSlicerSelectAllImpl(pivotContext(), slicerId)}
        onRemove={(slicerId) => handleRemoveSlicerImpl(pivotContext(), slicerId)}
      />
      {timelinePicker !== null && (
        <TimelineFieldPicker
          fields={timelinePicker.fields}
          onPick={(field) => handleCreateTimelineImpl(pivotContext(), field)}
          onClose={() => setTimelinePicker(null)}
        />
      )}
      <TimelinePanels
        timelines={timelines}
        onRange={(timelineId, start, end) =>
          handleTimelineRangeImpl(pivotContext(), timelineId, { start, end })
        }
        onClear={(timelineId) => handleTimelineRangeImpl(pivotContext(), timelineId, null)}
        onRemove={(timelineId) => handleRemoveTimelineImpl(pivotContext(), timelineId)}
      />
      {watchOpen && (
        <WatchWindowPanel
          watches={watchCells}
          onResolve={resolveWatch}
          onAddSelection={addWatchSelection}
          onRemove={(key) => setWatchCells(watchCells.filter((cell) => watchKey(cell) !== key))}
          onClose={() => setWatchOpen(false)}
        />
      )}
    </>
  )

  function definedNameRows(): {
    names: DefinedNameRow[]
    sheets: { id: string; name: string }[]
    activeSheetId: string | null
  } {
    const workbook = univerRef.current?.univerAPI.getActiveWorkbook()
    const activeSheetId = workbook?.getActiveSheet()?.getSheetId() ?? null
    const sheets =
      workbook?.getSheets().map((sheet) => ({
        id: sheet.getSheetId(),
        name: sheet.getSheetName(),
      })) ?? []
    const sheetNames = new Map(sheets.map((sheet) => [sheet.id, sheet.name]))
    const names = univerDefinedNames(univerRef.current).map((defined) => {
      const localSheetId = defined.getLocalSheetId()
      const scoped = localSheetId !== undefined && localSheetId !== 'AllDefaultWorkbook'
      return {
        name: defined.getName(),
        ref: defined.getFormulaOrRefString(),
        scopeSheetId: scoped ? localSheetId : null,
        scopeLabel: scoped ? (sheetNames.get(localSheetId) ?? localSheetId) : t('appScopeWorkbook'),
      }
    })
    return { names, sheets, activeSheetId }
  }

  function handleDefinedNameAction(action: DefinedNameAction): string | null {
    const runtime = univerRef.current
    const workbook = runtime?.univerAPI.getActiveWorkbook()
    if (!workbook || !lazyWorkbookRef.current) {
      return t('appNamesNeedFile')
    }
    try {
      if (action.kind === 'add') {
        const wb = workbook as unknown as {
          newDefinedNameBuilder(): {
            load(param: Record<string, unknown>): { build(): unknown }
          }
          insertDefinedNameBuilder(param: unknown): void
        }
        wb.insertDefinedNameBuilder(
          wb
            .newDefinedNameBuilder()
            .load({
              name: action.name,
              formulaOrRefString: action.ref.replace(/^=/, ''),
              localSheetId: action.sheetId ?? 'AllDefaultWorkbook',
            })
            .build(),
        )
      } else {
        const target = univerDefinedNames(runtime).find((defined) => {
          const localSheetId = defined.getLocalSheetId()
          const scoped = localSheetId !== undefined && localSheetId !== 'AllDefaultWorkbook'
          const scopeSheetId = scoped ? localSheetId : null
          const originalName = action.kind === 'update' ? action.originalName : action.name
          return defined.getName() === originalName && scopeSheetId === action.scopeSheetId
        })
        if (!target) return t('appNameGone')
        if (action.kind === 'remove') {
          target.delete()
        } else {
          if (action.name !== action.originalName) target.setName(action.name)
          target.setRef(action.ref.replace(/^=/, ''))
        }
      }
    } catch (error: unknown) {
      return error instanceof Error ? error.message : t('appNameApplyFailed')
    }
    setMessage(t('appNamesUpdated'))
    return null
  }

  /// Effective protection of the active sheet: journal override, else file
  /// state; null while unknown (still indexing) or in the demo workbook.
  function sheetProtectionEcho(): { protected: boolean; hasPassword: boolean } | null {
    const state = lazyWorkbookRef.current
    const sheetId = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
    if (!state || !sheetId) return null
    const info = effectiveSheetProtection(state, sheetId)
    return info ? { protected: info.protected, hasPassword: info.hasPassword } : null
  }

  async function protectActiveSheet(request: {
    password: string | null
    allow: SheetProtectionAllow
  }): Promise<string | null> {
    const sheetId = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
    if (!sheetId) return t('appProtectionNeedsFile')
    const outcome = await runUiOps(
      [
        {
          op: 'protect_sheet',
          sheetId,
          protected: true,
          allow: request.allow,
          ...(request.password ? { password: request.password } : {}),
        },
      ],
      t('appProtectionWillWrite'),
    )
    return outcome.ok ? null : (outcome.reason ?? t('appApplyTxFailed'))
  }

  async function unprotectActiveSheet(password: string): Promise<string | null> {
    const sheetId = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
    if (!sheetId) return t('appProtectionNeedsFile')
    const outcome = await runUiOps(
      [{ op: 'protect_sheet', sheetId, protected: false, password }],
      t('appProtectionWillRemove'),
    )
    return outcome.ok ? null : (outcome.reason ?? t('appApplyTxFailed'))
  }

  function workbookProtectionEcho(): boolean | null {
    const state = lazyWorkbookRef.current
    if (!state) return null
    return workbookStructureLocked(state)
  }

  /// The active sheet's allow-edit ranges, or an error the dialog surfaces.
  function protectedRangesSnapshot(): {
    ranges: readonly {
      name: string
      sqref: string
      hasPassword: boolean
      /** the hash, when this session computed it; a file's own hashes stay in the file */
      password?: SheetPasswordHash
    }[]
    error: string | null
  } {
    const state = lazyWorkbookRef.current
    const sheetId = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
    if (!state || !sheetId) return { ranges: [], error: t('appProtectionNeedsFile') }
    const file = state.sheetProtectedRanges.get(sheetId)
    if (!file && !state.editJournal.sheets.added.has(sheetId)) {
      return { ranges: [], error: t('appProtectionNeedsIndexed') }
    }
    return { ranges: file ?? [], error: null }
  }

  async function applyProtectedRanges(
    ranges: readonly { name: string; sqref: string; password?: string }[],
  ): Promise<string | null> {
    const state = lazyWorkbookRef.current
    const sheetId = univerRef.current?.univerAPI.getActiveWorkbook()?.getActiveSheet()?.getSheetId()
    if (!state || !sheetId) return t('appProtectionNeedsFile')
    const snapshot = protectedRangesSnapshot()
    if (snapshot.error !== null) return snapshot.error
    // A rewrite cannot preserve password hashes it does not know; fail closed.
    // A hash this session computed travels in the request and survives.
    if (snapshot.ranges.some((range) => range.hasPassword && range.password === undefined)) {
      return t('appRangesPasswordBlocked')
    }
    const hashed = await Promise.all(
      ranges.map(async (range) => ({
        name: range.name,
        sqref: range.sqref,
        hasPassword: range.password !== undefined && range.password !== '',
        ...(range.password ? { password: await hashSheetPassword(range.password) } : {}),
      })),
    )
    state.sheetProtectedRanges.set(sheetId, hashed)
    recordProtectedRangesChange(state.editJournal, sheetId)
    setPendingEdits(journalSize(state.editJournal))
    setMessage(t('appRangesRecorded', { count: ranges.length }))
    return null
  }
}
