import type { AiPanelPrefs } from '@genoffice/ui'
import { contextBridge, ipcRenderer, webUtils } from 'electron'

import type {
  AiChatResponse,
  AiSettings,
  AiStreamChunk,
  GenSparkAccountStatus,
} from '@genoffice/ai-provider'
import type { ProjectApi } from '@genoffice/project-store'
import type {
  AttachmentAddResult,
  AttachmentImageResult,
  AttachmentMeta,
  AttachmentReadResult,
  DesktopApi,
  McpCommandMessage,
  RecoveryPromptPayload,
  ScreenCaptureResult,
  ScreenSourcesResult,
  AutoSaveDefault,
  DocTheme,
  UiTheme,
  WorkbookCellStyle,
  WorkbookConditionalRule,
  WorkbookFile,
  WorkbookFindCellsRequest,
  WorkbookFindCellsResult,
  WorkbookFormulaCellsRequest,
  WorkbookFormulaCellsResult,
  WorkbookSharedFormulaGroup,
  WorkbookRowOutlineResult,
  WorkbookMediaRequest,
  WorkbookMediaResult,
  WorkbookPagePrintSettings,
  WorkbookPivotDefinition,
  WorkbookPivotRequest,
  WorkbookRangeRequest,
  WorkbookRangeResult,
  WorkbookRecalcRequest,
  WorkbookRecalcResult,
  WorkbookRedactionsResult,
  WorkbookRichRun,
  WorkbookSaveRequest,
  WorkbookSaveResult,
  WorkbookVisualObject,
  WebSearchResult,
  ImageSearchResponse,
  GenerateImageResult,
  UserSkillEntry,
} from '../shared/desktop-api'
import {
  HEADER_FOOTER_PICTURE_POSITION,
  IPC_CHANNELS,
  MAX_CREATE_DOCUMENT_CONTENT_CHARS,
  MAX_CREATE_DOCUMENT_TITLE_CHARS,
  MAX_CSV_EXPORT_CHARS,
  MAX_PDF_TEMPLATE_CHARS,
  MAX_SAVE_EDITS,
  MAX_SAVE_EDITS_TOTAL,
  SAVE_EDITS_CHUNK_JSON_MAX,
} from '../shared/ipc-channels'
import { installDropOpenBridge } from '@genoffice/electron-utils/drop-open'

const desktopApi: DesktopApi = {
  getLanguage: () => ipcRenderer.invoke('app:get-language'),
  openSourcePath: (path: string) => ipcRenderer.invoke('home:open-path', path),
  onLanguageChanged(handler) {
    const listener = (
      _event: Electron.IpcRendererEvent,
      lang: 'zh' | 'en' | 'ja' | 'ko' | 'fr' | 'de' | 'es' | 'th' | 'id' | 'ru' | 'ar',
    ) => handler(lang)
    ipcRenderer.on('app:language-changed', listener)
    return () => ipcRenderer.removeListener('app:language-changed', listener)
  },
  getTheme: () => ipcRenderer.invoke('app:get-theme'),
  onThemeChanged(handler) {
    const listener = (_event: Electron.IpcRendererEvent, theme: UiTheme) => handler(theme)
    ipcRenderer.on('app:theme-changed', listener)
    return () => ipcRenderer.removeListener('app:theme-changed', listener)
  },
  getDocumentTheme: async () => {
    const result: unknown = await ipcRenderer.invoke('app:get-document-theme')
    return result === 'dark' || result === 'light' ? result : 'follow'
  },
  onDocumentThemeChanged(handler) {
    const listener = (_event: Electron.IpcRendererEvent, theme: DocTheme) => handler(theme)
    ipcRenderer.on('app:document-theme-changed', listener)
    return () => ipcRenderer.removeListener('app:document-theme-changed', listener)
  },
  getAutoSaveDefault: () => ipcRenderer.invoke('app:get-auto-save-default'),
  onAutoSaveDefaultChanged(handler) {
    const listener = (_event: Electron.IpcRendererEvent, value: AutoSaveDefault) => handler(value)
    ipcRenderer.on('app:auto-save-default-changed', listener)
    return () => ipcRenderer.removeListener('app:auto-save-default-changed', listener)
  },
  getAiPanelPrefs: () => ipcRenderer.invoke('app:get-ai-panel-prefs'),
  setAiPanelPrefs: (patch) => ipcRenderer.invoke('app:set-ai-panel-prefs', patch),
  onAiPanelPrefsChanged: (handler) => {
    const listener = (_event: Electron.IpcRendererEvent, prefs: AiPanelPrefs) => handler(prefs)
    ipcRenderer.on('app:ai-panel-prefs-changed', listener)
    return () => ipcRenderer.removeListener('app:ai-panel-prefs-changed', listener)
  },
  onChromePressed(handler) {
    const listener = () => handler()
    ipcRenderer.on('app:chrome-pressed', listener)
    return () => ipcRenderer.removeListener('app:chrome-pressed', listener)
  },
  async selectWorkbook() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.selectWorkbook)
    if (result === null) return null
    if (
      typeof result === 'object' &&
      result !== null &&
      (result as { passwordRequired?: unknown }).passwordRequired === true &&
      typeof (result as { path?: unknown }).path === 'string'
    ) {
      return { passwordRequired: true, path: (result as { path: string }).path }
    }
    return parseWorkbookFile(result)
  },
  async openEncryptedWorkbook(path, password) {
    if (
      typeof path !== 'string' ||
      path.length === 0 ||
      typeof password !== 'string' ||
      password.length === 0
    ) {
      throw new Error('Invalid encrypted workbook request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.openEncryptedWorkbook, {
      path,
      password,
    })
    return result === null ? null : parseWorkbookFile(result)
  },
  async updateWorkbookPassword(sessionId, newPassword) {
    if (!isUuid(sessionId) || typeof newPassword !== 'string' || newPassword.length === 0) {
      throw new Error('Invalid workbook password update request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.updateWorkbookPassword, {
      sessionId,
      newPassword,
    })
    if (
      !isRecord(result) ||
      typeof result.sha256 !== 'string' ||
      !/^[a-f0-9]{64}$/i.test(result.sha256) ||
      typeof result.fileBytes !== 'number' ||
      !Number.isSafeInteger(result.fileBytes) ||
      result.fileBytes < 0 ||
      result.passwordProtected !== true
    ) {
      throw new Error('Invalid workbook password update response.')
    }
    return {
      sha256: result.sha256,
      fileBytes: result.fileBytes,
      passwordProtected: true as const,
    }
  },
  async selectWorkbooksForMerge() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.selectWorkbooksForMerge)
    if (result === null) return null
    if (!Array.isArray(result)) throw new Error('Invalid merge selection result.')
    return result.map((file) => parseWorkbookFile(file))
  },
  async openWorkbooksForMerge(paths) {
    if (!Array.isArray(paths) || paths.some((p) => typeof p !== 'string')) {
      throw new Error('Invalid merge paths.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.openWorkbooksForMerge, paths)
    if (result === null) return null
    if (!Array.isArray(result)) throw new Error('Invalid merge open result.')
    return result.map((file) => parseWorkbookFile(file))
  },
  async reopenWorkbook(path) {
    if (typeof path !== 'string' || path.length === 0) {
      throw new Error('Invalid reopen path.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.reopenWorkbook, path)
    if (result === null) return null
    // the password of a session that is already gone cannot be replayed; the
    // recovery gives up cleanly and the user re-opens the file by hand
    if (isRecord(result) && result.passwordRequired === true) return null
    return parseWorkbookFile(result)
  },
  onSidecarCrashed(callback) {
    const listener = (): void => {
      callback()
    }
    ipcRenderer.on(IPC_CHANNELS.sidecarCrashed, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.sidecarCrashed, listener)
  },
  async readWorkbookRange(request) {
    const validatedRequest = parseRangeRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.readWorkbookRange,
      validatedRequest,
    )
    return parseRangeResult(result)
  },
  async readWorkbookFormulas(request) {
    const validatedRequest = parseFormulaCellsRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.readWorkbookFormulas,
      validatedRequest,
    )
    return parseFormulaCellsResult(result)
  },
  async findWorkbookCells(request) {
    const validatedRequest = parseFindCellsRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.findWorkbookCells,
      validatedRequest,
    )
    return parseFindCellsResult(result)
  },
  async readWorkbookRowOutline(request) {
    const validatedRequest = parseFormulaCellsRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.readWorkbookRowOutline,
      validatedRequest,
    )
    return parseRowOutlineResult(result)
  },
  async recalcWorkbook(request) {
    const validatedRequest = parseRecalcRequest(request)
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.recalcWorkbook, validatedRequest)
    return parseRecalcResult(result)
  },
  async readWorkbookMedia(request) {
    const validatedRequest = parseMediaRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.readWorkbookMedia,
      validatedRequest,
    )
    return parseMediaResult(result)
  },
  async readLocalImage(request) {
    if (
      !isRecord(request) ||
      typeof request.path !== 'string' ||
      request.path.length === 0 ||
      request.path.length > 1024
    ) {
      throw new Error('Invalid local image request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.readLocalImage, request)
    if (
      !isRecord(result) ||
      typeof result.mediaType !== 'string' ||
      !['image/png', 'image/jpeg', 'image/gif'].includes(result.mediaType) ||
      typeof result.base64 !== 'string' ||
      result.base64.length === 0
    ) {
      throw new Error('Invalid local image response.')
    }
    return result as { mediaType: 'image/png' | 'image/jpeg' | 'image/gif'; base64: string }
  },
  async captureScreenSources() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.captureScreenSources)
    if (
      !isRecord(result) ||
      (result.status !== 'ok' && result.status !== 'denied') ||
      !Array.isArray(result.sources)
    ) {
      throw new Error('Invalid screen sources response.')
    }
    return result as ScreenSourcesResult
  },
  async captureScreenSource(request) {
    if (!isRecord(request) || typeof request.id !== 'string' || request.id.length === 0) {
      throw new Error('Invalid screen capture request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.captureScreenSource, {
      id: request.id,
    })
    if (result === null) return null
    if (
      !isRecord(result) ||
      result.mediaType !== 'image/png' ||
      typeof result.base64 !== 'string' ||
      result.base64.length === 0 ||
      typeof result.width !== 'number' ||
      typeof result.height !== 'number'
    ) {
      throw new Error('Invalid screen capture response.')
    }
    return result as ScreenCaptureResult
  },
  async readPivotDefinition(request) {
    const validatedRequest = parsePivotRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.readPivotDefinition,
      validatedRequest,
    )
    return parsePivotDefinitionResult(result)
  },
  async readWorkbookRedactions(request) {
    if (!isRecord(request) || !isUuid(request.sessionId)) {
      throw new Error('Invalid redaction request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.readWorkbookRedactions, {
      sessionId: request.sessionId,
    })
    return parseWorkbookRedactionsResult(result)
  },
  async saveWorkbookEdits(request) {
    const validatedRequest = parseSaveRequest(request)
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.saveWorkbook, validatedRequest)
    return parseSaveResult(result)
  },
  async beginSaveEditsTransfer(request) {
    if (!isRecord(request)) throw new Error('Invalid save transfer request.')
    if (!isUuid(request.sessionId)) throw new Error('Invalid save transfer session.')
    if (!isUuid(request.transferId)) throw new Error('Invalid save transfer id.')
    if (
      typeof request.total !== 'number' ||
      !Number.isInteger(request.total) ||
      request.total <= 0 ||
      request.total > MAX_SAVE_EDITS_TOTAL
    ) {
      throw new Error(
        `Invalid save transfer size. (${String(request.total)} exceeds the ${MAX_SAVE_EDITS_TOTAL} limit)`,
      )
    }
    await ipcRenderer.invoke(IPC_CHANNELS.saveEditsBegin, {
      sessionId: request.sessionId,
      transferId: request.transferId,
      total: request.total,
    })
  },
  async sendSaveEditsChunk(request) {
    if (!isRecord(request)) throw new Error('Invalid save transfer chunk.')
    if (!isUuid(request.sessionId)) throw new Error('Invalid save transfer session.')
    if (!isUuid(request.transferId)) throw new Error('Invalid save transfer id.')
    if (typeof request.seq !== 'number' || !Number.isInteger(request.seq) || request.seq < 0)
      throw new Error('Invalid save transfer chunk index.')
    // The edits stay a JSON string end to end here: the main process parses
    // and validates each chunk against the cell-edit schema before storing.
    if (
      typeof request.editsJson !== 'string' ||
      request.editsJson.length < 2 ||
      request.editsJson.length > SAVE_EDITS_CHUNK_JSON_MAX
    ) {
      throw new Error('Invalid save transfer chunk edits.')
    }
    await ipcRenderer.invoke(IPC_CHANNELS.saveEditsChunk, {
      sessionId: request.sessionId,
      transferId: request.transferId,
      seq: request.seq,
      editsJson: request.editsJson,
    })
  },
  async abortSaveEditsTransfer(request) {
    if (!isRecord(request)) throw new Error('Invalid save transfer request.')
    if (!isUuid(request.sessionId)) throw new Error('Invalid save transfer session.')
    if (!isUuid(request.transferId)) throw new Error('Invalid save transfer id.')
    await ipcRenderer.invoke(IPC_CHANNELS.saveEditsAbort, {
      sessionId: request.sessionId,
      transferId: request.transferId,
    })
  },
  async writeWorkbookRecovery(request) {
    const validatedRequest = parseSaveRequest(request)
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.writeWorkbookRecovery,
      validatedRequest,
    )
    return { ok: (result as { ok?: unknown } | null)?.ok === true }
  },
  async autoRenameWorkbook(sessionId, baseName) {
    if (!isUuid(sessionId)) throw new Error('Invalid workbook session.')
    if (typeof baseName !== 'string' || baseName.length === 0 || baseName.length > 100) {
      throw new Error('Invalid workbook name.')
    }
    const result: unknown = await ipcRenderer.invoke(
      IPC_CHANNELS.autoRenameWorkbook,
      sessionId,
      baseName,
    )
    if (!isRecord(result) || typeof result.renamed !== 'boolean') {
      throw new Error('Invalid auto-rename response.')
    }
    return result as { renamed: boolean; name?: string }
  },
  async exportPdf(request) {
    if (!isPdfExportRequest(request)) throw new Error('Invalid PDF export request.')
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.exportPdf, request)
    if (
      !isRecord(result) ||
      typeof result.canceled !== 'boolean' ||
      (result.canceled === false && typeof result.path !== 'string')
    ) {
      throw new Error('Invalid PDF export response.')
    }
    return result as { canceled: true } | { canceled: false; path: string }
  },
  async printWorkbook(request) {
    if (!isPdfExportRequest(request)) throw new Error('Invalid print request.')
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.printWorkbook, request)
    if (
      !isRecord(result) ||
      typeof result.ok !== 'boolean' ||
      (result.error !== undefined && typeof result.error !== 'string')
    ) {
      throw new Error('Invalid print response.')
    }
    return result as { ok: true } | { ok: false; error?: string }
  },
  async listPrinters() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.listPrinters)
    if (!Array.isArray(result)) throw new Error('Invalid printer list.')
    return result.filter(
      (entry): entry is { name: string; displayName: string } =>
        isRecord(entry) && typeof entry.name === 'string' && typeof entry.displayName === 'string',
    )
  },
  async exportCsv(request) {
    if (
      !isRecord(request) ||
      typeof request.fileName !== 'string' ||
      request.fileName.length === 0 ||
      request.fileName.length > 255 ||
      typeof request.content !== 'string' ||
      request.content.length > MAX_CSV_EXPORT_CHARS ||
      typeof request.hasFormulas !== 'boolean' ||
      (request.activeSheetName !== undefined &&
        (typeof request.activeSheetName !== 'string' || request.activeSheetName.length > 255)) ||
      (request.targetPath !== undefined &&
        (typeof request.targetPath !== 'string' || request.targetPath.length === 0))
    ) {
      throw new Error('Invalid CSV export request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.exportCsv, request)
    if (
      !isRecord(result) ||
      typeof result.canceled !== 'boolean' ||
      (result.canceled === false && typeof result.path !== 'string') ||
      (result.canceled === true &&
        result.saveAsXlsxInstead !== undefined &&
        typeof result.saveAsXlsxInstead !== 'boolean')
    ) {
      throw new Error('Invalid CSV export response.')
    }
    return result as
      { canceled: true; saveAsXlsxInstead?: boolean } | { canceled: false; path: string }
  },
  async confirmCsvSave() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.csvSaveConfirm)
    if (result !== 'csv' && result !== 'xlsx' && result !== 'cancel') {
      throw new Error('Invalid CSV save confirmation response.')
    }
    return result
  },
  async createDocument(request) {
    if (
      !isRecord(request) ||
      (request.type !== 'xlsx' &&
        request.type !== 'csv' &&
        request.type !== 'docx' &&
        request.type !== 'pdf' &&
        request.type !== 'md') ||
      typeof request.title !== 'string' ||
      request.title.length === 0 ||
      request.title.length > MAX_CREATE_DOCUMENT_TITLE_CHARS ||
      typeof request.content !== 'string' ||
      request.content.length === 0 ||
      request.content.length >
        (request.type === 'xlsx' || request.type === 'csv'
          ? MAX_CSV_EXPORT_CHARS
          : MAX_CREATE_DOCUMENT_CONTENT_CHARS) ||
      (request.sheetName !== undefined &&
        (typeof request.sheetName !== 'string' ||
          request.sheetName.length === 0 ||
          request.sheetName.length > 31))
    ) {
      throw new Error('Invalid create-document request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.createDocument, request)
    if (
      !isRecord(result) ||
      typeof result.ok !== 'boolean' ||
      (result.path !== undefined && typeof result.path !== 'string') ||
      (result.error !== undefined && typeof result.error !== 'string')
    ) {
      throw new Error('Invalid create-document response.')
    }
    return result as { ok: boolean; path?: string; error?: string }
  },
  async closeWorkbook(sessionId) {
    if (!isUuid(sessionId)) throw new Error('Invalid workbook session.')
    await ipcRenderer.invoke(IPC_CHANNELS.closeWorkbook, sessionId)
  },
  async openExternal(url) {
    if (typeof url !== 'string' || !/^https?:\/\//.test(url)) {
      throw new Error('Only http(s) links can be opened.')
    }
    await ipcRenderer.invoke(IPC_CHANNELS.openExternal, url)
  },
  onMenuAction(callback) {
    const listener = (_event: unknown, action: unknown): void => {
      if (
        action === 'open' ||
        action === 'save' ||
        action === 'save-as' ||
        action === 'print' ||
        action === 'export-pdf' ||
        action === 'export-csv' ||
        action === 'undo' ||
        action === 'redo'
      )
        callback(action)
    }
    ipcRenderer.on(IPC_CHANNELS.menuAction, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.menuAction, listener)
  },
  onWorkbookRenamed(callback) {
    const listener = (_event: unknown, newName: unknown): void => {
      if (typeof newName === 'string' && newName) callback(newName)
    }
    ipcRenderer.on(IPC_CHANNELS.workbookRenamed, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.workbookRenamed, listener)
  },
  notifyPendingEdits(count) {
    if (typeof count !== 'number' || !Number.isFinite(count) || count < 0) return
    ipcRenderer.send(IPC_CHANNELS.pendingEditsChanged, Math.floor(count))
  },
  onCloseSaveRequest(callback) {
    const listener = (): void => callback()
    ipcRenderer.on(IPC_CHANNELS.closeSaveRequest, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.closeSaveRequest, listener)
  },
  reportCloseSaveResult(ok) {
    ipcRenderer.send(IPC_CHANNELS.closeSaveResult, ok === true)
  },
  onRecoveryPrompt(callback) {
    const listener = (_event: unknown, payload: unknown): void => {
      if (
        isRecord(payload) &&
        typeof payload.title === 'string' &&
        typeof payload.body === 'string' &&
        typeof payload.restoreLabel === 'string' &&
        typeof payload.discardLabel === 'string' &&
        typeof payload.fileName === 'string' &&
        typeof payload.savedAtMs === 'number' &&
        Number.isFinite(payload.savedAtMs)
      ) {
        callback(payload as unknown as RecoveryPromptPayload)
      }
    }
    ipcRenderer.on(IPC_CHANNELS.recoveryPrompt, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.recoveryPrompt, listener)
  },
  replyRecoveryPrompt(restore) {
    ipcRenderer.send(IPC_CHANNELS.recoveryPromptReply, restore === true)
  },
  async getUserDisplayName() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.userDisplayName)
    return typeof result === 'string' ? result : ''
  },
  onUserDisplayNameChanged(handler) {
    const listener = (_event: Electron.IpcRendererEvent, name: unknown) => {
      if (typeof name === 'string') handler(name)
    }
    ipcRenderer.on('app:author-name-changed', listener)
    return () => ipcRenderer.removeListener('app:author-name-changed', listener)
  },
  async getAiSettings() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.aiGetSettings)
    if (!isRecord(result)) throw new Error('Invalid AI settings response.')
    return result as unknown as AiSettings
  },
  async setAiSettings(settings) {
    await ipcRenderer.invoke(IPC_CHANNELS.aiSetSettings, settings)
  },
  onAiSettingsChanged(handler) {
    const listener = () => handler()
    ipcRenderer.on(IPC_CHANNELS.aiSettingsChanged, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.aiSettingsChanged, listener)
  },
  async openAiModelSettings() {
    await ipcRenderer.invoke(IPC_CHANNELS.aiOpenModelSettings)
  },
  async openSkillsSettings() {
    await ipcRenderer.invoke('ai:open-skills-settings')
  },
  skillsList() {
    return ipcRenderer.invoke('ai:skills-list') as Promise<UserSkillEntry[]>
  },
  skillText(name: string) {
    return ipcRenderer.invoke('ai:skill-text', name) as Promise<string>
  },
  async aiChat(request) {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.aiChat, request)
    if (!isRecord(result) || typeof result.ok !== 'boolean') {
      throw new Error('Invalid AI chat response.')
    }
    return result as unknown as AiChatResponse
  },
  async aiStream(request) {
    await ipcRenderer.invoke(IPC_CHANNELS.aiStream, request)
  },
  async aiStreamCancel(requestId) {
    if (!requestId) throw new Error('Invalid AI stream request id.')
    await ipcRenderer.invoke(IPC_CHANNELS.aiStreamCancel, requestId)
  },
  async aiGskStatus(withEmail) {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.aiGskStatus, withEmail)
    if (!isRecord(result) || typeof result.loggedIn !== 'boolean') {
      throw new Error('Invalid Genspark account status response.')
    }
    return result as unknown as GenSparkAccountStatus
  },
  async aiGskLogin() {
    await ipcRenderer.invoke(IPC_CHANNELS.aiGskLogin)
  },
  async webSearch(query, maxResults) {
    if (typeof query !== 'string' || !query.trim() || query.length > 512) {
      throw new Error('Invalid search query.')
    }
    const result: unknown = await ipcRenderer.invoke('ai:web-search', query, maxResults)
    if (!isRecord(result) || !Array.isArray(result.results) || typeof result.method !== 'string') {
      throw new Error('Invalid web search response.')
    }
    return result as unknown as WebSearchResult
  },
  async imageSearch(query, maxResults) {
    if (typeof query !== 'string' || !query.trim() || query.length > 512) {
      throw new Error('Invalid search query.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.aiImageSearch, query, maxResults)
    if (!isRecord(result) || !Array.isArray(result.images) || typeof result.method !== 'string') {
      throw new Error('Invalid image search response.')
    }
    return result as unknown as ImageSearchResponse
  },
  async generateImage(op) {
    if (!isRecord(op) || typeof op.prompt !== 'string' || !op.prompt.trim()) {
      throw new Error('Invalid image generation request.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.aiGenerateImage, op)
    if (!isRecord(result)) throw new Error('Invalid image generation response.')
    return result as unknown as GenerateImageResult
  },
  async fetchImage(url) {
    if (typeof url !== 'string' || !/^https?:\/\//i.test(url) || url.length > 2048) {
      throw new Error('Invalid image URL.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.aiFetchImage, url)
    if (result === null) return null
    if (!isRecord(result) || typeof result.base64 !== 'string' || typeof result.mime !== 'string') {
      throw new Error('Invalid image download response.')
    }
    return result as { base64: string; mime: string }
  },
  onAiStream(callback) {
    const listener = (_event: unknown, chunk: unknown): void => {
      if (
        isRecord(chunk) &&
        typeof chunk.requestId === 'string' &&
        typeof chunk.type === 'string'
      ) {
        callback(chunk as unknown as AiStreamChunk)
      }
    }
    ipcRenderer.on(IPC_CHANNELS.aiStreamChunk, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.aiStreamChunk, listener)
  },
  async consumeNewBlankWorkbook() {
    const result: unknown = await ipcRenderer.invoke('sheets:consume-new-blank')
    return result === true
  },
  onMcpCommand(callback) {
    const listener = (_event: unknown, message: unknown): void => {
      if (
        isRecord(message) &&
        typeof message.requestId === 'string' &&
        typeof message.command === 'string'
      ) {
        callback(message as unknown as McpCommandMessage)
      }
    }
    ipcRenderer.on(IPC_CHANNELS.mcpCommand, listener)
    return () => ipcRenderer.removeListener(IPC_CHANNELS.mcpCommand, listener)
  },
  reportMcpResult(result) {
    if (!isRecord(result) || typeof result.requestId !== 'string') return
    ipcRenderer.send(IPC_CHANNELS.mcpResult, result)
  },
  signalMcpReady() {
    ipcRenderer.send(IPC_CHANNELS.mcpReady)
  },
  async hasQueuedWorkbook() {
    const result: unknown = await ipcRenderer.invoke('sheets:has-queued-workbook')
    return result === true
  },
  async consumeHeadlessExport() {
    const result: unknown = await ipcRenderer.invoke('sheets:consume-headless-export')
    return typeof result === 'string' ? result : null
  },
  headlessExportDone(result) {
    ipcRenderer.send('sheets:headless-export-done', {
      ok: result.ok === true,
      ...(typeof result.error === 'string' ? { error: result.error } : {}),
    })
  },
  async pickAttachments() {
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.filesPick)
    return result === null ? null : parseAttachmentAddResult(result)
  },
  async addAttachmentPaths(paths) {
    if (
      !Array.isArray(paths) ||
      paths.length === 0 ||
      paths.length > 50 ||
      paths.some((p) => typeof p !== 'string' || p.length === 0 || p.length > 1024)
    ) {
      throw new Error('Invalid attachment paths.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.filesAdd, paths)
    return parseAttachmentAddResult(result)
  },
  async addPastedImage(data, ext) {
    if (
      !(data instanceof ArrayBuffer) ||
      data.byteLength === 0 ||
      data.byteLength > 64 * 1024 * 1024
    ) {
      throw new Error('Invalid pasted image data.')
    }
    if (typeof ext !== 'string' || ext.length === 0 || ext.length > 8) {
      throw new Error('Invalid pasted image extension.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.filesAddPastedImage, data, ext)
    return parseAttachmentAddResult(result)
  },
  async readAttachment(path, offset, maxChars) {
    if (typeof path !== 'string' || path.length === 0 || path.length > 1024) {
      throw new Error('Invalid attachment path.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.filesRead, path, offset, maxChars)
    if (
      !isRecord(result) ||
      typeof result.ok !== 'boolean' ||
      !isOptionalString(result.error) ||
      !isOptionalString(result.name) ||
      !isOptionalString(result.text) ||
      (result.totalChars !== undefined && !isNonnegativeInteger(result.totalChars)) ||
      (result.offset !== undefined && !isNonnegativeInteger(result.offset))
    ) {
      throw new Error('Invalid attachment read response.')
    }
    const read: AttachmentReadResult = { ok: result.ok }
    if (result.error !== undefined) read.error = result.error
    if (result.name !== undefined) read.name = result.name
    if (result.text !== undefined) read.text = result.text
    if (result.totalChars !== undefined) read.totalChars = result.totalChars
    if (result.offset !== undefined) read.offset = result.offset
    return read
  },
  async readAttachmentImage(path) {
    if (typeof path !== 'string' || path.length === 0 || path.length > 1024) {
      throw new Error('Invalid attachment path.')
    }
    const result: unknown = await ipcRenderer.invoke(IPC_CHANNELS.filesReadImage, path)
    if (
      !isRecord(result) ||
      typeof result.ok !== 'boolean' ||
      !isOptionalString(result.base64) ||
      !isOptionalString(result.mime) ||
      !isOptionalString(result.error)
    ) {
      throw new Error('Invalid attachment image response.')
    }
    const image: AttachmentImageResult = { ok: result.ok }
    if (result.base64 !== undefined) image.base64 = result.base64
    if (result.mime !== undefined) image.mime = result.mime
    if (result.error !== undefined) image.error = result.error
    return image
  },
  getPathForFile(file) {
    return webUtils.getPathForFile(file)
  },
}

function parseAttachmentAddResult(input: unknown): AttachmentAddResult {
  if (
    !isRecord(input) ||
    !Array.isArray(input.accepted) ||
    input.accepted.length > 50 ||
    !Array.isArray(input.rejected) ||
    input.rejected.length > 50 ||
    input.rejected.some((reason) => typeof reason !== 'string')
  ) {
    throw new Error('Invalid attachment response.')
  }
  const accepted = input.accepted.map((meta): AttachmentMeta => {
    if (
      !isRecord(meta) ||
      typeof meta.path !== 'string' ||
      meta.path.length === 0 ||
      typeof meta.name !== 'string' ||
      meta.name.length === 0 ||
      typeof meta.ext !== 'string' ||
      !isNonnegativeInteger(meta.sizeBytes)
    ) {
      throw new Error('Invalid attachment metadata.')
    }
    return { path: meta.path, name: meta.name, ext: meta.ext, sizeBytes: meta.sizeBytes }
  })
  return { accepted, rejected: input.rejected as string[] }
}

contextBridge.exposeInMainWorld('desktopApi', desktopApi)

const projectApi: ProjectApi = {
  resolveChat: (args) => ipcRenderer.invoke('project:resolveChat', args),
  appendChat: (args) => ipcRenderer.invoke('project:appendChat', args),
  loadChat: (args) => ipcRenderer.invoke('project:loadChat', args),
  rebindChat: (args) => ipcRenderer.invoke('project:rebindChat', args),
  listChats: (args) => ipcRenderer.invoke('project:listChats', args),
  deleteChat: (args) => ipcRenderer.invoke('project:deleteChat', args),
}
contextBridge.exposeInMainWorld('projectApi', projectApi)

// Off by default. e2e drivers launch the BUILT app with GENOFFICE_DEBUG_HOOKS=1
// so the renderer exposes window.__genofficeDebug (see App.tsx) — the dev-only
// __univerAPI hook does not exist in production bundles.
if (process.env.GENOFFICE_DEBUG_HOOKS === '1') {
  contextBridge.exposeInMainWorld('__genofficeDebugHooks', true)
}

// open documents dragged from the OS onto this tab as a new shell tab
installDropOpenBridge()

function parseWorkbookFile(input: unknown): WorkbookFile {
  if (!isRecord(input)) throw new Error('Invalid workbook response.')
  const {
    sessionId,
    name,
    path,
    sha256,
    fileBytes,
    entryCount,
    sheets,
    styles,
    dxfStyles,
    visuals,
    definedNames,
    readOnly,
    needsSaveAs,
    csvPath,
    emptyCsv,
    restoredFromRecovery,
  } = input
  if (
    !isUuid(sessionId) ||
    typeof name !== 'string' ||
    (path !== undefined && (typeof path !== 'string' || path.length === 0)) ||
    typeof sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/.test(sha256) ||
    (fileBytes !== undefined && !isNonnegativeInteger(fileBytes)) ||
    !isNonnegativeInteger(entryCount) ||
    !Array.isArray(sheets) ||
    !Array.isArray(styles) ||
    !Array.isArray(dxfStyles) ||
    !Array.isArray(visuals) ||
    !Array.isArray(definedNames) ||
    typeof readOnly !== 'boolean' ||
    (needsSaveAs !== undefined && typeof needsSaveAs !== 'boolean') ||
    (csvPath !== undefined && (typeof csvPath !== 'string' || csvPath.length === 0)) ||
    (emptyCsv !== undefined && typeof emptyCsv !== 'boolean') ||
    (restoredFromRecovery !== undefined && typeof restoredFromRecovery !== 'boolean')
  ) {
    throw new Error('Invalid workbook response.')
  }
  const parsedDefinedNames = definedNames.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.name !== 'string' ||
      entry.name.length === 0 ||
      typeof entry.formula !== 'string' ||
      entry.formula.length === 0 ||
      (entry.sheetIndex !== undefined && !isNonnegativeInteger(entry.sheetIndex))
    ) {
      throw new Error('Invalid workbook defined name.')
    }
    return {
      name: entry.name,
      formula: entry.formula,
      ...(entry.sheetIndex === undefined ? {} : { sheetIndex: entry.sheetIndex }),
    }
  })
  const parsedSheets = sheets.map((sheet) => {
    if (
      !isRecord(sheet) ||
      typeof sheet.id !== 'string' ||
      typeof sheet.name !== 'string' ||
      !isPositiveInteger(sheet.rowCount) ||
      !isPositiveInteger(sheet.columnCount) ||
      !Array.isArray(sheet.columnWidths) ||
      typeof sheet.hidden !== 'boolean' ||
      (sheet.tabColor !== null && typeof sheet.tabColor !== 'string') ||
      typeof sheet.showGridLines !== 'boolean' ||
      !Array.isArray(sheet.tables) ||
      !Array.isArray(sheet.comments) ||
      !Array.isArray(sheet.pivotRanges) ||
      sheet.pivotRanges.length > 1_000
    ) {
      throw new Error('Invalid worksheet metadata.')
    }
    const tables = sheet.tables.map((table) => {
      if (
        !isRecord(table) ||
        !isNonnegativeInteger(table.headerRowCount) ||
        typeof table.showRowStripes !== 'boolean' ||
        typeof table.showColumnStripes !== 'boolean' ||
        (table.filterActive !== undefined && typeof table.filterActive !== 'boolean') ||
        !isOptionalString(table.styleName) ||
        !isOptionalString(table.name) ||
        (table.columns !== undefined &&
          (!Array.isArray(table.columns) ||
            table.columns.some((column: unknown) => typeof column !== 'string'))) ||
        !isOptionalString(table.headerFill) ||
        !isOptionalString(table.headerFontColor) ||
        !isOptionalString(table.stripeFill) ||
        !isOptionalString(table.secondRowStripeFill) ||
        !isOptionalString(table.columnStripeFill) ||
        !isOptionalString(table.secondColumnStripeFill) ||
        !isOptionalString(table.wholeTableFill) ||
        !isOptionalString(table.firstColumnFill) ||
        !isOptionalString(table.lastColumnFill) ||
        !isOptionalString(table.totalRowFill) ||
        !isOptionalString(table.totalRowFontColor) ||
        !isOptionalString(table.totalRowBorderColor) ||
        !isOptionalString(table.totalRowBorderStyle) ||
        !isOptionalString(table.bodyFontColor) ||
        !isOptionalString(table.firstHeaderCellFontColor) ||
        !isOptionalString(table.borderColor) ||
        !isOptionalString(table.wholeTableBorderColor) ||
        !isOptionalString(table.wholeTableBorderStyle) ||
        !isOptionalString(table.innerHorizontalBorderColor) ||
        !isOptionalString(table.innerHorizontalBorderStyle) ||
        !isOptionalString(table.innerVerticalBorderColor) ||
        !isOptionalString(table.innerVerticalBorderStyle) ||
        !isOptionalString(table.headerBottomBorderColor) ||
        !isOptionalString(table.headerBottomBorderStyle) ||
        (table.totalsRowCount !== undefined && !isNonnegativeInteger(table.totalsRowCount))
      ) {
        throw new Error('Invalid worksheet table.')
      }
      return {
        range: parseCellArea(table.range),
        headerRowCount: table.headerRowCount,
        showRowStripes: table.showRowStripes,
        showColumnStripes: table.showColumnStripes,
        ...(table.filterActive === undefined ? {} : { filterActive: table.filterActive }),
        ...(table.name === undefined ? {} : { name: table.name }),
        ...(table.columns === undefined ? {} : { columns: table.columns }),
        ...(table.styleName === undefined ? {} : { styleName: table.styleName }),
        ...(table.headerFill === undefined ? {} : { headerFill: table.headerFill }),
        ...(table.headerFontColor === undefined ? {} : { headerFontColor: table.headerFontColor }),
        ...(table.stripeFill === undefined ? {} : { stripeFill: table.stripeFill }),
        ...(table.secondRowStripeFill === undefined
          ? {}
          : { secondRowStripeFill: table.secondRowStripeFill }),
        ...(table.columnStripeFill === undefined
          ? {}
          : { columnStripeFill: table.columnStripeFill }),
        ...(table.secondColumnStripeFill === undefined
          ? {}
          : { secondColumnStripeFill: table.secondColumnStripeFill }),
        ...(table.wholeTableFill === undefined ? {} : { wholeTableFill: table.wholeTableFill }),
        ...(table.firstColumnFill === undefined ? {} : { firstColumnFill: table.firstColumnFill }),
        ...(table.lastColumnFill === undefined ? {} : { lastColumnFill: table.lastColumnFill }),
        ...(table.totalRowFill === undefined ? {} : { totalRowFill: table.totalRowFill }),
        ...(table.totalRowFontColor === undefined
          ? {}
          : { totalRowFontColor: table.totalRowFontColor }),
        ...(table.totalRowBorderColor === undefined
          ? {}
          : { totalRowBorderColor: table.totalRowBorderColor }),
        ...(table.totalRowBorderStyle === undefined
          ? {}
          : { totalRowBorderStyle: table.totalRowBorderStyle }),
        ...(table.bodyFontColor === undefined ? {} : { bodyFontColor: table.bodyFontColor }),
        ...(table.firstHeaderCellFontColor === undefined
          ? {}
          : { firstHeaderCellFontColor: table.firstHeaderCellFontColor }),
        ...(table.totalsRowCount === undefined ? {} : { totalsRowCount: table.totalsRowCount }),
        ...(table.borderColor === undefined ? {} : { borderColor: table.borderColor }),
        ...(table.wholeTableBorderColor === undefined
          ? {}
          : { wholeTableBorderColor: table.wholeTableBorderColor }),
        ...(table.wholeTableBorderStyle === undefined
          ? {}
          : { wholeTableBorderStyle: table.wholeTableBorderStyle }),
        ...(table.innerHorizontalBorderColor === undefined
          ? {}
          : { innerHorizontalBorderColor: table.innerHorizontalBorderColor }),
        ...(table.innerHorizontalBorderStyle === undefined
          ? {}
          : { innerHorizontalBorderStyle: table.innerHorizontalBorderStyle }),
        ...(table.innerVerticalBorderColor === undefined
          ? {}
          : { innerVerticalBorderColor: table.innerVerticalBorderColor }),
        ...(table.innerVerticalBorderStyle === undefined
          ? {}
          : { innerVerticalBorderStyle: table.innerVerticalBorderStyle }),
        ...(table.headerBottomBorderColor === undefined
          ? {}
          : { headerBottomBorderColor: table.headerBottomBorderColor }),
        ...(table.headerBottomBorderStyle === undefined
          ? {}
          : { headerBottomBorderStyle: table.headerBottomBorderStyle }),
      }
    })
    const comments = sheet.comments.map((comment) => {
      if (
        !isRecord(comment) ||
        !isNonnegativeInteger(comment.row) ||
        !isNonnegativeInteger(comment.column) ||
        typeof comment.author !== 'string' ||
        typeof comment.text !== 'string'
      ) {
        throw new Error('Invalid worksheet comment.')
      }
      return {
        row: comment.row,
        column: comment.column,
        author: comment.author,
        text: comment.text,
      }
    })
    const columnWidths = sheet.columnWidths.map((columnWidth) => {
      if (
        !isRecord(columnWidth) ||
        !isNonnegativeInteger(columnWidth.startColumn) ||
        !isNonnegativeInteger(columnWidth.endColumn) ||
        columnWidth.startColumn > columnWidth.endColumn ||
        (columnWidth.width !== undefined &&
          (typeof columnWidth.width !== 'number' ||
            !Number.isFinite(columnWidth.width) ||
            columnWidth.width < 0)) ||
        typeof columnWidth.hidden !== 'boolean' ||
        (columnWidth.outlineLevel !== undefined &&
          (!isNonnegativeInteger(columnWidth.outlineLevel) || columnWidth.outlineLevel > 7)) ||
        (columnWidth.collapsed !== undefined && typeof columnWidth.collapsed !== 'boolean') ||
        (columnWidth.styleIndex !== undefined &&
          (!isNonnegativeInteger(columnWidth.styleIndex) || columnWidth.styleIndex === 0))
      ) {
        throw new Error('Invalid worksheet column width.')
      }
      return {
        startColumn: columnWidth.startColumn,
        endColumn: columnWidth.endColumn,
        hidden: columnWidth.hidden,
        ...(columnWidth.width === undefined ? {} : { width: columnWidth.width }),
        ...(columnWidth.outlineLevel === undefined
          ? {}
          : { outlineLevel: columnWidth.outlineLevel }),
        ...(columnWidth.collapsed === undefined ? {} : { collapsed: columnWidth.collapsed }),
        ...(columnWidth.styleIndex === undefined ? {} : { styleIndex: columnWidth.styleIndex }),
      }
    })
    return {
      id: sheet.id,
      name: sheet.name,
      rowCount: sheet.rowCount,
      columnCount: sheet.columnCount,
      // The renderer's oversized-sheet write gate needs this; omitting it
      // silently disables the gate (older sidecars don't report it).
      ...(isPositiveInteger(sheet.sourceXmlBytes) ? { sourceXmlBytes: sheet.sourceXmlBytes } : {}),
      ...(isNonnegativeInteger(sheet.storedCellCount)
        ? { storedCellCount: sheet.storedCellCount }
        : {}),
      ...(isNonnegativeInteger(sheet.valueCellCount)
        ? { valueCellCount: sheet.valueCellCount }
        : {}),
      ...(isNonnegativeInteger(sheet.valueRowCount) && isNonnegativeInteger(sheet.valueColumnCount)
        ? { valueRowCount: sheet.valueRowCount, valueColumnCount: sheet.valueColumnCount }
        : {}),
      columnWidths,
      // Degrade instead of rejecting the workbook: 0 / malformed defaults
      // mean "use the built-in size".
      defaultRowHeight: normalizedDefaultSize(sheet.defaultRowHeight),
      ...(sheet.defaultRowHeightFixed === true ? { defaultRowHeightFixed: true } : {}),
      defaultColumnWidth: normalizedDefaultSize(sheet.defaultColumnWidth),
      baseColumnWidth: normalizedDefaultSize(sheet.baseColumnWidth),
      freeze: parseFreeze(sheet.freeze),
      hidden: sheet.hidden,
      ...(sheet.veryHidden === true ? { veryHidden: true } : {}),
      tabColor: sheet.tabColor,
      showGridLines: sheet.showGridLines,
      showFormulas: sheet.showFormulas === true,
      showRowColHeaders: sheet.showRowColHeaders !== false,
      rightToLeft: sheet.rightToLeft === true,
      ...(typeof sheet.zoomScale === 'number' &&
      Number.isInteger(sheet.zoomScale) &&
      sheet.zoomScale >= 10 &&
      sheet.zoomScale <= 400
        ? { zoomScale: sheet.zoomScale }
        : {}),
      ...(isOutlineLevel(sheet.outlineLevelRow) ? { outlineLevelRow: sheet.outlineLevelRow } : {}),
      ...(isOutlineLevel(sheet.outlineLevelCol) ? { outlineLevelCol: sheet.outlineLevelCol } : {}),
      ...(sheet.outlineSummaryBelow === false ? { outlineSummaryBelow: false as const } : {}),
      ...(sheet.outlineSummaryRight === false ? { outlineSummaryRight: false as const } : {}),
      tables,
      comments,
      pivotRanges: sheet.pivotRanges.map(parseCellArea),
      pivotTables: parsePivotTableInfos(sheet.pivotTables ?? []),
      sparklines: parseSparklineGroups(sheet.sparklines ?? []),
      cellImages: parseCellImages(sheet.cellImages ?? []),
      ...(isBoundedString(sheet.printArea, 2_000) ? { printArea: sheet.printArea } : {}),
      ...(isBoundedString(sheet.printTitles, 2_000) ? { printTitles: sheet.printTitles } : {}),
      ...(sheet.hasScopedDefinedNames === true ? { hasScopedDefinedNames: true } : {}),
    }
  })
  if (parsedSheets.length === 0) throw new Error('Workbook contains no worksheets.')
  const { themeColors, themeFonts, workbookProtection } = input
  if (
    themeColors !== undefined &&
    (!Array.isArray(themeColors) ||
      themeColors.length !== 12 ||
      themeColors.some((color) => typeof color !== 'string'))
  ) {
    throw new Error('Invalid workbook theme palette response.')
  }
  let parsedThemeFonts: { major: string; minor: string; minorEa?: string } | undefined
  if (themeFonts !== undefined) {
    if (
      !isRecord(themeFonts) ||
      typeof themeFonts.major !== 'string' ||
      typeof themeFonts.minor !== 'string'
    ) {
      throw new Error('Invalid workbook theme fonts response.')
    }
    parsedThemeFonts = {
      major: themeFonts.major,
      minor: themeFonts.minor,
      ...(typeof themeFonts.minorEa === 'string' ? { minorEa: themeFonts.minorEa } : {}),
    }
  }
  let parsedWorkbookProtection: { lockStructure: boolean; hasPassword: boolean } | undefined
  if (workbookProtection !== undefined) {
    if (
      !isRecord(workbookProtection) ||
      typeof workbookProtection.lockStructure !== 'boolean' ||
      typeof workbookProtection.hasPassword !== 'boolean'
    ) {
      throw new Error('Invalid workbook protection response.')
    }
    parsedWorkbookProtection = {
      lockStructure: workbookProtection.lockStructure,
      hasPassword: workbookProtection.hasPassword,
    }
  }
  const activeTab = isNonnegativeInteger(input.activeTab) ? input.activeTab : 0
  const date1904 = input.date1904 === true
  const shortDateFormat =
    typeof input.shortDateFormat === 'string' ? input.shortDateFormat : undefined
  return {
    sessionId,
    name,
    ...(path === undefined ? {} : { path }),
    sha256,
    ...(fileBytes === undefined ? {} : { fileBytes }),
    entryCount,
    sheets: parsedSheets,
    activeTab,
    styles: styles.map(parseCellStyle),
    dxfStyles: dxfStyles.map(parseCellStyle),
    visuals: visuals.map(parseVisualObject),
    definedNames: parsedDefinedNames,
    readOnly,
    ...(needsSaveAs === undefined ? {} : { needsSaveAs }),
    ...(csvPath === undefined ? {} : { csvPath }),
    ...(emptyCsv === undefined ? {} : { emptyCsv }),
    ...(restoredFromRecovery === undefined ? {} : { restoredFromRecovery }),
    ...(themeColors === undefined ? {} : { themeColors: themeColors as string[] }),
    ...(parsedThemeFonts === undefined ? {} : { themeFonts: parsedThemeFonts }),
    ...(typeof input.normalFontName === 'string' && input.normalFontName !== ''
      ? { normalFontName: input.normalFontName }
      : {}),
    ...(parsedWorkbookProtection === undefined
      ? {}
      : { workbookProtection: parsedWorkbookProtection }),
    ...(date1904 ? { date1904 } : {}),
    ...(shortDateFormat === undefined ? {} : { shortDateFormat }),
  }
}

function parseRangeRequest(input: WorkbookRangeRequest): WorkbookRangeRequest {
  if (
    !isRecord(input) ||
    !isUuid(input.sessionId) ||
    typeof input.sheetId !== 'string' ||
    !isRecord(input.range)
  ) {
    throw new Error('Invalid workbook range request.')
  }
  const { startRow, endRow, startColumn, endColumn } = input.range
  if (
    !isNonnegativeInteger(startRow) ||
    !isNonnegativeInteger(endRow) ||
    !isNonnegativeInteger(startColumn) ||
    !isNonnegativeInteger(endColumn) ||
    startRow > endRow ||
    startColumn > endColumn ||
    (endRow - startRow + 1) * (endColumn - startColumn + 1) > 100_000
  ) {
    throw new Error('Invalid workbook range request.')
  }
  return input
}

function parseCellRecord(cell: unknown): WorkbookRangeResult['cells'][number] {
  if (
    !isRecord(cell) ||
    !isNonnegativeInteger(cell.row) ||
    !isNonnegativeInteger(cell.column) ||
    !isCellScalar(cell.value) ||
    (cell.formula !== undefined && typeof cell.formula !== 'string') ||
    (cell.arrayRef !== undefined &&
      (typeof cell.arrayRef !== 'string' || cell.arrayRef.length > 64)) ||
    (cell.styleIndex !== undefined && !isNonnegativeInteger(cell.styleIndex))
  ) {
    throw new Error('Invalid workbook cell response.')
  }
  const rich = cell.rich === undefined ? undefined : parseRichRuns(cell.rich)
  return {
    row: cell.row,
    column: cell.column,
    value: cell.value,
    ...(cell.formula === undefined ? {} : { formula: cell.formula }),
    ...(cell.arrayRef === undefined ? {} : { arrayRef: cell.arrayRef }),
    ...(cell.styleIndex === undefined ? {} : { styleIndex: cell.styleIndex }),
    ...(rich === undefined ? {} : { rich }),
  }
}

function parseFormulaCellsRequest(input: unknown): WorkbookFormulaCellsRequest {
  if (
    !isRecord(input) ||
    !isUuid(input.sessionId) ||
    typeof input.sheetId !== 'string' ||
    input.sheetId.length === 0
  ) {
    throw new Error('Invalid formula-cells request.')
  }
  return { sessionId: input.sessionId, sheetId: input.sheetId }
}

function parseSharedFormulaGroup(group: unknown): WorkbookSharedFormulaGroup {
  if (
    !isRecord(group) ||
    !isNonnegativeInteger(group.si) ||
    !isNonnegativeInteger(group.row) ||
    !isNonnegativeInteger(group.column) ||
    typeof group.formula !== 'string' ||
    (group.range !== undefined &&
      !(
        isRecord(group.range) &&
        isNonnegativeInteger(group.range.startRow) &&
        isNonnegativeInteger(group.range.endRow) &&
        isNonnegativeInteger(group.range.startColumn) &&
        isNonnegativeInteger(group.range.endColumn)
      )) ||
    (group.cells !== undefined &&
      !(
        Array.isArray(group.cells) &&
        group.cells.every(
          (cell) =>
            Array.isArray(cell) &&
            cell.length === 2 &&
            isNonnegativeInteger(cell[0]) &&
            isNonnegativeInteger(cell[1]),
        )
      ))
  ) {
    throw new Error('Invalid shared-formula group response.')
  }
  const range = group.range as WorkbookSharedFormulaGroup['range']
  const cells = group.cells as WorkbookSharedFormulaGroup['cells']
  return {
    si: group.si,
    row: group.row,
    column: group.column,
    formula: group.formula,
    ...(range === undefined
      ? {}
      : {
          range: {
            startRow: range.startRow,
            endRow: range.endRow,
            startColumn: range.startColumn,
            endColumn: range.endColumn,
          },
        }),
    ...(cells === undefined ? {} : { cells: cells.map(([row, column]) => [row, column]) }),
  }
}

function isOutlineLevel(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 7
}

function parseRowOutlineResult(input: unknown): WorkbookRowOutlineResult {
  if (
    !isRecord(input) ||
    !Array.isArray(input.rows) ||
    input.rows.length > 1_048_576 ||
    typeof input.indexingComplete !== 'boolean'
  ) {
    throw new Error('Invalid row-outline response.')
  }
  return {
    rows: input.rows.map((entry) => {
      if (
        !isRecord(entry) ||
        !isNonnegativeInteger(entry.row) ||
        !isNonnegativeInteger(entry.level) ||
        entry.level > 7
      ) {
        throw new Error('Invalid row-outline response.')
      }
      return {
        row: entry.row,
        level: entry.level,
        ...(entry.collapsed === true ? { collapsed: true } : {}),
        ...(entry.hidden === true ? { hidden: true } : {}),
      }
    }),
    indexingComplete: input.indexingComplete,
  }
}

function parseFormulaCellsResult(input: unknown): WorkbookFormulaCellsResult {
  if (
    !isRecord(input) ||
    !Array.isArray(input.cells) ||
    input.cells.length > 100_000 ||
    !Array.isArray(input.sharedGroups) ||
    input.sharedGroups.length > 100_000 ||
    typeof input.indexingComplete !== 'boolean' ||
    typeof input.truncated !== 'boolean'
  ) {
    throw new Error('Invalid formula-cells response.')
  }
  return {
    cells: input.cells.map(parseCellRecord),
    sharedGroups: input.sharedGroups.map(parseSharedFormulaGroup),
    indexingComplete: input.indexingComplete,
    truncated: input.truncated,
  }
}

const FIND_LOOK_IN = new Set(['values', 'formulas', 'formulas_only', 'both'])
const FIND_CELLS_PAGE_MAX = 100_000

function parseFindCursor(input: unknown): WorkbookFindCellsRequest['resumeAt'] {
  if (
    !isRecord(input) ||
    typeof input.sheetId !== 'string' ||
    input.sheetId.length === 0 ||
    !isNonnegativeInteger(input.row) ||
    !isNonnegativeInteger(input.column)
  ) {
    throw new Error('Invalid find-cells cursor.')
  }
  return { sheetId: input.sheetId, row: input.row, column: input.column }
}

function parseFindCellsRequest(input: unknown): WorkbookFindCellsRequest {
  if (
    !isRecord(input) ||
    !isUuid(input.sessionId) ||
    (input.sheetId !== undefined &&
      (typeof input.sheetId !== 'string' || input.sheetId.length === 0)) ||
    typeof input.query !== 'string' ||
    input.query.length === 0 ||
    input.query.length > 10_000 ||
    typeof input.matchCase !== 'boolean' ||
    typeof input.matchEntireCell !== 'boolean' ||
    typeof input.lookIn !== 'string' ||
    !FIND_LOOK_IN.has(input.lookIn) ||
    typeof input.wildcards !== 'boolean' ||
    !isNonnegativeInteger(input.limit) ||
    input.limit < 1 ||
    input.limit > FIND_CELLS_PAGE_MAX
  ) {
    throw new Error('Invalid find-cells request.')
  }
  return {
    sessionId: input.sessionId,
    ...(input.sheetId === undefined ? {} : { sheetId: input.sheetId }),
    query: input.query,
    matchCase: input.matchCase,
    matchEntireCell: input.matchEntireCell,
    lookIn: input.lookIn as WorkbookFindCellsRequest['lookIn'],
    wildcards: input.wildcards,
    ...(input.resumeAt === undefined ? {} : { resumeAt: parseFindCursor(input.resumeAt) }),
    limit: input.limit,
  }
}

function parseFindCellsResult(input: unknown): WorkbookFindCellsResult {
  if (
    !isRecord(input) ||
    !Array.isArray(input.matches) ||
    input.matches.length > FIND_CELLS_PAGE_MAX ||
    typeof input.complete !== 'boolean' ||
    typeof input.indexingComplete !== 'boolean'
  ) {
    throw new Error('Invalid find-cells response.')
  }
  const matches = input.matches.map((match): WorkbookFindCellsResult['matches'][number] => {
    if (
      !isRecord(match) ||
      typeof match.sheetId !== 'string' ||
      !isNonnegativeInteger(match.row) ||
      !isNonnegativeInteger(match.column) ||
      !isCellScalar(match.value) ||
      (match.valueText !== null && typeof match.valueText !== 'string') ||
      (match.formulaText !== undefined && typeof match.formulaText !== 'string')
    ) {
      throw new Error('Invalid find-cells match.')
    }
    return {
      sheetId: match.sheetId,
      row: match.row,
      column: match.column,
      value: match.value,
      valueText: match.valueText,
      ...(match.formulaText === undefined ? {} : { formulaText: match.formulaText }),
    }
  })
  return {
    matches,
    complete: input.complete,
    ...(input.nextCursor === undefined ? {} : { nextCursor: parseFindCursor(input.nextCursor) }),
    indexingComplete: input.indexingComplete,
  }
}

function parseRecalcRequest(input: unknown): WorkbookRecalcRequest {
  if (
    !isRecord(input) ||
    !isUuid(input.sessionId) ||
    !Array.isArray(input.edits) ||
    input.edits.length > 10_000 ||
    !Array.isArray(input.reads) ||
    input.reads.length > 200
  ) {
    throw new Error('Invalid workbook recalc request.')
  }
  let readCells = 0
  const reads = input.reads.map((read) => {
    if (!isRecord(read) || typeof read.sheetId !== 'string' || read.sheetId.length === 0) {
      throw new Error('Invalid workbook recalc request.')
    }
    const range = read.range
    if (
      !isRecord(range) ||
      !isNonnegativeInteger(range.startRow) ||
      !isNonnegativeInteger(range.endRow) ||
      !isNonnegativeInteger(range.startColumn) ||
      !isNonnegativeInteger(range.endColumn) ||
      range.startRow > range.endRow ||
      range.startColumn > range.endColumn
    ) {
      throw new Error('Invalid workbook recalc request.')
    }
    readCells += (range.endRow - range.startRow + 1) * (range.endColumn - range.startColumn + 1)
    return {
      sheetId: read.sheetId,
      range: {
        startRow: range.startRow,
        endRow: range.endRow,
        startColumn: range.startColumn,
        endColumn: range.endColumn,
      },
    }
  })
  if (readCells > 20_000) throw new Error('Invalid workbook recalc request.')
  const edits = input.edits.map((edit) => {
    if (
      !isRecord(edit) ||
      typeof edit.sheetId !== 'string' ||
      edit.sheetId.length === 0 ||
      !isNonnegativeInteger(edit.row) ||
      edit.row > 1_048_575 ||
      !isNonnegativeInteger(edit.column) ||
      edit.column > 16_383 ||
      typeof edit.input !== 'string' ||
      edit.input.length > 32_767
    ) {
      throw new Error('Invalid workbook recalc request.')
    }
    return { sheetId: edit.sheetId, row: edit.row, column: edit.column, input: edit.input }
  })
  return { sessionId: input.sessionId, edits, reads }
}

function parseRecalcResult(input: unknown): WorkbookRecalcResult {
  if (!isRecord(input) || !Array.isArray(input.cells) || input.cells.length > 20_000) {
    throw new Error('Invalid workbook recalc response.')
  }
  const cells = input.cells.map((cell) => {
    if (
      !isRecord(cell) ||
      typeof cell.sheetId !== 'string' ||
      cell.sheetId.length === 0 ||
      !isNonnegativeInteger(cell.row) ||
      !isNonnegativeInteger(cell.column) ||
      typeof cell.formatted !== 'string' ||
      (cell.number !== undefined &&
        (typeof cell.number !== 'number' || !Number.isFinite(cell.number))) ||
      (cell.isError !== undefined && typeof cell.isError !== 'boolean') ||
      typeof cell.isFormula !== 'boolean'
    ) {
      throw new Error('Invalid workbook recalc response.')
    }
    return {
      sheetId: cell.sheetId,
      row: cell.row,
      column: cell.column,
      formatted: cell.formatted,
      ...(cell.number === undefined ? {} : { number: cell.number }),
      ...(cell.isError ? { isError: true } : {}),
      isFormula: cell.isFormula,
    }
  })
  return { cells }
}

function parseRangeResult(input: unknown): WorkbookRangeResult {
  if (
    !isRecord(input) ||
    !Array.isArray(input.cells) ||
    input.cells.length > 100_000 ||
    !Array.isArray(input.rows) ||
    input.rows.length > 100_000 ||
    !Array.isArray(input.merges) ||
    input.merges.length > 100_000 ||
    !Array.isArray(input.hyperlinks) ||
    input.hyperlinks.length > 100_000 ||
    !Array.isArray(input.conditionalRules) ||
    input.conditionalRules.length > 100_000 ||
    (input.indexedThroughRow !== null && !isNonnegativeInteger(input.indexedThroughRow)) ||
    typeof input.indexingComplete !== 'boolean'
  ) {
    throw new Error('Invalid workbook range response.')
  }
  const cells = input.cells.map(parseCellRecord)
  const rows = input.rows.map((row) => {
    if (
      !isRecord(row) ||
      !isNonnegativeInteger(row.row) ||
      (row.height !== undefined &&
        (typeof row.height !== 'number' || !Number.isFinite(row.height) || row.height < 0)) ||
      typeof row.hidden !== 'boolean' ||
      (row.outlineLevel !== undefined &&
        (!isNonnegativeInteger(row.outlineLevel) || row.outlineLevel > 7)) ||
      (row.collapsed !== undefined && typeof row.collapsed !== 'boolean') ||
      (row.customHeight !== undefined && typeof row.customHeight !== 'boolean') ||
      (row.styleIndex !== undefined &&
        (!isNonnegativeInteger(row.styleIndex) || row.styleIndex === 0))
    ) {
      throw new Error('Invalid workbook row response.')
    }
    return {
      row: row.row,
      hidden: row.hidden,
      ...(row.height === undefined ? {} : { height: row.height }),
      ...(row.customHeight === undefined ? {} : { customHeight: row.customHeight }),
      ...(row.outlineLevel === undefined ? {} : { outlineLevel: row.outlineLevel }),
      ...(row.collapsed === undefined ? {} : { collapsed: row.collapsed }),
      ...(row.styleIndex === undefined ? {} : { styleIndex: row.styleIndex }),
    }
  })
  const merges = input.merges.map((merge) => {
    if (
      !isRecord(merge) ||
      !isNonnegativeInteger(merge.startRow) ||
      !isNonnegativeInteger(merge.startColumn) ||
      !isNonnegativeInteger(merge.endRow) ||
      !isNonnegativeInteger(merge.endColumn) ||
      merge.startRow > merge.endRow ||
      merge.startColumn > merge.endColumn
    ) {
      throw new Error('Invalid workbook merge response.')
    }
    return {
      startRow: merge.startRow,
      startColumn: merge.startColumn,
      endRow: merge.endRow,
      endColumn: merge.endColumn,
    }
  })
  const hyperlinks = input.hyperlinks.map((link) => {
    if (
      !isRecord(link) ||
      !isNonnegativeInteger(link.row) ||
      !isNonnegativeInteger(link.column) ||
      typeof link.target !== 'string'
    ) {
      throw new Error('Invalid workbook hyperlink response.')
    }
    return { row: link.row, column: link.column, target: link.target }
  })
  const conditionalRules = input.conditionalRules.map(parseConditionalRule)
  if (
    !Array.isArray(input.dataValidations) ||
    input.dataValidations.length > 20_000 ||
    (input.autoFilter !== null && !isRecord(input.autoFilter)) ||
    !Array.isArray(input.autoFilterColumns) ||
    input.autoFilterColumns.length > 1_000
  ) {
    throw new Error('Invalid workbook range response.')
  }
  const autoFilterColumns = input.autoFilterColumns.map(parseAutoFilterColumn)
  const dataValidations = input.dataValidations.map((rule) => {
    if (
      !isRecord(rule) ||
      !Array.isArray(rule.ranges) ||
      typeof rule.ruleType !== 'string' ||
      !isOptionalString(rule.operator) ||
      !Array.isArray(rule.formulas) ||
      rule.formulas.some((formula) => typeof formula !== 'string') ||
      typeof rule.allowBlank !== 'boolean' ||
      typeof rule.suppressDropdown !== 'boolean' ||
      typeof rule.showInputMessage !== 'boolean' ||
      typeof rule.showErrorMessage !== 'boolean' ||
      !isOptionalString(rule.errorStyle) ||
      !isOptionalString(rule.errorTitle) ||
      !isOptionalString(rule.error) ||
      !isOptionalString(rule.promptTitle) ||
      !isOptionalString(rule.prompt)
    ) {
      throw new Error('Invalid workbook data validation.')
    }
    return {
      ranges: rule.ranges.map(parseCellArea),
      ruleType: rule.ruleType,
      formulas: rule.formulas as string[],
      allowBlank: rule.allowBlank,
      suppressDropdown: rule.suppressDropdown,
      showInputMessage: rule.showInputMessage,
      showErrorMessage: rule.showErrorMessage,
      ...(rule.operator === undefined ? {} : { operator: rule.operator }),
      ...(rule.errorStyle === undefined ? {} : { errorStyle: rule.errorStyle }),
      ...(rule.errorTitle === undefined ? {} : { errorTitle: rule.errorTitle }),
      ...(rule.error === undefined ? {} : { error: rule.error }),
      ...(rule.promptTitle === undefined ? {} : { promptTitle: rule.promptTitle }),
      ...(rule.prompt === undefined ? {} : { prompt: rule.prompt }),
    }
  })
  let sheetProtection: WorkbookRangeResult['sheetProtection'] = null
  if (input.sheetProtection !== null && input.sheetProtection !== undefined) {
    const protection = input.sheetProtection
    if (
      !isRecord(protection) ||
      typeof protection.protected !== 'boolean' ||
      typeof protection.hasPassword !== 'boolean'
    ) {
      throw new Error('Invalid workbook sheet protection.')
    }
    sheetProtection = {
      protected: protection.protected,
      hasPassword: protection.hasPassword,
      ...(protection.allow === undefined
        ? {}
        : { allow: parseSheetProtectionAllow(protection.allow) }),
      ...(protection.password === undefined
        ? {}
        : { password: parseSheetPasswordHash(protection.password) }),
    }
  }
  const parseBreaks = (value: unknown, label: string): number[] => {
    if (!Array.isArray(value) || value.length > 1_024 || !value.every(isNonnegativeInteger)) {
      throw new Error(`Invalid workbook ${label} response.`)
    }
    return value as number[]
  }
  if (!Array.isArray(input.protectedRanges) || input.protectedRanges.length > 1_024) {
    throw new Error('Invalid workbook protected ranges response.')
  }
  const protectedRanges = input.protectedRanges.map((range) => {
    if (
      !isRecord(range) ||
      typeof range.name !== 'string' ||
      range.name === '' ||
      typeof range.sqref !== 'string' ||
      range.sqref === '' ||
      typeof range.hasPassword !== 'boolean'
    ) {
      throw new Error('Invalid workbook protected range response.')
    }
    return { name: range.name, sqref: range.sqref, hasPassword: range.hasPassword }
  })
  return {
    cells,
    rows,
    merges,
    hyperlinks,
    conditionalRules,
    autoFilter: input.autoFilter === null ? null : parseCellArea(input.autoFilter),
    autoFilterColumns,
    dataValidations,
    sheetProtection,
    rowBreaks: parseBreaks(input.rowBreaks, 'row breaks'),
    colBreaks: parseBreaks(input.colBreaks, 'column breaks'),
    protectedRanges,
    pageSetup: parsePagePrintSettings(input.pageSetup),
    indexedThroughRow: input.indexedThroughRow,
    indexingComplete: input.indexingComplete,
  }
}

function parsePagePrintSettings(input: unknown): WorkbookRangeResult['pageSetup'] {
  if (input === null || input === undefined) return null
  const boundedInt = (value: unknown, min: number, max: number): boolean =>
    typeof value === 'number' && Number.isInteger(value) && value >= min && value <= max
  if (
    !isRecord(input) ||
    (input.orientation !== undefined &&
      input.orientation !== 'portrait' &&
      input.orientation !== 'landscape') ||
    (input.paperSize !== undefined && !boundedInt(input.paperSize, 1, 256)) ||
    (input.scale !== undefined && !boundedInt(input.scale, 10, 400)) ||
    (input.fitToWidth !== undefined && !boundedInt(input.fitToWidth, 0, 32_767)) ||
    (input.fitToHeight !== undefined && !boundedInt(input.fitToHeight, 0, 32_767)) ||
    (input.fitToPage !== undefined && typeof input.fitToPage !== 'boolean') ||
    (input.printGridlines !== undefined && typeof input.printGridlines !== 'boolean') ||
    (input.printHeadings !== undefined && typeof input.printHeadings !== 'boolean') ||
    (input.oddHeader !== undefined && !isBoundedString(input.oddHeader, 500)) ||
    (input.oddFooter !== undefined && !isBoundedString(input.oddFooter, 500)) ||
    (input.differentOddEven !== undefined && typeof input.differentOddEven !== 'boolean') ||
    (input.differentFirst !== undefined && typeof input.differentFirst !== 'boolean') ||
    (input.headerFooterFixedSize !== undefined &&
      typeof input.headerFooterFixedSize !== 'boolean') ||
    (input.evenHeader !== undefined && !isBoundedString(input.evenHeader, 500)) ||
    (input.evenFooter !== undefined && !isBoundedString(input.evenFooter, 500)) ||
    (input.firstHeader !== undefined && !isBoundedString(input.firstHeader, 500)) ||
    (input.firstFooter !== undefined && !isBoundedString(input.firstFooter, 500)) ||
    (input.headerFooterPictures !== undefined &&
      !isHeaderFooterPictureList(input.headerFooterPictures))
  ) {
    throw new Error('Invalid workbook page setup response.')
  }
  let margins: WorkbookPagePrintSettings['margins']
  if (input.margins !== undefined) {
    const record = input.margins
    if (
      !isRecord(record) ||
      !['left', 'right', 'top', 'bottom', 'header', 'footer'].every((edge) => {
        const value = record[edge]
        return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 10
      })
    ) {
      throw new Error('Invalid workbook page margins response.')
    }
    margins = {
      left: record.left as number,
      right: record.right as number,
      top: record.top as number,
      bottom: record.bottom as number,
      header: record.header as number,
      footer: record.footer as number,
    }
  }
  const validated = input as WorkbookPagePrintSettings
  return {
    ...(validated.orientation === undefined ? {} : { orientation: validated.orientation }),
    ...(validated.paperSize === undefined ? {} : { paperSize: validated.paperSize }),
    ...(validated.scale === undefined ? {} : { scale: validated.scale }),
    ...(validated.fitToWidth === undefined ? {} : { fitToWidth: validated.fitToWidth }),
    ...(validated.fitToHeight === undefined ? {} : { fitToHeight: validated.fitToHeight }),
    ...(validated.fitToPage === undefined ? {} : { fitToPage: validated.fitToPage }),
    ...(margins === undefined ? {} : { margins }),
    ...(validated.printGridlines === undefined ? {} : { printGridlines: validated.printGridlines }),
    ...(validated.printHeadings === undefined ? {} : { printHeadings: validated.printHeadings }),
    ...(validated.oddHeader === undefined ? {} : { oddHeader: validated.oddHeader }),
    ...(validated.oddFooter === undefined ? {} : { oddFooter: validated.oddFooter }),
    ...(validated.differentOddEven === undefined
      ? {}
      : { differentOddEven: validated.differentOddEven }),
    ...(validated.differentFirst === undefined ? {} : { differentFirst: validated.differentFirst }),
    ...(validated.headerFooterFixedSize === undefined
      ? {}
      : { headerFooterFixedSize: validated.headerFooterFixedSize }),
    ...(validated.evenHeader === undefined ? {} : { evenHeader: validated.evenHeader }),
    ...(validated.evenFooter === undefined ? {} : { evenFooter: validated.evenFooter }),
    ...(validated.firstHeader === undefined ? {} : { firstHeader: validated.firstHeader }),
    ...(validated.firstFooter === undefined ? {} : { firstFooter: validated.firstFooter }),
    ...(validated.headerFooterPictures === undefined
      ? {}
      : {
          headerFooterPictures: validated.headerFooterPictures.map((picture) => ({
            id: picture.id,
            position: picture.position,
            widthPt: picture.widthPt,
            heightPt: picture.heightPt,
            mediaType: picture.mediaType,
          })),
        }),
  }
}

/// pageSetup.headerFooterPictures: up to 18 `&G` slots with a media key,
/// VML slot name, declared size in points and a media type.
function isHeaderFooterPictureList(input: unknown): boolean {
  return (
    Array.isArray(input) &&
    input.length <= 18 &&
    input.every(
      (picture) =>
        isRecord(picture) &&
        isBoundedString(picture.id, 64) &&
        typeof picture.position === 'string' &&
        HEADER_FOOTER_PICTURE_POSITION.test(picture.position) &&
        typeof picture.widthPt === 'number' &&
        picture.widthPt > 0 &&
        picture.widthPt <= 2_000 &&
        typeof picture.heightPt === 'number' &&
        picture.heightPt > 0 &&
        picture.heightPt <= 2_000 &&
        typeof picture.mediaType === 'string' &&
        /^image\//.test(picture.mediaType),
    )
  )
}

function parseRichRuns(input: unknown): WorkbookRichRun[] {
  if (!Array.isArray(input)) throw new Error('Invalid workbook rich text response.')
  return input.map((run) => {
    if (
      !isRecord(run) ||
      typeof run.text !== 'string' ||
      typeof run.bold !== 'boolean' ||
      typeof run.italic !== 'boolean' ||
      typeof run.underline !== 'boolean' ||
      typeof run.strikethrough !== 'boolean' ||
      !isOptionalString(run.color) ||
      (run.size !== undefined &&
        (typeof run.size !== 'number' || !Number.isFinite(run.size) || run.size <= 0)) ||
      !isOptionalString(run.family) ||
      (run.vertAlign !== undefined &&
        run.vertAlign !== 'subscript' &&
        run.vertAlign !== 'superscript')
    ) {
      throw new Error('Invalid workbook rich text response.')
    }
    return {
      text: run.text,
      bold: run.bold,
      italic: run.italic,
      underline: run.underline,
      strikethrough: run.strikethrough,
      ...(run.color === undefined ? {} : { color: run.color }),
      ...(run.size === undefined ? {} : { size: run.size }),
      ...(run.family === undefined ? {} : { family: run.family }),
      ...(run.vertAlign === undefined ? {} : { vertAlign: run.vertAlign }),
    }
  })
}

function parseCellArea(input: unknown): WorkbookConditionalRule['ranges'][number] {
  if (
    !isRecord(input) ||
    !isNonnegativeInteger(input.startRow) ||
    !isNonnegativeInteger(input.startColumn) ||
    !isNonnegativeInteger(input.endRow) ||
    !isNonnegativeInteger(input.endColumn) ||
    input.startRow > input.endRow ||
    input.startColumn > input.endColumn
  ) {
    throw new Error('Invalid workbook cell area.')
  }
  return {
    startRow: input.startRow,
    startColumn: input.startColumn,
    endRow: input.endRow,
    endColumn: input.endColumn,
  }
}

const CUSTOM_FILTER_OPERATORS = new Set([
  'equal',
  'notEqual',
  'greaterThan',
  'greaterThanOrEqual',
  'lessThan',
  'lessThanOrEqual',
])

function parseAutoFilterColumn(input: unknown): WorkbookRangeResult['autoFilterColumns'][number] {
  if (
    !isRecord(input) ||
    !isNonnegativeInteger(input.colId) ||
    input.colId > 16_383 ||
    (input.values !== undefined &&
      (!Array.isArray(input.values) ||
        input.values.length > 10_000 ||
        input.values.some((value) => typeof value !== 'string' || value.length > 32_767))) ||
    (input.blank !== undefined && typeof input.blank !== 'boolean')
  ) {
    throw new Error('Invalid workbook filter column.')
  }
  type ParsedCustoms = NonNullable<WorkbookRangeResult['autoFilterColumns'][number]['customs']>
  let customs: ParsedCustoms | undefined
  if (input.customs !== undefined) {
    const raw = input.customs
    if (
      !isRecord(raw) ||
      (raw.and !== undefined && typeof raw.and !== 'boolean') ||
      !Array.isArray(raw.filters) ||
      raw.filters.length < 1 ||
      raw.filters.length > 2
    ) {
      throw new Error('Invalid workbook filter column.')
    }
    const filters: ParsedCustoms['filters'] = []
    for (const custom of raw.filters) {
      if (!isRecord(custom) || typeof custom.val !== 'string' || custom.val.length > 32_767) {
        throw new Error('Invalid workbook filter column.')
      }
      if (custom.operator !== undefined && typeof custom.operator !== 'string') {
        throw new Error('Invalid workbook filter column.')
      }
      // A comparison token outside the OOXML enum (foreign writer) cannot be
      // represented or re-saved; drop the whole comparison block.
      if (custom.operator !== undefined && !CUSTOM_FILTER_OPERATORS.has(custom.operator)) {
        filters.length = 0
        break
      }
      filters.push({
        val: custom.val,
        ...(custom.operator === undefined
          ? {}
          : { operator: custom.operator as ParsedCustoms['filters'][number]['operator'] }),
      })
    }
    if (filters.length > 0) {
      customs = { ...(raw.and === true ? { and: true } : {}), filters }
    }
  }
  return {
    colId: input.colId,
    ...(input.values === undefined ? {} : { values: input.values as string[] }),
    ...(input.blank === true ? { blank: true } : {}),
    ...(customs === undefined ? {} : { customs }),
  }
}

function parseConditionalRule(input: unknown): WorkbookConditionalRule {
  if (
    !isRecord(input) ||
    !Array.isArray(input.ranges) ||
    typeof input.ruleType !== 'string' ||
    !isOptionalString(input.operator) ||
    !Array.isArray(input.formulas) ||
    input.formulas.some((formula) => typeof formula !== 'string') ||
    !isOptionalString(input.text) ||
    (input.dxfIndex !== undefined && !isNonnegativeInteger(input.dxfIndex)) ||
    typeof input.priority !== 'number' ||
    !Number.isInteger(input.priority) ||
    (input.stopIfTrue !== undefined && typeof input.stopIfTrue !== 'boolean') ||
    (input.rank !== undefined && !isNonnegativeInteger(input.rank)) ||
    typeof input.percent !== 'boolean' ||
    typeof input.bottom !== 'boolean' ||
    !Array.isArray(input.cfvos) ||
    !Array.isArray(input.colors) ||
    input.colors.some((color) => typeof color !== 'string')
  ) {
    throw new Error('Invalid workbook conditional rule.')
  }
  const cfvos = input.cfvos.map((cfvo) => {
    if (
      !isRecord(cfvo) ||
      typeof cfvo.kind !== 'string' ||
      !isOptionalString(cfvo.value) ||
      (cfvo.gte !== undefined && typeof cfvo.gte !== 'boolean')
    ) {
      throw new Error('Invalid workbook conditional rule value.')
    }
    return {
      kind: cfvo.kind,
      ...(cfvo.value === undefined ? {} : { value: cfvo.value }),
      ...(cfvo.gte === undefined ? {} : { gte: cfvo.gte }),
    }
  })
  if (
    !isOptionalString(input.iconSetName) ||
    typeof input.iconReverse !== 'boolean' ||
    typeof input.showValue !== 'boolean' ||
    !isOptionalString(input.negativeColor) ||
    (input.negativeSameAsPositive !== undefined &&
      typeof input.negativeSameAsPositive !== 'boolean') ||
    (input.gradient !== undefined && typeof input.gradient !== 'boolean') ||
    (input.axisPosition !== undefined &&
      input.axisPosition !== 'automatic' &&
      input.axisPosition !== 'middle' &&
      input.axisPosition !== 'none') ||
    !isOptionalString(input.axisColor) ||
    !isOptionalBarLength(input.minLength) ||
    !isOptionalBarLength(input.maxLength)
  ) {
    throw new Error('Invalid workbook conditional rule.')
  }
  return {
    ranges: input.ranges.map(parseCellArea),
    ruleType: input.ruleType,
    formulas: input.formulas as string[],
    priority: input.priority,
    percent: input.percent,
    bottom: input.bottom,
    cfvos,
    colors: input.colors as string[],
    iconReverse: input.iconReverse,
    showValue: input.showValue,
    ...(input.iconSetName === undefined ? {} : { iconSetName: input.iconSetName }),
    ...(input.operator === undefined ? {} : { operator: input.operator }),
    ...(input.text === undefined ? {} : { text: input.text }),
    ...(input.dxfIndex === undefined ? {} : { dxfIndex: input.dxfIndex }),
    ...(input.stopIfTrue === undefined ? {} : { stopIfTrue: input.stopIfTrue }),
    ...(input.rank === undefined ? {} : { rank: input.rank }),
    ...(input.negativeColor === undefined ? {} : { negativeColor: input.negativeColor }),
    ...(input.negativeSameAsPositive === undefined
      ? {}
      : { negativeSameAsPositive: input.negativeSameAsPositive }),
    ...(input.gradient === undefined ? {} : { gradient: input.gradient }),
    ...(input.axisPosition === undefined ? {} : { axisPosition: input.axisPosition }),
    ...(input.axisColor === undefined ? {} : { axisColor: input.axisColor }),
    ...(input.minLength === undefined ? {} : { minLength: input.minLength }),
    ...(input.maxLength === undefined ? {} : { maxLength: input.maxLength }),
  }
}

/// dataBar minLength/maxLength: an integer percentage of the cell width.
function isOptionalBarLength(value: unknown): value is number | undefined {
  return value === undefined || (isNonnegativeInteger(value) && value <= 100)
}

const TABLE_OPTION_KEYS = [
  'headerRow',
  'totalsRow',
  'firstColumn',
  'lastColumn',
  'bandedColumns',
  'filterButton',
] as const

function parseSaveRequest(input: WorkbookSaveRequest): WorkbookSaveRequest {
  // Every rejection names the failing part: this one message ends up in the
  // save-failure toast, and "Invalid workbook save request." alone gave user
  // reports nothing to go on.
  const invalid = (detail: string): never => {
    throw new Error(`Invalid workbook save request. (${detail})`)
  }
  // Arrays of renderer-built parts share one shape rule: a real array, at
  // most `cap` entries.
  const cappedArray = (name: string, value: unknown, cap: number): void => {
    if (!Array.isArray(value)) invalid(`${name}: not a list`)
    if ((value as unknown[]).length > cap)
      invalid(`${name}: ${(value as unknown[]).length} entries exceeds the ${cap} limit`)
  }
  if (!isRecord(input)) invalid('malformed request')
  if (!isUuid(input.sessionId)) invalid('session id')
  if (input.mode !== 'save' && input.mode !== 'save-as') invalid('mode')
  if (input.restoreWriteBack !== undefined && typeof input.restoreWriteBack !== 'boolean')
    invalid('restore flag')
  if (
    input.targetPath !== undefined &&
    (typeof input.targetPath !== 'string' ||
      input.targetPath.length === 0 ||
      input.targetPath.length > 1024)
  )
    invalid('target path')
  if (input.overwrite !== undefined && typeof input.overwrite !== 'boolean')
    invalid('overwrite flag')
  if (
    input.csvContent !== undefined &&
    (typeof input.csvContent !== 'string' || input.csvContent.length > MAX_CSV_EXPORT_CHARS)
  )
    invalid('csv content')
  if (input.editsTransferId !== undefined && !isUuid(input.editsTransferId))
    invalid('edits transfer id')
  cappedArray('cell edits', input.edits, MAX_SAVE_EDITS)
  if (input.editsTransferId !== undefined && input.edits.length > 0)
    invalid('cell edits: inline edits mixed with a transfer')
  cappedArray('bulk constant fills', input.bulkConstantFills ?? [], 1_000)
  cappedArray('structural operations', input.structuralOps, 1_000)
  cappedArray('chart edits', input.chartEdits, 100)
  cappedArray('visual edits', input.visualEdits, 100)
  cappedArray('visual additions', input.visualAdditions, 100)
  cappedArray('table additions', input.tableAdditions, 50)
  cappedArray('table edits', input.tableEdits ?? [], 100)
  cappedArray('pivot additions', input.pivotAdditions, 20)
  cappedArray('sheet operations', input.sheetOps, 100)
  cappedArray('sheet order', input.sheetOrder, 1_000)
  if (input.sheetOrder.some((sheetId) => typeof sheetId !== 'string' || sheetId.length === 0))
    invalid('sheet order: empty sheet id')
  cappedArray('filter states', input.filterStates, 1_000)
  cappedArray('hyperlink edits', input.hyperlinkEdits, 1_000)
  cappedArray('conditional-formatting states', input.cfStates, 1_000)
  cappedArray('data-validation states', input.dvStates, 1_000)
  cappedArray('page-setup states', input.pageSetupStates, 1_000)
  cappedArray('note states', input.noteStates, 1_000)
  cappedArray('pivot cache refreshes', input.pivotCacheRefreshPaths, 100)
  if (input.pivotCacheRefreshPaths.some((path) => typeof path !== 'string'))
    invalid('pivot cache refreshes: non-string path')
  cappedArray('pivot refresh updates', input.pivotRefreshUpdates, 100)
  if (
    input.pivotRefreshUpdates.some(
      (update) =>
        !isRecord(update) ||
        typeof update.cachePath !== 'string' ||
        typeof update.sheetId !== 'string' ||
        update.sheetId.length === 0 ||
        typeof update.newOutputRef !== 'string' ||
        update.newOutputRef.length > 64 ||
        // relayout's full shape is authoritatively validated by main's zod schema.
        (update.relayout !== undefined && !isRecord(update.relayout)),
    )
  )
    invalid('pivot refresh updates: malformed entry')
  cappedArray('sheet protections', input.sheetProtections, 1_000)
  if (
    input.sheetProtections.some(
      (state) =>
        !isRecord(state) ||
        typeof state.sheetId !== 'string' ||
        state.sheetId.length === 0 ||
        typeof state.protected !== 'boolean',
    )
  )
    invalid('sheet protections: malformed entry')
  if (!isDefinedNamesState(input.definedNamesState)) invalid('defined names')
  if (!isThemeState(input.themeState)) invalid('theme')
  if (
    input.workbookProtectionState !== null &&
    (!isRecord(input.workbookProtectionState) ||
      typeof input.workbookProtectionState.lockStructure !== 'boolean')
  )
    invalid('workbook protection')
  cappedArray('protected-range states', input.protectedRangeStates, 1_000)
  if (
    input.protectedRangeStates.some(
      (state) =>
        !isRecord(state) ||
        typeof state.sheetId !== 'string' ||
        state.sheetId.length === 0 ||
        !Array.isArray(state.ranges) ||
        state.ranges.length > 1_000 ||
        state.ranges.some(
          (range: unknown) =>
            !isRecord(range) ||
            typeof range.name !== 'string' ||
            range.name.length === 0 ||
            range.name.length > 255 ||
            typeof range.sqref !== 'string' ||
            range.sqref.length === 0 ||
            range.sqref.length > 1_024,
        ),
    )
  )
    invalid('protected-range states: malformed entry')
  if (input.redactionStates !== null) cappedArray('redaction states', input.redactionStates, 1_000)
  if (
    (input.redactionStates ?? []).some(
      (state) =>
        !isRecord(state) ||
        typeof state.sheetName !== 'string' ||
        state.sheetName.length === 0 ||
        !Array.isArray(state.marks) ||
        state.marks.length > 100_000 ||
        state.marks.some(
          (mark: unknown) =>
            !isRecord(mark) ||
            typeof mark.startRow !== 'number' ||
            typeof mark.endRow !== 'number' ||
            typeof mark.startColumn !== 'number' ||
            typeof mark.endColumn !== 'number' ||
            typeof mark.label !== 'string' ||
            mark.label.length === 0,
        ),
    )
  )
    invalid('redaction states: malformed entry')
  if (
    input.mode !== 'save-as' &&
    input.restoreWriteBack !== true &&
    input.editsTransferId === undefined &&
    input.edits.length === 0 &&
    (input.bulkConstantFills?.length ?? 0) === 0 &&
    input.structuralOps.length === 0 &&
    input.chartEdits.length === 0 &&
    input.visualEdits.length === 0 &&
    input.visualAdditions.length === 0 &&
    input.tableAdditions.length === 0 &&
    (input.tableEdits?.length ?? 0) === 0 &&
    input.pivotAdditions.length === 0 &&
    (input.sparklineAdditions?.length ?? 0) === 0 &&
    input.sheetOps.length === 0 &&
    input.filterStates.length === 0 &&
    input.hyperlinkEdits.length === 0 &&
    input.cfStates.length === 0 &&
    input.dvStates.length === 0 &&
    input.pageSetupStates.length === 0 &&
    input.noteStates.length === 0 &&
    input.pivotCacheRefreshPaths.length === 0 &&
    input.pivotRefreshUpdates.length === 0 &&
    input.sheetProtections.length === 0 &&
    input.definedNamesState === null &&
    input.themeState === null &&
    input.workbookProtectionState === null &&
    input.protectedRangeStates.length === 0 &&
    (input.redactionStates?.length ?? 0) === 0
  )
    invalid('no changes to save')
  if (input.sheetOps.length > 0 && input.sheetOrder.length === 0)
    invalid('sheet order missing for sheet operations')
  for (const state of input.dvStates) {
    if (
      !isRecord(state) ||
      typeof state.sheetId !== 'string' ||
      state.sheetId.length === 0 ||
      !Array.isArray(state.rules) ||
      state.rules.length > 500
    ) {
      throw new Error('Invalid workbook data-validation state.')
    }
    for (const rule of state.rules) {
      if (
        !isRecord(rule) ||
        !isRecord(rule.rule) ||
        !Array.isArray(rule.ranges) ||
        rule.ranges.length === 0 ||
        rule.ranges.length > 100
      ) {
        throw new Error('Invalid workbook data-validation rule.')
      }
      for (const range of rule.ranges) parseCellArea(range)
    }
  }
  for (const state of input.pageSetupStates) {
    if (!isPageSetupState(state)) throw new Error('Invalid workbook page-setup state.')
  }
  for (const table of input.tableAdditions) {
    if (
      !isRecord(table) ||
      typeof table.sheetId !== 'string' ||
      table.sheetId.length === 0 ||
      typeof table.name !== 'string' ||
      table.name.length === 0 ||
      table.name.length > 255 ||
      !Array.isArray(table.columnNames) ||
      table.columnNames.length === 0 ||
      table.columnNames.length > 1_000 ||
      table.columnNames.some((name) => typeof name !== 'string' || name.length > 255) ||
      (table.style !== undefined &&
        (typeof table.style !== 'string' ||
          !/^TableStyle(?:Light|Medium|Dark)[1-9][0-9]?$/.test(table.style))) ||
      typeof table.bandedRows !== 'boolean' ||
      TABLE_OPTION_KEYS.some((key) => table[key] !== undefined && typeof table[key] !== 'boolean')
    ) {
      throw new Error('Invalid workbook table addition.')
    }
    parseCellArea(table.area)
  }
  for (const edit of input.tableEdits ?? []) {
    if (
      !isRecord(edit) ||
      typeof edit.sheetId !== 'string' ||
      edit.sheetId.length === 0 ||
      typeof edit.tableName !== 'string' ||
      edit.tableName.length === 0 ||
      edit.tableName.length > 255 ||
      (edit.name !== undefined &&
        (typeof edit.name !== 'string' || edit.name.length === 0 || edit.name.length > 255)) ||
      (edit.columnNames !== undefined &&
        (!Array.isArray(edit.columnNames) ||
          edit.columnNames.length === 0 ||
          edit.columnNames.length > 1_000 ||
          edit.columnNames.some((name) => typeof name !== 'string' || name.length > 255))) ||
      (edit.style !== undefined &&
        (typeof edit.style !== 'string' ||
          !/^TableStyle(?:Light|Medium|Dark)[1-9][0-9]?$/.test(edit.style))) ||
      (edit.remove !== undefined && edit.remove !== true) ||
      [...TABLE_OPTION_KEYS, 'bandedRows'].some((key) => {
        const value = (edit as Record<string, unknown>)[key]
        return value !== undefined && typeof value !== 'boolean'
      })
    ) {
      throw new Error('Invalid workbook table edit.')
    }
    if (edit.area !== undefined) parseCellArea(edit.area)
  }
  for (const pivot of input.pivotAdditions) {
    if (
      !isRecord(pivot) ||
      typeof pivot.sheetId !== 'string' ||
      pivot.sheetId.length === 0 ||
      typeof pivot.sourceSheetId !== 'string' ||
      pivot.sourceSheetId.length === 0 ||
      typeof pivot.name !== 'string' ||
      pivot.name.length === 0 ||
      pivot.name.length > 255 ||
      !Array.isArray(pivot.fieldNames) ||
      pivot.fieldNames.length === 0 ||
      pivot.fieldNames.length > 200 ||
      pivot.fieldNames.some(
        (name) => typeof name !== 'string' || name.length === 0 || name.length > 255,
      ) ||
      !Array.isArray(pivot.rowFieldIndices) ||
      pivot.rowFieldIndices.length === 0 ||
      pivot.rowFieldIndices.length > 8 ||
      pivot.rowFieldIndices.some((i) => !isNonnegativeInteger(i)) ||
      (pivot.rowLevelItems !== undefined &&
        (!Array.isArray(pivot.rowLevelItems) ||
          pivot.rowLevelItems.length > 8 ||
          pivot.rowLevelItems.some(
            (level) =>
              !Array.isArray(level) ||
              level.length > 10_000 ||
              level.some((item) => typeof item !== 'string' || item.length > 255),
          ))) ||
      (pivot.rowLines !== undefined &&
        (!Array.isArray(pivot.rowLines) ||
          pivot.rowLines.length > 20_000 ||
          pivot.rowLines.some(
            (line) =>
              !isRecord(line) ||
              !['data', 'default'].includes(String(line.t)) ||
              !Array.isArray(line.members) ||
              line.members.length === 0 ||
              line.members.length > 8 ||
              line.members.some((member) => !isNonnegativeInteger(member)),
          ))) ||
      (pivot.columnFieldIndex !== undefined && !isNonnegativeInteger(pivot.columnFieldIndex)) ||
      (pivot.pageFieldIndices !== undefined &&
        (!Array.isArray(pivot.pageFieldIndices) ||
          pivot.pageFieldIndices.length > 4 ||
          pivot.pageFieldIndices.some((i) => !isNonnegativeInteger(i)))) ||
      !Array.isArray(pivot.rowItems) ||
      pivot.rowItems.length === 0 ||
      pivot.rowItems.length > 10_000 ||
      pivot.rowItems.some((item) => typeof item !== 'string' || item.length > 255) ||
      (pivot.columnItems !== undefined &&
        (!Array.isArray(pivot.columnItems) ||
          pivot.columnItems.length > 1_000 ||
          pivot.columnItems.some((item) => typeof item !== 'string' || item.length > 255))) ||
      !Array.isArray(pivot.values) ||
      pivot.values.length === 0 ||
      pivot.values.length > 8 ||
      pivot.values.some(
        (value) =>
          !isRecord(value) ||
          !isNonnegativeInteger(value.fieldIndex) ||
          !['sum', 'count', 'average', 'max', 'min'].includes(String(value.agg)) ||
          (value.showDataAs !== undefined &&
            !['percentOfTotal', 'percentOfRow', 'percentOfCol'].includes(String(value.showDataAs))),
      )
    ) {
      throw new Error('Invalid workbook pivot addition.')
    }
    parseCellArea(pivot.sourceArea)
    parseCellArea(pivot.location)
  }
  for (const state of input.cfStates) {
    if (
      !isRecord(state) ||
      typeof state.sheetId !== 'string' ||
      state.sheetId.length === 0 ||
      !Array.isArray(state.rules) ||
      state.rules.length > 500
    ) {
      throw new Error('Invalid workbook conditional-formatting state.')
    }
    for (const rule of state.rules) {
      if (
        !isRecord(rule) ||
        typeof rule.stopIfTrue !== 'boolean' ||
        !isRecord(rule.rule) ||
        !Array.isArray(rule.ranges) ||
        rule.ranges.length === 0 ||
        rule.ranges.length > 100
      ) {
        throw new Error('Invalid workbook conditional-formatting rule.')
      }
      for (const range of rule.ranges) parseCellArea(range)
    }
  }
  for (const link of input.hyperlinkEdits) {
    if (
      !isRecord(link) ||
      typeof link.sheetId !== 'string' ||
      link.sheetId.length === 0 ||
      !isNonnegativeInteger(link.row) ||
      !isNonnegativeInteger(link.column) ||
      (link.target !== null &&
        (typeof link.target !== 'string' || link.target.length === 0 || link.target.length > 2083))
    ) {
      throw new Error('Invalid workbook hyperlink edit.')
    }
  }
  for (const state of input.filterStates) {
    if (
      !isRecord(state) ||
      typeof state.sheetId !== 'string' ||
      state.sheetId.length === 0 ||
      !Array.isArray(state.hiddenRows) ||
      state.hiddenRows.length > 100_000 ||
      state.hiddenRows.some((row) => !isNonnegativeInteger(row))
    ) {
      throw new Error('Invalid workbook filter state.')
    }
    parseCellArea(state.visibilityRange)
    if (state.filter === null) continue
    if (
      !isRecord(state.filter) ||
      !Array.isArray(state.filter.columns) ||
      state.filter.columns.length > 1_000
    ) {
      throw new Error('Invalid workbook filter state.')
    }
    parseCellArea(state.filter.range)
    for (const column of state.filter.columns) {
      if (!isFilterColumn(column)) throw new Error('Invalid workbook filter column.')
    }
  }
  for (const op of input.sheetOps) {
    if (!isRecord(op)) throw new Error('Invalid workbook sheet operation.')
    if (op.kind === 'reorder-sheets') continue
    if (typeof op.sheetId !== 'string' || op.sheetId.length === 0) {
      throw new Error('Invalid workbook sheet operation.')
    }
    if (op.kind === 'rename-sheet') {
      if (!isSheetName(op.newName)) throw new Error('Invalid workbook sheet operation.')
    } else if (op.kind === 'add-sheet') {
      if (!isSheetName(op.name)) throw new Error('Invalid workbook sheet operation.')
    } else if (op.kind === 'duplicate-sheet') {
      if (
        !isSheetName(op.name) ||
        typeof op.sourceSheetId !== 'string' ||
        op.sourceSheetId.length === 0
      ) {
        throw new Error('Invalid workbook sheet operation.')
      }
    } else if (op.kind === 'set-sheet-hidden') {
      if (typeof op.hidden !== 'boolean') throw new Error('Invalid workbook sheet operation.')
    } else if (op.kind === 'set-sheet-tab-color') {
      if (op.color !== null && !(typeof op.color === 'string' && /^#[0-9A-F]{6}$/.test(op.color))) {
        throw new Error('Invalid workbook sheet operation.')
      }
    } else if (op.kind !== 'remove-sheet') {
      throw new Error('Invalid workbook sheet operation.')
    }
  }
  for (const chartEdit of input.chartEdits) {
    if (
      !isRecord(chartEdit) ||
      typeof chartEdit.chartPath !== 'string' ||
      !/^xl\/charts\/[A-Za-z0-9._-]+\.xml$/.test(chartEdit.chartPath) ||
      (chartEdit.title !== undefined &&
        (typeof chartEdit.title !== 'string' || chartEdit.title.length > 255)) ||
      (chartEdit.chartType !== undefined &&
        !['column', 'bar', 'line', 'area'].includes(String(chartEdit.chartType))) ||
      (chartEdit.seriesColors !== undefined && !isSeriesColors(chartEdit.seriesColors))
    ) {
      throw new Error('Invalid workbook chart edit.')
    }
  }
  for (const visualEdit of input.visualEdits) {
    if (
      !isRecord(visualEdit) ||
      typeof visualEdit.drawingPath !== 'string' ||
      !/^xl\/drawings\/[A-Za-z0-9._/-]+\.xml$/.test(visualEdit.drawingPath) ||
      !isNonnegativeInteger(visualEdit.drawingIndex) ||
      visualEdit.drawingIndex > 10_000 ||
      (visualEdit.remove !== undefined && visualEdit.remove !== true) ||
      !isShapePaint(visualEdit.fillColor) ||
      !isShapePaint(visualEdit.lineColor) ||
      (visualEdit.zIndex !== undefined &&
        (!isNonnegativeInteger(visualEdit.zIndex) || visualEdit.zIndex > 10_000)) ||
      (visualEdit.rotation !== undefined &&
        (typeof visualEdit.rotation !== 'number' || !Number.isFinite(visualEdit.rotation))) ||
      (visualEdit.flipH !== undefined && typeof visualEdit.flipH !== 'boolean') ||
      (visualEdit.flipV !== undefined && typeof visualEdit.flipV !== 'boolean') ||
      !isOptionalString(visualEdit.altText) ||
      !isOptionalString(visualEdit.hyperlink) ||
      (visualEdit.editAs !== undefined &&
        !['twoCell', 'oneCell', 'absolute'].includes(String(visualEdit.editAs))) ||
      (visualEdit.remove === undefined &&
        !isRecord(visualEdit.anchor) &&
        [
          visualEdit.fillColor,
          visualEdit.lineColor,
          visualEdit.zIndex,
          visualEdit.rotation,
          visualEdit.flipH,
          visualEdit.flipV,
          visualEdit.altText,
          visualEdit.hyperlink,
          visualEdit.editAs,
        ].every((value) => value === undefined))
    ) {
      throw new Error('Invalid workbook visual edit.')
    }
    if (visualEdit.anchor !== undefined) {
      if (!isRecord(visualEdit.anchor)) throw new Error('Invalid workbook visual edit.')
      parseDrawingAnchor(visualEdit.anchor)
    }
  }
  for (const op of input.structuralOps) {
    if (!isRecord(op) || typeof op.sheetId !== 'string' || op.sheetId.length === 0) {
      throw new Error('Invalid workbook structural operation.')
    }
    if ('range' in op) {
      if (op.kind !== 'merge-cells' && op.kind !== 'unmerge-cells') {
        throw new Error('Invalid workbook structural operation.')
      }
      parseCellArea(op.range)
      continue
    }
    if ('style' in op) {
      const { start, end } = op
      if (
        op.kind !== 'set-col-style' ||
        !isNonnegativeInteger(start) ||
        !isNonnegativeInteger(end) ||
        end < start ||
        end - start >= 100_000 ||
        !isRecord(op.style) ||
        Object.keys(op.style).length === 0
      ) {
        throw new Error('Invalid workbook structural operation.')
      }
      continue
    }
    if ('summaryBelow' in op) {
      if (
        op.kind !== 'set-outline-pr' ||
        typeof op.summaryBelow !== 'boolean' ||
        typeof op.summaryRight !== 'boolean'
      ) {
        throw new Error('Invalid workbook structural operation.')
      }
      continue
    }
    if ('size' in op || 'hidden' in op || 'level' in op) {
      const { start, end } = op
      if (
        !isNonnegativeInteger(start) ||
        !isNonnegativeInteger(end) ||
        end < start ||
        end - start >= 100_000
      ) {
        throw new Error('Invalid workbook structural operation.')
      }
      if ('size' in op) {
        if (
          (op.kind !== 'set-row-size' && op.kind !== 'set-col-size') ||
          (op.size !== null &&
            (typeof op.size !== 'number' ||
              !Number.isFinite(op.size) ||
              op.size <= 0 ||
              op.size > 500))
        ) {
          throw new Error('Invalid workbook structural operation.')
        }
      } else if ('level' in op) {
        if (
          (op.kind !== 'set-rows-outline' && op.kind !== 'set-cols-outline') ||
          !isNonnegativeInteger(op.level) ||
          op.level > 7 ||
          (op.collapsed !== undefined && typeof op.collapsed !== 'boolean')
        ) {
          throw new Error('Invalid workbook structural operation.')
        }
      } else if (
        (op.kind !== 'set-rows-hidden' && op.kind !== 'set-cols-hidden') ||
        typeof op.hidden !== 'boolean'
      ) {
        throw new Error('Invalid workbook structural operation.')
      }
      continue
    }
    const { index, count } = op
    if ('before' in op) {
      if (
        op.kind !== 'move-rows' ||
        !isNonnegativeInteger(index) ||
        !isNonnegativeInteger(count) ||
        count === 0 ||
        count > 10_000 ||
        !isNonnegativeInteger(op.before) ||
        (op.before >= index && op.before <= index + count)
      ) {
        throw new Error('Invalid workbook structural operation.')
      }
      continue
    }
    if (
      !['insert-rows', 'remove-rows', 'insert-cols', 'remove-cols'].includes(String(op.kind)) ||
      !isNonnegativeInteger(index) ||
      !isNonnegativeInteger(count) ||
      count === 0 ||
      count > 10_000
    ) {
      throw new Error('Invalid workbook structural operation.')
    }
  }
  for (const edit of input.edits) {
    if (
      !isRecord(edit) ||
      typeof edit.sheetId !== 'string' ||
      edit.sheetId.length === 0 ||
      !isNonnegativeInteger(edit.row) ||
      !isNonnegativeInteger(edit.column) ||
      typeof edit.writeValue !== 'boolean' ||
      !isCellScalar(edit.value) ||
      (edit.formula !== undefined &&
        (typeof edit.formula !== 'string' ||
          edit.formula.length === 0 ||
          edit.formula.length > 8_192)) ||
      (edit.style !== undefined && !isStyleEdit(edit.style)) ||
      (edit.styleReset !== undefined && typeof edit.styleReset !== 'boolean') ||
      (!edit.writeValue && edit.style === undefined && edit.styleReset !== true)
    ) {
      throw new Error('Invalid workbook cell edit.')
    }
    if (edit.rich !== undefined) parseRichRuns(edit.rich)
  }
  for (const fill of input.bulkConstantFills ?? []) {
    if (
      !isRecord(fill) ||
      typeof fill.sheetId !== 'string' ||
      fill.sheetId.length === 0 ||
      !isNonnegativeInteger(fill.startRow) ||
      !isNonnegativeInteger(fill.endRow) ||
      fill.endRow < fill.startRow ||
      !isNonnegativeInteger(fill.startColumn) ||
      !isNonnegativeInteger(fill.endColumn) ||
      fill.endColumn < fill.startColumn ||
      !isCellScalar(fill.value)
    ) {
      invalid('bulk constant fills: malformed entry')
    }
  }
  return input
}

const FILTER_OPERATORS = [
  'equal',
  'notEqual',
  'greaterThan',
  'greaterThanOrEqual',
  'lessThan',
  'lessThanOrEqual',
]

function isFilterColumn(input: unknown): boolean {
  if (!isRecord(input) || !isNonnegativeInteger(input.colId)) return false
  if (
    input.values !== undefined &&
    (!Array.isArray(input.values) ||
      input.values.length > 10_000 ||
      // filter values are cell texts — cell cap, not a short-name cap
      input.values.some((value) => typeof value !== 'string' || value.length > 32_767))
  ) {
    return false
  }
  if (input.blank !== undefined && typeof input.blank !== 'boolean') return false
  if (input.customs !== undefined) {
    if (!isRecord(input.customs)) return false
    if (input.customs.and !== undefined && typeof input.customs.and !== 'boolean') return false
    const filters = input.customs.filters
    if (!Array.isArray(filters) || filters.length === 0 || filters.length > 2) return false
    for (const custom of filters) {
      if (
        !isRecord(custom) ||
        (typeof custom.val !== 'string' && typeof custom.val !== 'number') ||
        (custom.operator !== undefined && !FILTER_OPERATORS.includes(String(custom.operator)))
      ) {
        return false
      }
    }
  }
  return input.values !== undefined || input.blank !== undefined || input.customs !== undefined
}

/** Shape check shared by PDF export and print: both send the laid-out sheet with its page setup. */
function isPdfExportRequest(request: unknown): boolean {
  return !(
    !isRecord(request) ||
    typeof request.fileName !== 'string' ||
    request.fileName.length === 0 ||
    request.fileName.length > 255 ||
    typeof request.html !== 'string' ||
    request.html.length === 0 ||
    request.html.length > 20_000_000 ||
    typeof request.landscape !== 'boolean' ||
    !isPdfPageSize(request.pageSize) ||
    !isRecord(request.margins) ||
    !['top', 'bottom', 'left', 'right'].every((edge) => {
      const value = (request.margins as Record<string, unknown>)[edge]
      return typeof value === 'number' && value >= 0 && value <= 3
    }) ||
    typeof request.scale !== 'number' ||
    request.scale < 0.1 ||
    request.scale > 2 ||
    (request.headerTemplate !== undefined &&
      !isBoundedString(request.headerTemplate, MAX_PDF_TEMPLATE_CHARS)) ||
    (request.footerTemplate !== undefined &&
      !isBoundedString(request.footerTemplate, MAX_PDF_TEMPLATE_CHARS)) ||
    (request.firstPage !== undefined && !isPdfPageVariant(request.firstPage)) ||
    (request.evenPages !== undefined && !isPdfPageVariant(request.evenPages)) ||
    (request.outPath !== undefined && !isBoundedString(request.outPath, 4096)) ||
    // '' = the system default printer
    (request.deviceName !== undefined &&
      (typeof request.deviceName !== 'string' || request.deviceName.length > 255)) ||
    (request.copies !== undefined &&
      (typeof request.copies !== 'number' ||
        !Number.isInteger(request.copies) ||
        request.copies < 1 ||
        request.copies > 999)) ||
    (request.collate !== undefined && typeof request.collate !== 'boolean')
  )
}

function isPdfPageSize(input: unknown): boolean {
  if (typeof input === 'string') {
    return ['A3', 'A4', 'A5', 'Legal', 'Letter', 'Tabloid'].includes(input)
  }
  return (
    isRecord(input) &&
    typeof input.width === 'number' &&
    input.width > 0 &&
    input.width <= 100 &&
    typeof input.height === 'number' &&
    input.height > 0 &&
    input.height <= 100
  )
}

/// firstPage / evenPages of a PDF export: optional header/footer templates.
function isPdfPageVariant(input: unknown): boolean {
  return (
    isRecord(input) &&
    Object.keys(input).every((key) => key === 'headerTemplate' || key === 'footerTemplate') &&
    (input.headerTemplate === undefined ||
      isBoundedString(input.headerTemplate, MAX_PDF_TEMPLATE_CHARS)) &&
    (input.footerTemplate === undefined ||
      isBoundedString(input.footerTemplate, MAX_PDF_TEMPLATE_CHARS))
  )
}

function isPageSetupState(input: unknown): boolean {
  if (!isRecord(input) || typeof input.sheetId !== 'string' || input.sheetId.length === 0) {
    return false
  }
  const isBoundedInt = (value: unknown, min: number, max: number) =>
    typeof value === 'number' && Number.isInteger(value) && value >= min && value <= max
  if (
    input.orientation !== undefined &&
    input.orientation !== 'portrait' &&
    input.orientation !== 'landscape'
  )
    return false
  if (input.paperSize !== undefined && !isBoundedInt(input.paperSize, 1, 118)) return false
  if (input.scale !== undefined && !isBoundedInt(input.scale, 10, 400)) return false
  if (input.fitToWidth !== undefined && !isBoundedInt(input.fitToWidth, 0, 1_000)) return false
  if (input.fitToHeight !== undefined && !isBoundedInt(input.fitToHeight, 0, 1_000)) return false
  if (input.margins !== undefined && !['normal', 'wide', 'narrow'].includes(String(input.margins)))
    return false
  for (const key of [
    'printGridlines',
    'printHeadings',
    'showGridlines',
    'showFormulas',
    'showHeadings',
    'rightToLeft',
    'fitToPage',
  ]) {
    if (input[key] !== undefined && typeof input[key] !== 'boolean') return false
  }
  if (
    input.printArea !== undefined &&
    input.printArea !== null &&
    (typeof input.printArea !== 'string' ||
      input.printArea.length === 0 ||
      input.printArea.length > 255)
  )
    return false
  if (
    input.printTitles !== undefined &&
    input.printTitles !== null &&
    (typeof input.printTitles !== 'string' || !/^\d{1,7}:\d{1,7}$/.test(input.printTitles))
  )
    return false
  for (const [key, max] of [
    ['rowBreaks', 1_048_575],
    ['colBreaks', 16_383],
  ] as const) {
    const breaks = input[key]
    if (
      breaks !== undefined &&
      (!Array.isArray(breaks) ||
        breaks.length > 1_023 ||
        breaks.some((id) => !isBoundedInt(id, 1, max)))
    )
      return false
  }
  return Object.keys(input).length > 1
}

function isSheetName(input: unknown): input is string {
  return (
    typeof input === 'string' &&
    input.length >= 1 &&
    input.length <= 31 &&
    !/[\\/?*[\]:]/.test(input) &&
    !input.startsWith("'") &&
    !input.endsWith("'")
  )
}

function isSeriesColors(input: unknown): boolean {
  if (!isRecord(input)) return false
  return Object.entries(input).every(
    ([key, value]) =>
      /^[0-9]{1,3}$/.test(key) && typeof value === 'string' && /^#[0-9A-Fa-f]{6}$/.test(value),
  )
}

const BORDER_STYLE_NAMES = [
  'thin',
  'medium',
  'thick',
  'dashed',
  'dotted',
  'double',
  'hair',
  'dashDot',
  'dashDotDot',
  'mediumDashed',
  'mediumDashDot',
  'mediumDashDotDot',
  'slantDashDot',
]

function isStyleEdit(input: unknown): boolean {
  if (!isRecord(input)) return false
  const isHexColor = (value: unknown): boolean =>
    typeof value === 'string' && /^#[0-9A-Fa-f]{6}$/.test(value)
  const isOptionalBoolean = (value: unknown): boolean =>
    value === undefined || typeof value === 'boolean'
  const isBorderEdge = (value: unknown): boolean =>
    value === undefined ||
    value === null ||
    (isRecord(value) &&
      BORDER_STYLE_NAMES.includes(String(value.style)) &&
      (value.color === undefined || isHexColor(value.color)) &&
      Object.keys(value).every((key) => ['style', 'color'].includes(key)))
  if (
    ![input.borderTop, input.borderBottom, input.borderLeft, input.borderRight].every(isBorderEdge)
  ) {
    return false
  }
  return (
    isOptionalBoolean(input.bold) &&
    isOptionalBoolean(input.italic) &&
    isOptionalBoolean(input.underline) &&
    isOptionalBoolean(input.strikethrough) &&
    isOptionalBoolean(input.wrapText) &&
    (input.fontFamily === undefined ||
      (typeof input.fontFamily === 'string' &&
        input.fontFamily.length > 0 &&
        input.fontFamily.length <= 128)) &&
    (input.fontSize === undefined ||
      (typeof input.fontSize === 'number' &&
        Number.isFinite(input.fontSize) &&
        input.fontSize > 0 &&
        input.fontSize <= 409)) &&
    (input.fontColor === undefined || input.fontColor === null || isHexColor(input.fontColor)) &&
    (input.fillColor === undefined || input.fillColor === null || isHexColor(input.fillColor)) &&
    (input.horizontalAlignment === undefined ||
      ['left', 'center', 'right', 'justify', 'distributed'].includes(
        String(input.horizontalAlignment),
      )) &&
    (input.verticalAlignment === undefined ||
      ['top', 'center', 'bottom'].includes(String(input.verticalAlignment))) &&
    (input.numberFormat === undefined ||
      (typeof input.numberFormat === 'string' &&
        input.numberFormat.length > 0 &&
        input.numberFormat.length <= 255)) &&
    (input.underlineStyle === undefined ||
      ['single', 'double'].includes(String(input.underlineStyle))) &&
    (input.vertAlign === undefined ||
      input.vertAlign === null ||
      ['superscript', 'subscript'].includes(String(input.vertAlign))) &&
    (input.textRotation === undefined ||
      (typeof input.textRotation === 'number' &&
        Number.isInteger(input.textRotation) &&
        ((input.textRotation >= 0 && input.textRotation <= 180) || input.textRotation === 255))) &&
    (input.indent === undefined ||
      (typeof input.indent === 'number' &&
        Number.isInteger(input.indent) &&
        input.indent >= 0 &&
        input.indent <= 250)) &&
    isOptionalBoolean(input.protectionLocked) &&
    isOptionalBoolean(input.protectionHidden) &&
    Object.keys(input).every((key) =>
      [
        'bold',
        'italic',
        'underline',
        'underlineStyle',
        'strikethrough',
        'vertAlign',
        'fontFamily',
        'fontSize',
        'fontColor',
        'fillColor',
        'horizontalAlignment',
        'verticalAlignment',
        'wrapText',
        'numberFormat',
        'textRotation',
        'indent',
        'protectionLocked',
        'protectionHidden',
        'borderTop',
        'borderBottom',
        'borderLeft',
        'borderRight',
      ].includes(key),
    )
  )
}

function isThemeState(input: unknown): boolean {
  if (input === null) return true
  if (!isRecord(input)) return false
  const { colors, fonts } = input
  if (colors === undefined && fonts === undefined) return false
  if (colors !== undefined) {
    if (
      !isRecord(colors) ||
      typeof colors.name !== 'string' ||
      colors.name.length === 0 ||
      colors.name.length > 64 ||
      !Array.isArray(colors.values) ||
      colors.values.length !== 12 ||
      colors.values.some((value) => typeof value !== 'string' || !/^#[0-9A-Fa-f]{6}$/.test(value))
    )
      return false
  }
  if (fonts !== undefined) {
    if (
      !isRecord(fonts) ||
      typeof fonts.name !== 'string' ||
      fonts.name.length === 0 ||
      fonts.name.length > 64 ||
      typeof fonts.major !== 'string' ||
      fonts.major.length === 0 ||
      fonts.major.length > 128 ||
      typeof fonts.minor !== 'string' ||
      fonts.minor.length === 0 ||
      fonts.minor.length > 128
    )
      return false
  }
  return true
}

function isDefinedNamesState(input: unknown): boolean {
  if (input === null) return true
  if (!isRecord(input)) return false
  const { names, preserveNames } = input
  if (
    !Array.isArray(names) ||
    names.length > 2_000 ||
    !Array.isArray(preserveNames) ||
    preserveNames.length > 2_000 ||
    preserveNames.some((name) => typeof name !== 'string' || name.length === 0)
  ) {
    return false
  }
  return names.every(
    (entry) =>
      isRecord(entry) &&
      typeof entry.name === 'string' &&
      entry.name.length >= 1 &&
      entry.name.length <= 255 &&
      typeof entry.formula === 'string' &&
      entry.formula.length >= 1 &&
      entry.formula.length <= 8_192 &&
      (entry.sheetIndex === undefined || isNonnegativeInteger(entry.sheetIndex)),
  )
}

function parseSaveResult(input: unknown): WorkbookSaveResult {
  if (!isRecord(input)) throw new Error('Invalid workbook save response.')
  if (input.canceled === true) {
    if (input.csvSaveAsPath !== undefined) {
      if (typeof input.csvSaveAsPath !== 'string' || input.csvSaveAsPath.length === 0) {
        throw new Error('Invalid workbook save response.')
      }
      return { canceled: true, csvSaveAsPath: input.csvSaveAsPath }
    }
    return { canceled: true }
  }
  if (
    input.canceled !== false ||
    !Array.isArray(input.touchedEntries) ||
    input.touchedEntries.length > 10_000 ||
    input.touchedEntries.some((entry) => typeof entry !== 'string')
  ) {
    throw new Error('Invalid workbook save response.')
  }
  return {
    canceled: false,
    file: parseWorkbookFile(input.file),
    touchedEntries: input.touchedEntries as string[],
  }
}

function parseMediaRequest(input: WorkbookMediaRequest): WorkbookMediaRequest {
  if (!isRecord(input) || !isUuid(input.sessionId) || typeof input.visualId !== 'string') {
    throw new Error('Invalid workbook media request.')
  }
  return input
}

function parseMediaResult(input: unknown): WorkbookMediaResult {
  if (
    !isRecord(input) ||
    typeof input.mediaType !== 'string' ||
    !input.mediaType.startsWith('image/') ||
    typeof input.base64 !== 'string' ||
    input.base64.length === 0
  ) {
    throw new Error('Invalid workbook media response.')
  }
  return { mediaType: input.mediaType, base64: input.base64 }
}

function parseSparklineGroups(input: unknown): {
  type: 'line' | 'column' | 'stacked'
  color?: string
  negativeColor?: string
  cells: { cell: string; sourceRef: string }[]
}[] {
  if (!Array.isArray(input) || input.length > 100) {
    throw new Error('Invalid worksheet sparkline metadata.')
  }
  return input.map((entry) => {
    if (
      !isRecord(entry) ||
      (entry.type !== 'line' && entry.type !== 'column' && entry.type !== 'stacked') ||
      !Array.isArray(entry.cells) ||
      entry.cells.length > 500 ||
      (entry.color !== undefined && typeof entry.color !== 'string') ||
      (entry.negativeColor !== undefined && typeof entry.negativeColor !== 'string')
    ) {
      throw new Error('Invalid worksheet sparkline metadata.')
    }
    return {
      type: entry.type,
      ...(entry.color === undefined ? {} : { color: entry.color }),
      ...(entry.negativeColor === undefined ? {} : { negativeColor: entry.negativeColor }),
      cells: entry.cells.map((cell) => {
        if (
          !isRecord(cell) ||
          typeof cell.cell !== 'string' ||
          cell.cell.length < 2 ||
          typeof cell.sourceRef !== 'string' ||
          cell.sourceRef.length === 0
        ) {
          throw new Error('Invalid worksheet sparkline metadata.')
        }
        return { cell: cell.cell, sourceRef: cell.sourceRef }
      }),
    }
  })
}

function parseCellImages(input: unknown): { id: string; row: number; column: number }[] {
  if (!Array.isArray(input) || input.length > 500) {
    throw new Error('Invalid worksheet cell-image metadata.')
  }
  return input.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.id !== 'string' ||
      entry.id.length === 0 ||
      !isNonnegativeInteger(entry.row) ||
      !isNonnegativeInteger(entry.column)
    ) {
      throw new Error('Invalid worksheet cell-image metadata.')
    }
    return { id: entry.id, row: entry.row, column: entry.column }
  })
}

/// Pivot style band fills / font colors (see `pivotTables` in desktop-api.ts).
const PIVOT_PALETTE_COLOR_KEYS = [
  'headerFill',
  'headerFontColor',
  'firstHeaderCellFontColor',
  'wholeTableFill',
  'wholeTableFontColor',
  'stripeFill',
  'secondRowStripeFill',
  'columnStripeFill',
  'secondColumnStripeFill',
  'firstColumnFill',
  'subheadingFill',
  'subheadingFontColor',
  'subheading2Fill',
  'subheading2FontColor',
  'subtotalFill',
  'subtotalFontColor',
  'totalRowFill',
  'totalRowFontColor',
] as const
const PIVOT_PALETTE_BOLD_KEYS = [
  'headerBold',
  'firstHeaderCellBold',
  'firstColumnBold',
  'subheadingBold',
  'subheading2Bold',
  'subtotalBold',
  'totalRowBold',
] as const

type PivotTableInfo = {
  path: string
  cachePath: string | null
  outputRef: string
  styled?: boolean
  firstDataRow?: number
  firstDataCol?: number
  rowGrandTotals?: boolean
  rowKinds?: string
} & Partial<Record<(typeof PIVOT_PALETTE_COLOR_KEYS)[number], string>> &
  Partial<Record<(typeof PIVOT_PALETTE_BOLD_KEYS)[number], boolean>>

function parsePivotTableInfos(input: unknown): PivotTableInfo[] {
  if (!Array.isArray(input) || input.length > 100) {
    throw new Error('Invalid worksheet pivot metadata.')
  }
  return input.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.path !== 'string' ||
      entry.path.length === 0 ||
      (entry.cachePath !== null && typeof entry.cachePath !== 'string') ||
      typeof entry.outputRef !== 'string' ||
      entry.outputRef.length === 0 ||
      PIVOT_PALETTE_COLOR_KEYS.some((key) => !isOptionalString(entry[key])) ||
      PIVOT_PALETTE_BOLD_KEYS.some(
        (key) => entry[key] !== undefined && typeof entry[key] !== 'boolean',
      ) ||
      (entry.styled !== undefined && typeof entry.styled !== 'boolean') ||
      (entry.firstDataRow !== undefined && !isNonnegativeInteger(entry.firstDataRow)) ||
      (entry.firstDataCol !== undefined && !isNonnegativeInteger(entry.firstDataCol)) ||
      (entry.rowGrandTotals !== undefined && typeof entry.rowGrandTotals !== 'boolean') ||
      (entry.rowKinds !== undefined &&
        (typeof entry.rowKinds !== 'string' ||
          entry.rowKinds.length > 1_048_576 ||
          !/^[dsStgb]*$/.test(entry.rowKinds)))
    ) {
      throw new Error('Invalid worksheet pivot metadata.')
    }
    const info: PivotTableInfo = {
      path: entry.path,
      cachePath: entry.cachePath,
      outputRef: entry.outputRef,
      ...(entry.styled === undefined ? {} : { styled: entry.styled }),
      ...(entry.firstDataRow === undefined ? {} : { firstDataRow: entry.firstDataRow }),
      ...(entry.firstDataCol === undefined ? {} : { firstDataCol: entry.firstDataCol }),
      ...(entry.rowGrandTotals === undefined ? {} : { rowGrandTotals: entry.rowGrandTotals }),
      ...(entry.rowKinds === undefined ? {} : { rowKinds: entry.rowKinds }),
    }
    for (const key of PIVOT_PALETTE_COLOR_KEYS) {
      const value = entry[key]
      if (typeof value === 'string') info[key] = value
    }
    for (const key of PIVOT_PALETTE_BOLD_KEYS) {
      const value = entry[key]
      if (typeof value === 'boolean') info[key] = value
    }
    return info
  })
}

function parsePivotRequest(input: WorkbookPivotRequest): WorkbookPivotRequest {
  const isPartPath = (value: unknown): value is string =>
    typeof value === 'string' && value.length <= 256 && /^xl\/[A-Za-z0-9._/-]+\.xml$/.test(value)
  if (
    !isRecord(input) ||
    !isUuid(input.sessionId) ||
    !isPartPath(input.path) ||
    !isPartPath(input.cachePath)
  ) {
    throw new Error('Invalid pivot definition request.')
  }
  return input
}

/// Structural check only — the main process zod-validates the full shape;
/// the recompute engine fails closed on any bad member data.
function parsePivotDefinitionResult(input: unknown): WorkbookPivotDefinition {
  if (
    !isRecord(input) ||
    typeof input.outputRef !== 'string' ||
    typeof input.firstDataRow !== 'number' ||
    typeof input.firstDataCol !== 'number' ||
    typeof input.sourceSheet !== 'string' ||
    typeof input.sourceRef !== 'string' ||
    !Array.isArray(input.fields) ||
    input.fields.length > 1_000 ||
    !Array.isArray(input.fieldItems) ||
    input.fieldItems.length > 1_000 ||
    !Array.isArray(input.rowFields) ||
    input.rowFields.length > 64 ||
    !Array.isArray(input.colFields) ||
    input.colFields.length > 64 ||
    !Array.isArray(input.rowLines) ||
    input.rowLines.length > 100_000 ||
    !Array.isArray(input.colLines) ||
    input.colLines.length > 10_000 ||
    !Array.isArray(input.dataFields) ||
    input.dataFields.length > 256 ||
    !Array.isArray(input.pageFields) ||
    input.pageFields.length > 256 ||
    !Array.isArray(input.unsupported) ||
    input.unsupported.length > 100 ||
    input.unsupported.some((reason) => typeof reason !== 'string')
  ) {
    throw new Error('Invalid pivot definition response.')
  }
  return input as unknown as WorkbookPivotDefinition
}

/**
 * Structural check only — the main process zod-validates the full shape, and
 * the gateway's own parser is what refuses a part it cannot understand. The
 * three states stay distinct here: an `unreadable` result must not be folded
 * into an empty state list on the way to the renderer, or a damaged part would
 * read as "nothing is withheld".
 */
function parseWorkbookRedactionsResult(input: unknown): WorkbookRedactionsResult {
  if (!isRecord(input)) throw new Error('Invalid redaction response.')
  if (input.status === 'absent') return { status: 'absent' }
  if (input.status === 'unreadable') {
    if (typeof input.error !== 'string' || input.error.length === 0) {
      throw new Error('Invalid redaction response.')
    }
    return { status: 'unreadable', error: input.error }
  }
  if (input.status !== 'ok' || !Array.isArray(input.states) || input.states.length > 1_000) {
    throw new Error('Invalid redaction response.')
  }
  for (const state of input.states) {
    if (
      !isRecord(state) ||
      typeof state.sheetName !== 'string' ||
      state.sheetName.length === 0 ||
      !Array.isArray(state.marks) ||
      state.marks.length > 100_000
    ) {
      throw new Error('Invalid redaction response.')
    }
    for (const mark of state.marks) {
      if (
        !isRecord(mark) ||
        typeof mark.startRow !== 'number' ||
        typeof mark.endRow !== 'number' ||
        typeof mark.startColumn !== 'number' ||
        typeof mark.endColumn !== 'number' ||
        typeof mark.label !== 'string' ||
        mark.label.length === 0
      ) {
        throw new Error('Invalid redaction response.')
      }
    }
  }
  return input as unknown as WorkbookRedactionsResult
}

function parseCellStyle(input: unknown): WorkbookCellStyle {
  if (
    !isRecord(input) ||
    typeof input.bold !== 'boolean' ||
    typeof input.italic !== 'boolean' ||
    typeof input.underline !== 'boolean' ||
    typeof input.strikethrough !== 'boolean' ||
    typeof input.wrapText !== 'boolean' ||
    (input.shrinkToFit !== undefined && typeof input.shrinkToFit !== 'boolean') ||
    (input.locked !== undefined && typeof input.locked !== 'boolean') ||
    (input.hidden !== undefined && typeof input.hidden !== 'boolean') ||
    (input.vertAlign !== undefined &&
      input.vertAlign !== 'superscript' &&
      input.vertAlign !== 'subscript') ||
    !isOptionalString(input.fontFamily) ||
    (input.fontSize !== undefined &&
      (typeof input.fontSize !== 'number' ||
        !Number.isFinite(input.fontSize) ||
        input.fontSize <= 0)) ||
    !isOptionalString(input.fontColor) ||
    !isOptionalString(input.fillColor) ||
    !isOptionalString(input.horizontalAlignment) ||
    !isOptionalString(input.verticalAlignment) ||
    (input.indent !== undefined && !isNonnegativeInteger(input.indent)) ||
    (input.textRotation !== undefined &&
      (!isNonnegativeInteger(input.textRotation) || input.textRotation > 255)) ||
    !isOptionalString(input.numberFormat) ||
    (input.fontColorTheme !== undefined && !isNonnegativeInteger(input.fontColorTheme)) ||
    (input.fillColorTheme !== undefined && !isNonnegativeInteger(input.fillColorTheme)) ||
    (input.fontColorTint !== undefined &&
      (typeof input.fontColorTint !== 'number' || !Number.isFinite(input.fontColorTint))) ||
    (input.fillColorTint !== undefined &&
      (typeof input.fillColorTint !== 'number' || !Number.isFinite(input.fillColorTint))) ||
    (input.fontScheme !== undefined && input.fontScheme !== 'major' && input.fontScheme !== 'minor')
  ) {
    throw new Error('Invalid workbook style response.')
  }
  const borderTop = parseBorderEdge(input.borderTop)
  const borderBottom = parseBorderEdge(input.borderBottom)
  const borderLeft = parseBorderEdge(input.borderLeft)
  const borderRight = parseBorderEdge(input.borderRight)
  const borderDiagonal = parseBorderEdge(input.borderDiagonal)
  if (typeof input.diagonalUp !== 'boolean' || typeof input.diagonalDown !== 'boolean') {
    throw new Error('Invalid workbook style response.')
  }
  return {
    bold: input.bold,
    italic: input.italic,
    underline: input.underline,
    strikethrough: input.strikethrough,
    wrapText: input.wrapText,
    diagonalUp: input.diagonalUp,
    diagonalDown: input.diagonalDown,
    ...(input.shrinkToFit === undefined ? {} : { shrinkToFit: input.shrinkToFit }),
    ...(input.locked === undefined ? {} : { locked: input.locked }),
    ...(input.hidden === undefined ? {} : { hidden: input.hidden }),
    ...(input.vertAlign === undefined ? {} : { vertAlign: input.vertAlign }),
    ...(input.fontFamily === undefined ? {} : { fontFamily: input.fontFamily }),
    ...(input.fontSize === undefined ? {} : { fontSize: input.fontSize }),
    ...(input.fontColor === undefined ? {} : { fontColor: input.fontColor }),
    ...(input.fillColor === undefined ? {} : { fillColor: input.fillColor }),
    ...(input.horizontalAlignment === undefined
      ? {}
      : { horizontalAlignment: input.horizontalAlignment }),
    ...(input.verticalAlignment === undefined
      ? {}
      : { verticalAlignment: input.verticalAlignment }),
    ...(input.indent === undefined ? {} : { indent: input.indent }),
    ...(input.textRotation === undefined ? {} : { textRotation: input.textRotation }),
    ...(input.numberFormat === undefined ? {} : { numberFormat: input.numberFormat }),
    ...(input.fontColorTheme === undefined ? {} : { fontColorTheme: input.fontColorTheme }),
    ...(input.fontColorTint === undefined ? {} : { fontColorTint: input.fontColorTint }),
    ...(input.fillColorTheme === undefined ? {} : { fillColorTheme: input.fillColorTheme }),
    ...(input.fillColorTint === undefined ? {} : { fillColorTint: input.fillColorTint }),
    ...(input.fontScheme === undefined ? {} : { fontScheme: input.fontScheme }),
    ...(borderTop === undefined ? {} : { borderTop }),
    ...(borderBottom === undefined ? {} : { borderBottom }),
    ...(borderLeft === undefined ? {} : { borderLeft }),
    ...(borderRight === undefined ? {} : { borderRight }),
    ...(borderDiagonal === undefined ? {} : { borderDiagonal }),
  }
}

const SHEET_PROTECTION_ALLOW_KEYS = [
  'selectLockedCells',
  'selectUnlockedCells',
  'formatCells',
  'formatColumns',
  'formatRows',
  'insertColumns',
  'insertRows',
  'insertHyperlinks',
  'deleteColumns',
  'deleteRows',
  'sort',
  'autoFilter',
  'pivotTables',
  'objects',
  'scenarios',
] as const

function parseSheetProtectionAllow(
  input: unknown,
): NonNullable<WorkbookRangeResult['sheetProtection']>['allow'] {
  if (
    !isRecord(input) ||
    SHEET_PROTECTION_ALLOW_KEYS.some((key) => typeof input[key] !== 'boolean')
  ) {
    throw new Error('Invalid workbook sheet protection.')
  }
  return Object.fromEntries(
    SHEET_PROTECTION_ALLOW_KEYS.map((key) => [key, input[key] as boolean]),
  ) as NonNullable<NonNullable<WorkbookRangeResult['sheetProtection']>['allow']>
}

function parseSheetPasswordHash(
  input: unknown,
): NonNullable<WorkbookRangeResult['sheetProtection']>['password'] {
  if (!isRecord(input)) throw new Error('Invalid workbook sheet protection.')
  if (typeof input.legacy === 'string' && input.legacy.length > 0 && input.legacy.length <= 8) {
    return { legacy: input.legacy }
  }
  if (
    typeof input.algorithmName !== 'string' ||
    input.algorithmName.length === 0 ||
    input.algorithmName.length > 32 ||
    typeof input.hashValue !== 'string' ||
    input.hashValue.length > 1024 ||
    typeof input.saltValue !== 'string' ||
    input.saltValue.length > 1024 ||
    !isNonnegativeInteger(input.spinCount)
  ) {
    throw new Error('Invalid workbook sheet protection.')
  }
  return {
    algorithmName: input.algorithmName,
    hashValue: input.hashValue,
    saltValue: input.saltValue,
    spinCount: input.spinCount,
  }
}

function parseFreeze(input: unknown): { frozenColumns: number; frozenRows: number } | null {
  if (input === null || input === undefined) return null
  if (
    !isRecord(input) ||
    !isNonnegativeInteger(input.frozenColumns) ||
    !isNonnegativeInteger(input.frozenRows)
  ) {
    throw new Error('Invalid worksheet freeze pane.')
  }
  return { frozenColumns: input.frozenColumns, frozenRows: input.frozenRows }
}

function parseBorderEdge(input: unknown): { style: string; color?: string } | undefined {
  if (input === undefined) return undefined
  if (
    !isRecord(input) ||
    typeof input.style !== 'string' ||
    input.style.length === 0 ||
    !isOptionalString(input.color)
  ) {
    throw new Error('Invalid workbook border response.')
  }
  return {
    style: input.style,
    ...(input.color === undefined ? {} : { color: input.color }),
  }
}

function parseVisualObject(input: unknown): WorkbookVisualObject {
  if (
    !isRecord(input) ||
    typeof input.id !== 'string' ||
    typeof input.sheetId !== 'string' ||
    !['chart', 'image', 'shape', 'ole', 'slicer'].includes(String(input.kind)) ||
    !isRecord(input.anchor)
  ) {
    throw new Error('Invalid workbook visual response.')
  }
  const anchor = parseDrawingAnchor(input.anchor)
  const chart = input.chart === undefined ? undefined : parseChart(input.chart)
  if (input.kind === 'chart' && chart === undefined) {
    throw new Error('Workbook chart has no chart metadata.')
  }
  const paragraphs =
    input.paragraphs === undefined ? undefined : parseShapeParagraphs(input.paragraphs)
  const fillGradient =
    input.fillGradient === undefined ? undefined : parseFillGradient(input.fillGradient)
  const customPath = input.customPath === undefined ? undefined : parseCustomPath(input.customPath)
  const crop = input.crop === undefined ? undefined : parseCropRect(input.crop)
  if (
    !isOptionalString(input.shapeType) ||
    (input.opacity !== undefined &&
      (typeof input.opacity !== 'number' ||
        !Number.isFinite(input.opacity) ||
        input.opacity < 0 ||
        input.opacity > 1)) ||
    !isOptionalString(input.fillMediaPath) ||
    !isOptionalString(input.fillMediaType) ||
    !isOptionalString(input.fillColor) ||
    !isOptionalString(input.lineColor) ||
    (input.lineWidth !== undefined &&
      (typeof input.lineWidth !== 'number' || !Number.isFinite(input.lineWidth))) ||
    !isOptionalString(input.lineDash) ||
    !isOptionalString(input.lineCap) ||
    (input.flipH !== undefined && typeof input.flipH !== 'boolean') ||
    (input.flipV !== undefined && typeof input.flipV !== 'boolean') ||
    !isOptionalString(input.textColor) ||
    !isOptionalString(input.textAnchor) ||
    !isOptionalString(input.textVertOverflow) ||
    !isOptionalString(input.textHorzOverflow) ||
    !isOptionalString(input.text) ||
    !isOptionalString(input.progId) ||
    (input.rotation !== undefined &&
      (typeof input.rotation !== 'number' || !Number.isFinite(input.rotation))) ||
    (input.frameWidth !== undefined &&
      (typeof input.frameWidth !== 'number' ||
        !Number.isFinite(input.frameWidth) ||
        input.frameWidth <= 0)) ||
    (input.frameHeight !== undefined &&
      (typeof input.frameHeight !== 'number' ||
        !Number.isFinite(input.frameHeight) ||
        input.frameHeight <= 0)) ||
    (input.drawingPath !== undefined &&
      (typeof input.drawingPath !== 'string' ||
        !/^xl\/drawings\/[A-Za-z0-9._/-]+\.xml$/.test(input.drawingPath))) ||
    (input.drawingIndex !== undefined &&
      (!isNonnegativeInteger(input.drawingIndex) || input.drawingIndex > 10_000)) ||
    !isOptionalString(input.altText) ||
    !isOptionalString(input.hyperlink) ||
    (input.editAs !== undefined &&
      !['twoCell', 'oneCell', 'absolute'].includes(String(input.editAs)))
  ) {
    throw new Error('Invalid workbook visual response.')
  }
  return {
    id: input.id,
    sheetId: input.sheetId,
    kind: input.kind as 'chart' | 'image' | 'shape' | 'ole' | 'slicer',
    anchor,
    ...(chart === undefined ? {} : { chart }),
    ...(typeof input.chartPath === 'string' ? { chartPath: input.chartPath } : {}),
    ...(typeof input.mediaPath === 'string' ? { mediaPath: input.mediaPath } : {}),
    ...(typeof input.mediaType === 'string' ? { mediaType: input.mediaType } : {}),
    ...(input.opacity === undefined ? {} : { opacity: input.opacity }),
    ...(crop === undefined ? {} : { crop }),
    ...(input.fillMediaPath === undefined ? {} : { fillMediaPath: input.fillMediaPath }),
    ...(input.fillMediaType === undefined ? {} : { fillMediaType: input.fillMediaType }),
    ...(typeof input.name === 'string' ? { name: input.name } : {}),
    ...(input.shapeType === undefined ? {} : { shapeType: input.shapeType }),
    ...(customPath === undefined ? {} : { customPath }),
    ...(input.fillColor === undefined ? {} : { fillColor: input.fillColor }),
    ...(fillGradient === undefined ? {} : { fillGradient }),
    ...(input.lineColor === undefined ? {} : { lineColor: input.lineColor }),
    ...(input.lineWidth === undefined ? {} : { lineWidth: input.lineWidth }),
    ...(input.lineDash === undefined ? {} : { lineDash: input.lineDash }),
    ...(input.lineCap === undefined ? {} : { lineCap: input.lineCap }),
    ...(input.flipH === undefined ? {} : { flipH: input.flipH }),
    ...(input.flipV === undefined ? {} : { flipV: input.flipV }),
    ...(input.textColor === undefined ? {} : { textColor: input.textColor }),
    ...(input.textAnchor === undefined ? {} : { textAnchor: input.textAnchor }),
    ...(input.textVertOverflow === undefined ? {} : { textVertOverflow: input.textVertOverflow }),
    ...(input.textHorzOverflow === undefined ? {} : { textHorzOverflow: input.textHorzOverflow }),
    ...(paragraphs === undefined ? {} : { paragraphs }),
    ...(input.text === undefined ? {} : { text: input.text }),
    ...(input.progId === undefined ? {} : { progId: input.progId }),
    ...(input.rotation === undefined ? {} : { rotation: input.rotation }),
    ...(input.frameWidth === undefined ? {} : { frameWidth: input.frameWidth }),
    ...(input.frameHeight === undefined ? {} : { frameHeight: input.frameHeight }),
    ...(input.drawingPath === undefined ? {} : { drawingPath: input.drawingPath }),
    ...(input.drawingIndex === undefined ? {} : { drawingIndex: input.drawingIndex }),
    ...(input.altText === undefined ? {} : { altText: input.altText }),
    ...(input.editAs === undefined
      ? {}
      : { editAs: input.editAs as 'twoCell' | 'oneCell' | 'absolute' }),
    ...(input.hyperlink === undefined ? {} : { hyperlink: input.hyperlink }),
  }
}

function parseCropRect(input: unknown): NonNullable<WorkbookVisualObject['crop']> {
  if (!isRecord(input)) throw new Error('Invalid workbook image crop.')
  const side = (value: unknown): number => {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < -1 || value > 1) {
      throw new Error('Invalid workbook image crop.')
    }
    return value
  }
  return {
    left: side(input.left),
    top: side(input.top),
    right: side(input.right),
    bottom: side(input.bottom),
  }
}

function parseCustomPath(input: unknown): NonNullable<WorkbookVisualObject['customPath']> {
  if (
    !isRecord(input) ||
    typeof input.width !== 'number' ||
    !Number.isFinite(input.width) ||
    input.width <= 0 ||
    typeof input.height !== 'number' ||
    !Number.isFinite(input.height) ||
    input.height <= 0 ||
    typeof input.d !== 'string' ||
    (input.strokeOnly !== undefined && typeof input.strokeOnly !== 'boolean') ||
    (input.fillD !== undefined && typeof input.fillD !== 'string')
  ) {
    throw new Error('Invalid workbook shape custom path.')
  }
  return {
    width: input.width,
    height: input.height,
    d: input.d,
    ...(input.strokeOnly === undefined ? {} : { strokeOnly: input.strokeOnly }),
    ...(input.fillD === undefined ? {} : { fillD: input.fillD }),
  }
}

function parseFillGradient(input: unknown): NonNullable<WorkbookVisualObject['fillGradient']> {
  if (
    !isRecord(input) ||
    typeof input.angle !== 'number' ||
    !Number.isFinite(input.angle) ||
    !Array.isArray(input.stops) ||
    input.stops.length < 2 ||
    input.stops.length > 50
  ) {
    throw new Error('Invalid workbook shape gradient.')
  }
  const stops = input.stops.map((stop) => {
    if (
      !isRecord(stop) ||
      typeof stop.position !== 'number' ||
      !Number.isFinite(stop.position) ||
      stop.position < 0 ||
      stop.position > 1 ||
      typeof stop.color !== 'string'
    ) {
      throw new Error('Invalid workbook shape gradient stop.')
    }
    return { position: stop.position, color: stop.color }
  })
  return { angle: input.angle, stops }
}

function parseShapeParagraphs(input: unknown): NonNullable<WorkbookVisualObject['paragraphs']> {
  if (!Array.isArray(input) || input.length > 200) {
    throw new Error('Invalid workbook shape paragraphs.')
  }
  return input.map((paragraph) => {
    if (
      !isRecord(paragraph) ||
      !isOptionalString(paragraph.align) ||
      !isOptionalFiniteNumber(paragraph.marginLeft) ||
      !isOptionalFiniteNumber(paragraph.indent) ||
      !isOptionalString(paragraph.bulletScheme) ||
      (paragraph.bulletStartAt !== undefined &&
        (typeof paragraph.bulletStartAt !== 'number' ||
          !Number.isInteger(paragraph.bulletStartAt) ||
          paragraph.bulletStartAt < 0)) ||
      !isOptionalString(paragraph.bulletChar) ||
      !Array.isArray(paragraph.runs)
    ) {
      throw new Error('Invalid workbook shape paragraph.')
    }
    const runs = paragraph.runs.map((run) => {
      if (
        !isRecord(run) ||
        typeof run.text !== 'string' ||
        !isOptionalString(run.color) ||
        (run.bold !== undefined && typeof run.bold !== 'boolean') ||
        (run.italic !== undefined && typeof run.italic !== 'boolean') ||
        (run.underline !== undefined && typeof run.underline !== 'boolean') ||
        (run.size !== undefined && (typeof run.size !== 'number' || !Number.isFinite(run.size))) ||
        (run.caps !== undefined && run.caps !== 'all' && run.caps !== 'small')
      ) {
        throw new Error('Invalid workbook shape run.')
      }
      const caps: 'all' | 'small' | undefined =
        run.caps === 'all' || run.caps === 'small' ? run.caps : undefined
      return {
        text: run.text,
        ...(run.color === undefined ? {} : { color: run.color }),
        ...(run.bold === undefined ? {} : { bold: run.bold }),
        ...(run.italic === undefined ? {} : { italic: run.italic }),
        ...(run.underline === undefined ? {} : { underline: run.underline }),
        ...(run.size === undefined ? {} : { size: run.size }),
        ...(caps === undefined ? {} : { caps }),
      }
    })
    return {
      ...(paragraph.align === undefined ? {} : { align: paragraph.align }),
      ...(paragraph.marginLeft === undefined ? {} : { marginLeft: paragraph.marginLeft }),
      ...(paragraph.indent === undefined ? {} : { indent: paragraph.indent }),
      ...(paragraph.bulletScheme === undefined ? {} : { bulletScheme: paragraph.bulletScheme }),
      ...(paragraph.bulletStartAt === undefined ? {} : { bulletStartAt: paragraph.bulletStartAt }),
      ...(paragraph.bulletChar === undefined ? {} : { bulletChar: paragraph.bulletChar }),
      runs,
    }
  })
}

function parseDrawingAnchor(input: Record<string, unknown>): WorkbookVisualObject['anchor'] {
  const values = [input.fromRow, input.fromColumn, input.toRow, input.toColumn]
  const offsets = [
    input.fromRowOffset,
    input.fromColumnOffset,
    input.toRowOffset,
    input.toColumnOffset,
  ]
  if (
    values.some((value) => !isNonnegativeInteger(value)) ||
    offsets.some((value) => typeof value !== 'number' || !Number.isInteger(value)) ||
    (input.explicitTo !== undefined && typeof input.explicitTo !== 'boolean')
  ) {
    throw new Error('Invalid workbook drawing anchor.')
  }
  return {
    fromRow: input.fromRow as number,
    fromColumn: input.fromColumn as number,
    toRow: input.toRow as number,
    toColumn: input.toColumn as number,
    fromRowOffset: input.fromRowOffset as number,
    fromColumnOffset: input.fromColumnOffset as number,
    toRowOffset: input.toRowOffset as number,
    toColumnOffset: input.toColumnOffset as number,
    ...(input.explicitTo === undefined ? {} : { explicitTo: input.explicitTo }),
  }
}

const CHART_LEGENDS = ['none', 'right', 'bottom', 'top', 'left'] as const
const CHART_DATA_LABELS = [
  'none',
  'value',
  'percent',
  'category-percent',
  'category-value-percent',
] as const
const CHART_DATA_LABEL_POSITIONS = ['center', 'inside-end', 'outside-end'] as const
const CHART_GROUPINGS = ['clustered', 'stacked', 'percentStacked', 'standard'] as const
const CHART_DISP_BLANKS = ['gap', 'zero', 'span'] as const

function parseChart(input: unknown): NonNullable<WorkbookVisualObject['chart']> {
  if (
    !isRecord(input) ||
    !Array.isArray(input.chartTypes) ||
    input.chartTypes.some((value) => typeof value !== 'string') ||
    typeof input.title !== 'string' ||
    !Array.isArray(input.series) ||
    !isOptionalString(input.barDirection) ||
    !isOptionalEnum(input.legend, CHART_LEGENDS) ||
    !isOptionalEnum(input.dataLabels, CHART_DATA_LABELS) ||
    !isOptionalEnum(input.dataLabelPosition, CHART_DATA_LABEL_POSITIONS) ||
    !isOptionalString(input.dataLabelFormat) ||
    !isOptionalEnum(input.grouping, CHART_GROUPINGS) ||
    (input.gridlines !== undefined && typeof input.gridlines !== 'boolean') ||
    !isOptionalString(input.categoryAxisFormat) ||
    !isOptionalFiniteNumber(input.gapWidthPct) ||
    !isOptionalFiniteNumber(input.holeSizePct) ||
    (input.lineMarkers !== undefined && typeof input.lineMarkers !== 'boolean') ||
    !isOptionalEnum(input.dispBlanksAs, CHART_DISP_BLANKS) ||
    !isOptionalString(input.chartAreaFill) ||
    !isOptionalString(input.plotAreaFill)
  ) {
    throw new Error('Invalid workbook chart response.')
  }
  const axisTitles = parseChartAxisTitles(input.axisTitles)
  const valueAxis = parseChartValueAxis(input.valueAxis)
  const xAxis = parseChartAxisInfo(input.xAxis)
  const yAxis = parseChartAxisInfo(input.yAxis)
  const secondaryYAxis = parseChartAxisInfo(input.secondaryYAxis)
  const titleStyle = parseChartTitleStyle(input.titleStyle)
  const dataLabelStyle = parseChartTitleStyle(input.dataLabelStyle)
  if (!isOptionalString(input.scatterStyle)) {
    throw new Error('Invalid workbook chart response.')
  }
  const series = input.series.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.name !== 'string' ||
      !isOptionalString(entry.nameRef) ||
      !Array.isArray(entry.categories) ||
      entry.categories.some((value) => typeof value !== 'string') ||
      !Array.isArray(entry.values) ||
      entry.values.some((value) => typeof value !== 'number' || !Number.isFinite(value)) ||
      (entry.blanks !== undefined &&
        (!Array.isArray(entry.blanks) ||
          entry.blanks.some(
            (value) => typeof value !== 'number' || !Number.isInteger(value) || value < 0,
          ))) ||
      !isOptionalString(entry.numberFormat) ||
      !isOptionalString(entry.categoryFormat) ||
      !isOptionalString(entry.color) ||
      !isOptionalString(entry.trendline) ||
      !isOptionalString(entry.valuesRef) ||
      !isOptionalString(entry.categoriesRef) ||
      !isOptionalFiniteNumber(entry.explosionPct) ||
      !isOptionalString(entry.lineColor) ||
      !isOptionalFiniteNumber(entry.lineWidth) ||
      (entry.smooth !== undefined && typeof entry.smooth !== 'boolean') ||
      !isOptionalString(entry.marker) ||
      !isOptionalString(entry.plot) ||
      (entry.secondaryAxis !== undefined && typeof entry.secondaryAxis !== 'boolean') ||
      !isOptionalEnum(entry.dataLabels, CHART_DATA_LABELS)
    ) {
      throw new Error('Invalid workbook chart series.')
    }
    const pointColors = parseChartPointColors(entry.pointColors)
    const pointLabels = parseChartPointLabels(entry.pointLabels)
    const pointExplosions = parseChartPointExplosions(entry.pointExplosions)
    const categoryGroups = parseChartCategoryGroups(entry.categoryGroups)
    return {
      name: entry.name,
      ...(entry.nameRef === undefined ? {} : { nameRef: entry.nameRef }),
      categories: entry.categories,
      values: entry.values,
      ...(entry.blanks === undefined ? {} : { blanks: entry.blanks }),
      ...(entry.numberFormat === undefined ? {} : { numberFormat: entry.numberFormat }),
      ...(entry.categoryFormat === undefined ? {} : { categoryFormat: entry.categoryFormat }),
      ...(entry.color === undefined ? {} : { color: entry.color }),
      ...(entry.trendline === undefined ? {} : { trendline: entry.trendline }),
      ...(entry.valuesRef === undefined ? {} : { valuesRef: entry.valuesRef }),
      ...(entry.categoriesRef === undefined ? {} : { categoriesRef: entry.categoriesRef }),
      ...(pointColors === undefined ? {} : { pointColors }),
      ...(entry.explosionPct === undefined ? {} : { explosionPct: entry.explosionPct }),
      ...(pointExplosions === undefined ? {} : { pointExplosions }),
      ...(entry.lineColor === undefined ? {} : { lineColor: entry.lineColor }),
      ...(entry.lineWidth === undefined ? {} : { lineWidth: entry.lineWidth }),
      ...(entry.smooth === undefined ? {} : { smooth: entry.smooth }),
      ...(entry.marker === undefined ? {} : { marker: entry.marker }),
      ...(entry.plot === undefined ? {} : { plot: entry.plot }),
      ...(entry.secondaryAxis === undefined ? {} : { secondaryAxis: entry.secondaryAxis }),
      ...(categoryGroups === undefined ? {} : { categoryGroups }),
      ...(entry.dataLabels === undefined ? {} : { dataLabels: entry.dataLabels }),
      ...(pointLabels === undefined ? {} : { pointLabels }),
    }
  })
  return {
    chartTypes: input.chartTypes,
    title: input.title,
    series,
    ...(input.barDirection === undefined ? {} : { barDirection: input.barDirection }),
    ...(input.legend === undefined ? {} : { legend: input.legend }),
    ...(axisTitles === undefined ? {} : { axisTitles }),
    ...(input.dataLabels === undefined ? {} : { dataLabels: input.dataLabels }),
    ...(input.dataLabelPosition === undefined
      ? {}
      : { dataLabelPosition: input.dataLabelPosition }),
    ...(input.dataLabelFormat === undefined ? {} : { dataLabelFormat: input.dataLabelFormat }),
    ...(input.grouping === undefined ? {} : { grouping: input.grouping }),
    ...(input.gridlines === undefined ? {} : { gridlines: input.gridlines }),
    ...(input.categoryAxisFormat === undefined
      ? {}
      : { categoryAxisFormat: input.categoryAxisFormat }),
    ...(valueAxis === undefined ? {} : { valueAxis }),
    ...(input.gapWidthPct === undefined ? {} : { gapWidthPct: input.gapWidthPct }),
    ...(input.holeSizePct === undefined ? {} : { holeSizePct: input.holeSizePct }),
    ...(xAxis === undefined ? {} : { xAxis }),
    ...(yAxis === undefined ? {} : { yAxis }),
    ...(secondaryYAxis === undefined ? {} : { secondaryYAxis }),
    ...(titleStyle === undefined ? {} : { titleStyle }),
    ...(dataLabelStyle === undefined ? {} : { dataLabelStyle }),
    ...(input.scatterStyle === undefined ? {} : { scatterStyle: input.scatterStyle }),
    ...(input.lineMarkers === undefined ? {} : { lineMarkers: input.lineMarkers }),
    ...(input.dispBlanksAs === undefined ? {} : { dispBlanksAs: input.dispBlanksAs }),
    ...(input.chartAreaFill === undefined ? {} : { chartAreaFill: input.chartAreaFill }),
    ...(input.plotAreaFill === undefined ? {} : { plotAreaFill: input.plotAreaFill }),
  }
}

function parseChartTitleStyle(
  input: unknown,
): { size?: number; bold?: boolean; color?: string } | undefined {
  if (input === undefined) return undefined
  if (
    !isRecord(input) ||
    !isOptionalFiniteNumber(input.size) ||
    (input.bold !== undefined && typeof input.bold !== 'boolean') ||
    !isOptionalString(input.color)
  ) {
    throw new Error('Invalid workbook chart title style.')
  }
  return {
    ...(input.size === undefined ? {} : { size: input.size }),
    ...(input.bold === undefined ? {} : { bold: input.bold }),
    ...(input.color === undefined ? {} : { color: input.color }),
  }
}

function isOptionalAxisSide(value: unknown): value is 'l' | 'r' | 't' | 'b' | undefined {
  return value === undefined || value === 'l' || value === 'r' || value === 't' || value === 'b'
}

function parseChartAxisInfo(input: unknown):
  | {
      title?: string
      min?: number
      max?: number
      majorUnit?: number
      numFmt?: string
      majorGridlines: boolean
      hidden: boolean
      reversed: boolean
      position?: 'l' | 'r' | 't' | 'b'
      labelSize?: number
      labelColor?: string
      titleSize?: number
      titleColor?: string
      displayUnit?: number
      displayUnitLabel?: string
    }
  | undefined {
  if (input === undefined) return undefined
  if (
    !isRecord(input) ||
    !isOptionalString(input.title) ||
    !isOptionalFiniteNumber(input.min) ||
    !isOptionalFiniteNumber(input.max) ||
    !isOptionalFiniteNumber(input.majorUnit) ||
    !isOptionalString(input.numFmt) ||
    typeof input.majorGridlines !== 'boolean' ||
    (input.hidden !== undefined && typeof input.hidden !== 'boolean') ||
    (input.reversed !== undefined && typeof input.reversed !== 'boolean') ||
    !isOptionalAxisSide(input.position) ||
    !isOptionalFiniteNumber(input.labelSize) ||
    !isOptionalString(input.labelColor) ||
    !isOptionalFiniteNumber(input.titleSize) ||
    !isOptionalString(input.titleColor) ||
    !isOptionalFiniteNumber(input.displayUnit) ||
    !isOptionalString(input.displayUnitLabel)
  ) {
    throw new Error('Invalid workbook chart axis.')
  }
  return {
    ...(input.title === undefined ? {} : { title: input.title }),
    ...(input.min === undefined ? {} : { min: input.min }),
    ...(input.max === undefined ? {} : { max: input.max }),
    ...(input.majorUnit === undefined ? {} : { majorUnit: input.majorUnit }),
    ...(input.numFmt === undefined ? {} : { numFmt: input.numFmt }),
    majorGridlines: input.majorGridlines,
    hidden: input.hidden === true,
    reversed: input.reversed === true,
    ...(input.position === undefined ? {} : { position: input.position }),
    ...(input.labelSize === undefined ? {} : { labelSize: input.labelSize }),
    ...(input.labelColor === undefined ? {} : { labelColor: input.labelColor }),
    ...(input.titleSize === undefined ? {} : { titleSize: input.titleSize }),
    ...(input.titleColor === undefined ? {} : { titleColor: input.titleColor }),
    ...(input.displayUnit === undefined ? {} : { displayUnit: input.displayUnit }),
    ...(input.displayUnitLabel === undefined ? {} : { displayUnitLabel: input.displayUnitLabel }),
  }
}

function parseChartAxisTitles(
  input: unknown,
): { category?: string | null; value?: string | null } | undefined {
  if (input === undefined) return undefined
  if (
    !isRecord(input) ||
    !isOptionalNullableString(input.category) ||
    !isOptionalNullableString(input.value)
  ) {
    throw new Error('Invalid workbook chart axis titles.')
  }
  return {
    ...(input.category === undefined ? {} : { category: input.category }),
    ...(input.value === undefined ? {} : { value: input.value }),
  }
}

function parseChartValueAxis(input: unknown): { min?: number; max?: number } | undefined {
  if (input === undefined) return undefined
  if (
    !isRecord(input) ||
    !isOptionalFiniteNumber(input.min) ||
    !isOptionalFiniteNumber(input.max)
  ) {
    throw new Error('Invalid workbook chart value axis.')
  }
  return {
    ...(input.min === undefined ? {} : { min: input.min }),
    ...(input.max === undefined ? {} : { max: input.max }),
  }
}

function parseChartPointColors(
  input: unknown,
): Array<{ index: number; color: string }> | undefined {
  if (input === undefined) return undefined
  if (!Array.isArray(input)) throw new Error('Invalid workbook chart point colors.')
  return input.map((entry) => {
    if (!isRecord(entry) || !isNonnegativeInteger(entry.index) || typeof entry.color !== 'string') {
      throw new Error('Invalid workbook chart point colors.')
    }
    return { index: entry.index, color: entry.color }
  })
}

function parseChartPointLabels(
  input: unknown,
): Array<{ index: number; showVal?: boolean; offsetX?: number; offsetY?: number }> | undefined {
  if (input === undefined) return undefined
  if (!Array.isArray(input)) throw new Error('Invalid workbook chart point labels.')
  return input.map((entry) => {
    if (
      !isRecord(entry) ||
      !isNonnegativeInteger(entry.index) ||
      (entry.showVal !== undefined && typeof entry.showVal !== 'boolean') ||
      !isOptionalFiniteNumber(entry.offsetX) ||
      !isOptionalFiniteNumber(entry.offsetY)
    ) {
      throw new Error('Invalid workbook chart point labels.')
    }
    return {
      index: entry.index,
      ...(entry.showVal === undefined ? {} : { showVal: entry.showVal }),
      ...(entry.offsetX === undefined ? {} : { offsetX: entry.offsetX }),
      ...(entry.offsetY === undefined ? {} : { offsetY: entry.offsetY }),
    }
  })
}

function parseChartCategoryGroups(
  input: unknown,
): Array<{ label: string; start: number; end: number }> | undefined {
  if (input === undefined) return undefined
  if (!Array.isArray(input)) throw new Error('Invalid workbook chart category groups.')
  return input.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.label !== 'string' ||
      !isNonnegativeInteger(entry.start) ||
      !isNonnegativeInteger(entry.end)
    ) {
      throw new Error('Invalid workbook chart category groups.')
    }
    return { label: entry.label, start: entry.start, end: entry.end }
  })
}

function parseChartPointExplosions(
  input: unknown,
): Array<{ index: number; pct: number }> | undefined {
  if (input === undefined) return undefined
  if (!Array.isArray(input)) throw new Error('Invalid workbook chart point explosions.')
  return input.map((entry) => {
    if (
      !isRecord(entry) ||
      !isNonnegativeInteger(entry.index) ||
      typeof entry.pct !== 'number' ||
      !Number.isFinite(entry.pct)
    ) {
      throw new Error('Invalid workbook chart point explosions.')
    }
    return { index: entry.index, pct: entry.pct }
  })
}

function isRecord(input: unknown): input is Record<string, unknown> {
  return typeof input === 'object' && input !== null && !Array.isArray(input)
}

function isUuid(input: unknown): input is string {
  return (
    typeof input === 'string' &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(input)
  )
}

const isShapePaint = (value: unknown): boolean =>
  value === undefined ||
  value === 'none' ||
  (typeof value === 'string' && /^#[0-9A-Fa-f]{6}$/.test(value))

function isNonnegativeInteger(input: unknown): input is number {
  return typeof input === 'number' && Number.isInteger(input) && input >= 0
}

/// Sheet default row height / column width: finite positive number, or null
/// for "no default — use the built-in size" (0 and junk degrade to null).
function normalizedDefaultSize(input: unknown): number | null {
  return typeof input === 'number' && Number.isFinite(input) && input > 0 ? input : null
}

function isPositiveInteger(input: unknown): input is number {
  return isNonnegativeInteger(input) && input > 0
}

function isCellScalar(input: unknown): input is string | number | boolean | null {
  return input === null || ['string', 'number', 'boolean'].includes(typeof input)
}

function isOptionalString(input: unknown): input is string | undefined {
  return input === undefined || typeof input === 'string'
}

function isBoundedString(input: unknown, maxLength: number): input is string {
  return typeof input === 'string' && input.length >= 1 && input.length <= maxLength
}

function isOptionalNullableString(input: unknown): input is string | null | undefined {
  return input === undefined || input === null || typeof input === 'string'
}

function isOptionalFiniteNumber(input: unknown): input is number | undefined {
  return input === undefined || (typeof input === 'number' && Number.isFinite(input))
}

function isOptionalEnum<T extends string>(
  input: unknown,
  values: readonly T[],
): input is T | undefined {
  return input === undefined || (values as readonly unknown[]).includes(input)
}
